AutocompleteStyle.builder()
    .textFieldStyle(/** Стиль компонента */)
    .dropdownStyle(/** Стиль компонента */)
    .style()

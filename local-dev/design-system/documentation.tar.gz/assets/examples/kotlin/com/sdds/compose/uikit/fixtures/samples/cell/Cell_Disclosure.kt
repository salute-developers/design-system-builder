Cell(
    disclosureContentEnabled = true,
    disclosureText = AnnotatedString("Description"),
)

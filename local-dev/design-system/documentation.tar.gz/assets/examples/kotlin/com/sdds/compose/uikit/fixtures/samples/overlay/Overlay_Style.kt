OverlayStyle.builder()
    .color {
        backgroundColor(SolidColor(Color.Gray))
    }
    .style()

ButtonGroupStyle.builder()
    .externalShape(CircleShape)
    .internalShape(RoundedCornerShape(5))
    .buttonStyle(
        /** Стиль компонента */,
    )
    .dimensions {
        spacing(2.dp)
    }
    .style()

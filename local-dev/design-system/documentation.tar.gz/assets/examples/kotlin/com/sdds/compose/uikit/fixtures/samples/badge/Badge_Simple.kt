Badge(
    label = "Label",
    startContent = {
        Icon(
            painter = painterResource(id = R.drawable.ic_plasma_16),
            contentDescription = "",
        )
    },
)

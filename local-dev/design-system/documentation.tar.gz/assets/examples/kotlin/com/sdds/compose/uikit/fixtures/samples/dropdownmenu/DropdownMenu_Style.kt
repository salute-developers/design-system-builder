DropdownMenuStyle.builder()
    .shadow(/** Токен тени */)
    .shape(/** Токен формы (скругления) */)
    .listStyle(/** Стиль компонента */)
    .dividerStyle(/** Стиль разделителя */)
    .overlayStyle(/** Стиль overlay */)
    .dimensions {
        width(200.dp)
        strokeWidth(1.dp)
        offset(8.0.dp)
    }
    .colors {
        backgroundColor(SolidColor(Color.LightGray))
        strokeColor(SolidColor(Color.Black))
    }
    .style()

CheckBox(
    state = ToggleableState.On,
    enabled = true,
    label = "Label",
    description = "Description",
    onClick = {},
)

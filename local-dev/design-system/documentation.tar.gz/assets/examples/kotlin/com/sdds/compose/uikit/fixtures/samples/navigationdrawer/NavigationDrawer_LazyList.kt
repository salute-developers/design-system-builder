val selectedIndex = remember { mutableIntStateOf(0) }
val state = rememberNavigationDrawerState(NavigationDrawerValue.Expanded)

NavigationDrawer(
    state = state,
    lazyContent = {
        items(count = 50) { index ->
            NavigationDrawerItem(
                selected = selectedIndex.intValue == index,
                icon = { Icon(painterResource(R.drawable.ic_mail_outline_24), "") },
                titleContent = { Text("Item $index") },
                onClick = { selectedIndex.intValue = index },
            )
        }
    },
)

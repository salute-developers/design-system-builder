val drawerState = rememberDrawerState(
    initialValue = placeholder(
        DrawerValue.Opened,
        "DrawerValue.Closed",
    ),
)
Drawer(
    drawerState = drawerState,
    openOnFocus = false,
    drawerContent = { Text("Панель не открывается по фокусу") },
) {
    /* Основной контент */
}

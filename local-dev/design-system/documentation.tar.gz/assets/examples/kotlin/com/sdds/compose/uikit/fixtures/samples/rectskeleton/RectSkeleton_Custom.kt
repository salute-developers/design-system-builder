RectSkeleton(
    modifier = Modifier.size(64.dp),
    shape = CircleShape, // кастомная форма
    duration = 1200, // кастомная длительность анимации
    brush = /** Токен градиента */
        .asStatefulValue(), // кастомный градиент
)

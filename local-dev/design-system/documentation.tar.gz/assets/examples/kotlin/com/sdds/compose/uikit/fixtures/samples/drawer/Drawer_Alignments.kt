val start = rememberDrawerState(
    initialValue = DrawerValue.Closed,
    alignment = DrawerAlignment.Start,
)
val end =
    rememberDrawerState(initialValue = DrawerValue.Closed, alignment = DrawerAlignment.End)
val top =
    rememberDrawerState(initialValue = DrawerValue.Closed, alignment = DrawerAlignment.Top)
val bottom = rememberDrawerState(
    initialValue = DrawerValue.Closed,
    alignment = DrawerAlignment.Bottom,
)
val scope = rememberCoroutineScope()

Column {
    Button(label = "Слева", onClick = { scope.launch { start.open() } })
    Drawer(drawerState = start, drawerContent = { Text("Панель слева") }) { }

    Button(label = "Справа", onClick = { scope.launch { end.open() } })
    Drawer(drawerState = end, drawerContent = { Text("Панель справа") }) { }

    Button(label = "Сверху", onClick = { scope.launch { top.open() } })
    Drawer(drawerState = top, drawerContent = { Text("Панель сверху") }) { }

    Button(label = "Снизу", onClick = { scope.launch { bottom.open() } })
    Drawer(drawerState = bottom, drawerContent = { Text("Панель снизу") }) { }
}

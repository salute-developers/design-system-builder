Card(
    modifier = Modifier
        .width(150.dp)
        .height(200.dp),
    focusSelectorSettings = LocalFocusSelectorSettings.current,
) {
    Column(
        modifier = Modifier
            .fillMaxSize(),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center,
    ) {
        Text(
            text = "Заголовок",
            color = placeholder({ Color.Gray }, replace = "/** Токен цвета */"),
        )
        CardContent(
            modifier = Modifier,
            focusSelectorSettings = FocusSelectorSettings.None,
        ) {
            Column(
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.Center,
                modifier = Modifier.fillMaxSize(),
            ) {
                Image(
                    contentScale = ContentScale.Crop,
                    painter = painterResource(id = R.drawable.ic_bulb_diode_fill_36),
                    colorFilter = ColorFilter.tint(Color.Black),
                    contentDescription = "Android",
                )
                Spacer(modifier = Modifier.height(8.dp))
                Text(
                    text = "Подзаголовок",
                    color = placeholder({ Color.Black }, replace = "/** Токен цвета */"),
                )
                Row(
                    modifier = Modifier.padding(top = 12.dp),
                    horizontalArrangement = Arrangement.spacedBy(12.dp),
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    Image(
                        contentScale = ContentScale.Crop,
                        painter = painterResource(id = R.drawable.ic_power_16),
                        colorFilter = ColorFilter.tint(Color.Black),
                        contentDescription = "Power",
                    )

                    Image(
                        contentScale = ContentScale.Crop,
                        painter = painterResource(id = R.drawable.ic_reset_outline_16),
                        colorFilter = ColorFilter.tint(Color.Black),
                        contentDescription = "Reset",
                    )

                    Image(
                        contentScale = ContentScale.Crop,
                        painter = painterResource(id = R.drawable.ic_settings_outline_16),
                        colorFilter = ColorFilter.tint(Color.Black),
                        contentDescription = "Settings",
                    )
                }
            }
        }
    }
}

TextFieldStyle.builder()
    .colors {
        captionColor(
            /** Токен цвета */.asInteractive(
                setOf(InteractiveState.Activated)
                    to /** Токен цвета в состоянии activated */,
            ),
        )
        backgroundColor(
            /** Токен цвета */.asInteractive(
                setOf(InteractiveState.Activated)
                    to /** Токен цвета в состоянии activated */,
            ),
        )
        optionalColor(/** Токен цвета */.asInteractive())
        valueColor(/** Токен цвета */.asInteractive())
        placeholderColor(
            /** Токен цвета */.asInteractive(
                setOf(InteractiveState.Activated)
                    to /** Токен цвета в состоянии activated */,
            ),
        )
        indicatorColor(/** Токен цвета */.asInteractive())
        startContentColor(/** Токен цвета */.asInteractive())
        endContentColor(
            /** Токен цвета */.asInteractive(
                setOf(InteractiveState.Pressed)
                    to /** Токен цвета в состоянии pressed */,
                setOf(InteractiveState.Hovered)
                    to /** Токен цвета в состоянии hovered */,
            ),
        )
        endContentColorReadOnly(
            /** Токен цвета */.multiplyAlpha(0.4f)
                .asInteractive(),
        )
        captionColorReadOnly(
            /** Токен цвета */.asInteractive(),
        )
        counterColor(/** Токен цвета */.asInteractive())
        backgroundColorReadOnly(
            /** Токен цвета */.multiplyAlpha(0.4f)
                .asInteractive(),
        )
        cursorColor(/** Токен цвета */.asInteractive())
        prefixColor(/** Токен цвета */.asInteractive())
        suffixColor(/** Токен цвета */.asInteractive())
    }
    .singleLine(true)
    .shape(
        /** Токен формы(скругления) */
            .adjustBy(all = 0.0.dp),
    )
    .dimensions {
        optionalPadding(4.0.dp)
        helperTextPadding(4.0.dp)
        chipsPadding(6.0.dp)
        boxPaddingStart(8.0.dp)
        boxPaddingEnd(8.0.dp)
        boxPaddingTop(8.0.dp)
        boxPaddingBottom(8.0.dp)
        boxMinHeight(32.0.dp)
        alignmentLineHeight(32.0.dp)
        startContentPadding(4.0.dp)
        endContentPadding(4.0.dp)
        startContentSize(16.0.dp)
        endContentSize(16.0.dp)
    }
    .captionStyle(/** Токен типографики */)
    .counterStyle(/** Токен типографики */)
    .captionPlacement(TextFieldHelperTextPlacement.Outer)
    .counterPlacement(TextFieldHelperTextPlacement.Outer)
    .valueStyle(/** Токен типографики */)
    .prefixStyle(/** Токен типографики */)
    .suffixStyle(/** Токен типографики */)
    .placeholderStyle(/** Токен типографики */)
    .chipGroupStyle(/** Стиль компонента */)
    .labelPlacement(TextFieldLabelPlacement.None)
    .style()

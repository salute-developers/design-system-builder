IconBadge(
    content = {
        Icon(
            painter = painterResource(id = R.drawable.ic_plasma_16),
            contentDescription = "",
        )
    },
)

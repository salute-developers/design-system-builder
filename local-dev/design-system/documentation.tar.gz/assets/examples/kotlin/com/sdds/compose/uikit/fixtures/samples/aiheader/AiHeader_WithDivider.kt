AiHeader(
    modifier = Modifier.fillMaxWidth(),
    separationType = AiHeaderSeparationType.Divider,
    actionBefore = {
        IconButton(iconRes = R.drawable.ic_panel_sidebar_l_outline_24, onClick = {})
    },
    actionAfter = {
        IconButton(iconRes = R.drawable.ic_close_24, onClick = {})
    },
    titleContent = { Text(text = "Заголовок") },
    subtitleContent = { Text(text = "Подзаголовок") },
)

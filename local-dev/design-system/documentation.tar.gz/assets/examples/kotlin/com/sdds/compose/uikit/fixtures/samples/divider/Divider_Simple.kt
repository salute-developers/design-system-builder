Divider(
    modifier = Modifier,
    orientation = DividerOrientation.Horizontal,
)

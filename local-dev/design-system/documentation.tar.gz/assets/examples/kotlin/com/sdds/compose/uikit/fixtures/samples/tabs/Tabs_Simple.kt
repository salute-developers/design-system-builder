val pagerState = rememberPagerState { 5 }
val scope = rememberCoroutineScope()
Tabs(
    selectedTabIndexProvider = { pagerState.currentPage },
    selectedTabOffset = { pagerState.currentPageOffsetFraction },
) {
    repeat(pagerState.pageCount) { index ->
        tabItem {
            // Анимация TabItem при изменении состояния pagerState
            val tabMotion = rememberTabItemPagerMotion(index, pagerState)
            // Состояние выбора текущего таба
            val isTabSelected = rememberTabSelectedState(index, pagerState)
            TabItem(
                isSelected = isTabSelected.value,
                onClick = {
                    scope.launch {
                        pagerState.animateScrollToPage(
                            index,
                            pagerState.currentPageOffsetFraction,
                        )
                    }
                },
                content = { Text("Tab$index") },
                helperContent = { Text("Value") },
                counter = {
                    Counter(
                        count = "3",
                        // Делимся контекстом с Counter, чтобы он анимировлся синхронно с TabItem
                        motion = rememberCounterMotion(motionContext = tabMotion.context),
                    )
                },
                startContent = {
                    Icon(
                        source = resourceImageSource(R.drawable.ic_plasma_24),
                        contentDescription = "",
                    )
                },
                motion = tabMotion,
            )
        }
    }
}

HorizontalPager(
    state = pagerState,
    pageContent = {},
)

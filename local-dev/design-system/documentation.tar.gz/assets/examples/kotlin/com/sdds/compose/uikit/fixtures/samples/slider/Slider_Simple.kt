Slider(
    modifier = Modifier,
    value = 0f,
    title = "Title",
    labelContent = {
        Icon(
            painter = painterResource(com.sdds.icons.R.drawable.ic_salute_outline_36),
            contentDescription = null,
        )
    },
    onValueChange = {},
    labelEnabled = true,
    thumbEnabled = true,
    limitLabelEnabled = true,
    slideDirection = SlideDirection.Normal,
    valueRange = 0f..1f,
    valueFormatTransformer = { progress ->
        val totalSeconds = progress.toInt()
        val minutes = totalSeconds / 60
        val seconds = totalSeconds % 60
        "%02d:%02d".format(minutes, seconds)
    },
    alignment = SliderAlignment.Start,
)

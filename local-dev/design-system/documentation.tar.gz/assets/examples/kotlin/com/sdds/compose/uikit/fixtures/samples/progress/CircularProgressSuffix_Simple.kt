val progress = 0.5f
CircularProgressBar(
    progress = progress,
    style = LocalCircularProgressBarStyle.current,
    value = "${(progress * 100).roundToInt()}",
    valueSuffix = "%",
)

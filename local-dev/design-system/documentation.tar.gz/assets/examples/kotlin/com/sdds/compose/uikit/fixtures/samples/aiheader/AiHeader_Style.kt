AiHeaderStyle.builder()
    .shape(/** Токен формы (скругления) */)
    .titleStyle(/** Токен типографики */)
    .subtitleStyle(/** Токен типографики */)
    .colors {
        backgroundColor(/** Токен цвета */)
        titleColor(/** Токен цвета */)
        subtitleColor(/** Токен цвета */)
        dividerColor(/** Токен цвета */)
    }
    .dimensions {
        paddingStart(0.0.dp)
        paddingEnd(0.0.dp)
        paddingTop(0.0.dp)
        paddingBottom(0.0.dp)
        textPaddingStart(10.0.dp)
        textPaddingEnd(10.0.dp)
        textPaddingTop(9.0.dp)
        textPaddingBottom(9.0.dp)
        subtitlePadding(4.0.dp)
        dividerThickness(1.0.dp)
    }
    .startButtonStyle(
        /** Стиль кнопки слева */,
    )
    .endButtonStyle(
        /** Стиль кнопки справа */,
    )
    .style()

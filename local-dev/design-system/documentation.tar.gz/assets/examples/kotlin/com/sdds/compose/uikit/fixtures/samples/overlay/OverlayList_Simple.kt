val listState = rememberLazyListState()
val scrollOffset by remember {
    derivedStateOf {
        listState.firstVisibleItemIndex * (
            listState.layoutInfo.visibleItemsInfo.firstOrNull()?.size
                ?: 0
            ) +
            listState.firstVisibleItemScrollOffset
    }
}

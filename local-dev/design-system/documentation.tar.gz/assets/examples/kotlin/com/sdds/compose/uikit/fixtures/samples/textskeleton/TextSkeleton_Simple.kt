TextSkeleton(
    textStyle = /** Токен стиля текста */,
)

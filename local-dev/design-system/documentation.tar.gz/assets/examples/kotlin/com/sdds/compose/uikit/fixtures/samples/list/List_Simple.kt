com.sdds.compose.uikit.List {
    items(5) {
        val interactionSource = remember { MutableInteractionSource() }
        val isFocused = interactionSource.collectIsFocusedAsState()
        ListItem(
            modifier = Modifier
                .focusable(interactionSource = interactionSource)
                .focusSelector(
                    settings = LocalFocusSelectorSettings.current,
                ) { isFocused.value },
            text = "List item title",
            label = "List item label",
            disclosureEnabled = true,
            interactionSource = interactionSource,
        )
    }
}

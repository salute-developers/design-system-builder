var text by remember { mutableStateOf("") }
MaskedTextField(
    value = text,
    onValueChange = { text = it },
    mask = remember {
        NumberMask(
            decimalScale = 3, // изменяем количество знаков после запятой
            decimalSeparator = ".", // используем кастомный разделитель дробной части
            decimalSeparatorAliases = listOf(".", ",").toSet(), // изменяем спиок допустимых разделителей
            thousandGroupSeparator = "_", // кастомный разделитель групп цифр
            digitsPerGroup = 2, // изменяем количество цифр в группе
        )
    },
    placeholderText = "Введите сумму",
    suffix = "млн. руб",
    focusSelectorSettings = FocusSelectorSettings.None,
)

RadioBoxStyle.builder()
    .colorValues {
        labelColor(/** Токен цвета */.asInteractive())
        descriptionColor(/** Токен цвета */.asInteractive())
        toggleColor(
            /** Токен цвета */.asInteractive(
                setOf(RadioBoxStates.Checked)
                    to /** Цвет в состоянии checked */,
            ),
        )
        toggleIconColor(/** Токен цвета */.asInteractive())
        toggleBorderColor(/** Токен цвета */.asInteractive())
    }
    .shape(/** Токе формы(скругления) */)
    .labelStyle(/** Токен типографики */)
    .descriptionStyle(/** Токен типографики */)
    .dimensionValues {
        toggleBorderOffset(
            0.0.dp.asStatefulValue(
                setOf(InteractiveState.Focused) to 3.0.dp,
                setOf(
                    InteractiveState.Focused,
                    RadioBoxStates.Checked,
                ) to 3.0.dp,
            ),
        )
        toggleWidth(24.0.dp)
        toggleHeight(24.0.dp)
        toggleIconHeight(10.0.dp)
        toggleIconWidth(10.0.dp)
        toggleBorderWidth(
            2.0.dp.asStatefulValue(
                setOf(InteractiveState.Focused, RadioBoxStates.Checked) to 1.0.dp,
            ),
        )
        togglePadding(1.0.dp)
        textPadding(12.0.dp)
        descriptionPadding(2.0.dp)
    }
    .style()

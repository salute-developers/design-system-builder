val state = rememberNavigationDrawerState(NavigationDrawerValue.Expanded)
NavigationDrawer(
    state = state,
    header = {
        NavigationDrawerItem(
            modifier = Modifier.fillMaxWidth(),
            selected = false,
            onClick = { },
            icon = {
                Icon(
                    source = resourceImageSource(R.drawable.ic_menu_24),
                    contentDescription = "Menu",
                )
            },
            titleContent = { Text("Menu") },
        )
    },
    footer = {
        NavigationDrawerItem(
            modifier = Modifier.fillMaxWidth(),
            selected = false,
            icon = {
                Avatar(
                    placeholder = AvatarPlaceholder.Name("Michael Scot"),
                ) {
                    AsyncImage(
                        modifier = Modifier.matchParentSize(),
                        contentScale = ContentScale.Crop,
                        model = "https://cdn.costumewall.com/wp-content/uploads/2018/09/michael-scott.jpg",
                        contentDescription = "AsyncAvatar",
                    )
                }
            },
            titleContent = { Text("User") },
        )
    },
) {
    NavigationDrawerItem(
        selected = true,
        icon = { Icon(painterResource(R.drawable.ic_mail_outline_24), "") },
        titleContent = { Text("Inbox") },
        indicator = { Counter(count = "5") },
        onClick = {},
    )
    NavigationDrawerItem(
        icon = { Icon(painterResource(R.drawable.ic_settings_outline_24), "") },
        titleContent = { Text("Settings") },
        onClick = {},
    )
}

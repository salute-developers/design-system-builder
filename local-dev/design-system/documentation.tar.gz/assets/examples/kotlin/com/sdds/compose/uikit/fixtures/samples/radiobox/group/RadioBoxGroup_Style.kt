RadioBoxGroupStyle.builder()
    .radioBoxStyle(/** Стиль компонента */)
    .dimensions {
        itemSpacing(12.0.dp)
    }
    .style()

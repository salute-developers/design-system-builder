Avatar(
    status = AvatarStatus.Active,
    placeholder = AvatarPlaceholder.Name("Michael Scott"),
)

var text by remember { mutableStateOf("") }
MaskedTextField(
    value = text,
    onValueChange = { text = it },
    mask = remember { PhoneMask() }, // маска для телефонных номеров
    placeholderText = "Введите номер телефона",
    labelText = "Номер пользователя",
    focusSelectorSettings = FocusSelectorSettings.None,
)

segment {
    condition { it changes InteractiveState.Selected }
    vector { snapshot -> snapshot pointTo InteractiveState.Selected }
} evaluatesBy {
    colorEvaluator()
}

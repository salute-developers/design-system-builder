var text by remember { mutableStateOf(TextFieldValue()) }
var showDropdown by remember { mutableStateOf(false) }
val filteredList = AutocompleteSuggestions.filterSuggestions(text.text)
val showEmptyState = filteredList.isEmpty()
Autocomplete(
    showDropdown = showDropdown,
    onDismissRequest = { showDropdown = false },
    field = {
        TextField(
            modifier = Modifier.width(240.dp),
            value = text,
            placeholderText = "Сотрудник",
            captionText = "Введите имя",
            onValueChange = {
                text = it
                showDropdown = true
            },
            focusSelectorSettings = FocusSelectorSettings.None,
        )
    },
    showEmptyState = showEmptyState,
    emptyState = {
        EmptyState(
            iconRes = com.sdds.icons.R.drawable.ic_plasma_36,
            description = "Empty State",
            buttonLabel = "Action",
        )
    },
    footer = { Loading() },
    listContent = {
        items(filteredList.size) { index ->
            ListItem(
                modifier = Modifier
                    .fillMaxWidth()
                    .clickable(
                        indication = null,
                        interactionSource = remember { MutableInteractionSource() },
                    ) {
                        text = TextFieldValue(
                            text = filteredList[index],
                            selection = TextRange(filteredList[index].length),
                        )
                        showDropdown = false
                    },
                text = filteredList[index],
            )
        }
    },
)

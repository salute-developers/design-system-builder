WheelStyle.builder()
    .controlIconUp(resourceImageSource(com.sdds.icons.R.drawable.ic_disclosure_up_outline_36))
    .controlIconDown(resourceImageSource(com.sdds.icons.R.drawable.ic_disclosure_down_outline_36))
    .wheelCount(3)
    .visibleItemsCount(3)
    .colors {
        itemTextColor(/** Токен цвета */.asInteractive())
        itemTextAfterColor(/** Токен цвета */.asInteractive())
        descriptionColor(/** Токен цвета */.asInteractive())
        controlIconUpColor(
            /** Токен цвета */.asInteractive(
                setOf(InteractiveState.Focused)
                    to /** Токен цвета в состоянии focused */,
            ),
        )
        controlIconDownColor(
            /** Токен цвета */.asInteractive(
                setOf(InteractiveState.Focused)
                    to /** Токен цвета в состоянии focused */,
            ),
        )
        separatorColor(/** Токен цвета */.asInteractive())
    }
    .itemTextStyle(/** Токен типографики */)
    .itemTextAfterStyle(/** Токен типографики */)
    .descriptionStyle(/** Токен типографики */)
    .dimensions {
        itemTextAfterPadding(2.0.dp)
        descriptionPadding(8.0.dp)
        separatorSpacing(40.0.dp)
        itemMinSpacing(20.0.dp)
    }
    .itemAlignment(WheelAlignment.Center)
    .style()

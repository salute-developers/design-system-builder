CircularProgressBarStyle.builder()
    .colors {
        indicatorColor(
            SolidColor(/** Токен цвета */).asStatefulValue(),
        )
        trackColor(
            SolidColor(/** Токен цвета */).asStatefulValue(),
        )
        valueColor(
            SolidColor(/** Токен цвета */).asStatefulValue(),
        )
    }
    .valueStyle(/** Токен типографики */)
    .dimensions {
        width(128.0.dp)
        height(128.0.dp)
        trackThickness(4.0.dp)
        progressThickness(4.0.dp)
    }
    .style()

var selectedIndex by remember { mutableStateOf(0) }

TabBar {
    repeat(3) { index ->
        tabItem {
            val isSelected = index == selectedIndex
            TabBarItem(
                isSelected = isSelected,
                icon = {
                    AnimatedContent(
                        targetState = isSelected,
                        transitionSpec = {
                            fadeIn(tween(200))
                                .togetherWith(fadeOut(tween(200)))
                        },
                    ) {
                        val iconSource = resourceImageSource(
                            if (it) {
                                getIconSelected(index)
                            } else {
                                getIcon(index)
                            },
                        )
                        Icon(source = iconSource, contentDescription = "")
                    }
                },
                labelContent = { Text(getTitle(index)) },
                onClick = {
                    selectedIndex = index
                },
            )
        }
    }
}

val drawerState = rememberDrawerState(initialValue = DrawerValue.Closed)
val scope = rememberCoroutineScope()
Drawer(
    drawerState = drawerState,
    drawerContent = { Text("Содержимое Drawer") },
) {
    Button(
        label = "Открыть",
        modifier = Modifier.align(Alignment.Center),
        onClick = { scope.launch { drawerState.open() } },
    )
}
LaunchedEffect(Unit) {
    drawerState.open()
}

Image(
    modifier = Modifier
        .width(100.dp)
        .background(Color.Gray),
    painter = painterResource(com.sdds.icons.R.drawable.ic_alarm_done_fill_36),
    contentDescription = "image",
    contentScale = ContentScale.Fit,
    alignment = Alignment.Center,
)

Toast(
    text = "Текст уведомления",
    contentStart = {
        Icon(
            painter = painterResource(com.sdds.icons.R.drawable.ic_shazam_16),
            contentDescription = null,
        )
    },
    contentEnd = {
        Icon(
            painter = painterResource(com.sdds.icons.R.drawable.ic_close_16),
            contentDescription = null,
        )
    },
)

val overlayManager = LocalOverlayManager.current
LaunchedEffect(Unit) {
    repeat(5) {
        overlayManager.showToast(
            position = OverlayPosition.BottomCenter,
        ) {
            composableCodeSnippet {
                Toast(
                    text = "Текст уведомления",
                    contentStart = {
                        Icon(
                            painter = painterResource(com.sdds.icons.R.drawable.ic_shazam_16),
                            contentDescription = null,
                        )
                    },
                    contentEnd = {
                        Icon(
                            painter = painterResource(com.sdds.icons.R.drawable.ic_close_16),
                            contentDescription = null,
                        )
                    },
                )
            }
        }
    }
}

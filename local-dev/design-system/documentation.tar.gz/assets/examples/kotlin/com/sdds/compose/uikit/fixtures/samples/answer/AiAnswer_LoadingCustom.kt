AiAnswer(
    state = AiAnswerState.Loading,
    loading = {
        AiAnswerLoading(text = { Text("Ищем подходящий ответ") })
    },
)

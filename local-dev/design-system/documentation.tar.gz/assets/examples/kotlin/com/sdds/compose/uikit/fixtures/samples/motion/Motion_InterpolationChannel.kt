object IconProgressChannelKey : MotionChannelKey
var expanded by remember { mutableStateOf(false) }
val progress by animateFloatAsState(targetValue = if (expanded) 1f else 0f)

val motionContext = rememberMotionContext {
    interpolationChannel(IconProgressChannelKey) {
        updateInterpolationChannel { progress }
    }
}

var text by remember { mutableStateOf(TextFieldValue("Value")) }
val focusRequester = remember { FocusRequester() }
Editable(
    modifier = Modifier
        .focusRequester(focusRequester),
    value = text,
    onValueChange = { text = it },
    icon = {
        Icon(
            modifier = Modifier
                .clickable(
                    indication = null,
                    interactionSource = remember { MutableInteractionSource() },
                ) {
                    focusRequester.requestFocus()
                    text = text.copy(selection = TextRange(text.text.length))
                },
            painter = painterResource(R.drawable.ic_edit_fill_36),
            contentDescription = null,
        )
    },
    iconPlacement = EditableIconPlacement.Absolute,
    textAlign = TextAlign.Center,
)

ChipGroupStyle.builder()
    .dimensions {
        gap(2.0.dp)
        lineSpacing(2.0.dp)
    }
    .chipStyle(/** Стиль компонента */)
    .style()

ScrollBarStyle.builder()
    .colors {
        trackColor(/** Токен цвета */.asInteractive())
        thumbColor(/** Токен цвета */.asInteractive())
    }
    .shape(CircleShape)
    .hoverExpandFactor(2.0f)
    .dimensions {
        width(4.0.dp)
    }
    .style()

Wheel(
    wheelCount = 1,
    visibleItemsCount = 3,
    onItemSelected = { wheelIndex, itemIndex ->
        println("item selected: $itemIndex in wheel $wheelIndex")
    },
) { wheelIndex ->
    WheelDataSet(
        dataSet = List(10) {
            WheelItemData(
                text = "Label$wheelIndex",
                textAfter = "TA$wheelIndex",
            )
        },
        description = "Description",
    )
}

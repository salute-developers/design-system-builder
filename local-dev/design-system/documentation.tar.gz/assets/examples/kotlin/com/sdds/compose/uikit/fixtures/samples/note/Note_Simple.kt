Note(
    title = "Title",
    text = "Text",
    contentBefore = {
        Icon(
            painter = painterResource(com.sdds.icons.R.drawable.ic_salute_outline_24),
            contentDescription = null,
        )
    },
    action = {
        Button(
            style = LocalLinkButtonStyle.current,
            label = "Label",
            onClick = {},
        )
    },
)

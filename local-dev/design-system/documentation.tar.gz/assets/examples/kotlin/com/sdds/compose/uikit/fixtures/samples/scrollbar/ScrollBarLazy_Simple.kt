val lazyState = rememberLazyListState()
Box {
    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        state = lazyState,
    ) {
        items(100) {
            Text(text = "Item $it")
        }
    }
    ScrollBar(
        modifier = Modifier.align(Alignment.CenterEnd),
        scrollState = lazyState,
        alwaysShowScrollbar = true,
        hasTrack = true,
        hoverExpand = true,
    )
}

AiInput(
    value = text,
    onValueChange = { text = it },
    modifier = Modifier.fillMaxWidth(),
    placeholder = { Text(text = "Введите сообщение") },
    content = {
        File(label = "file.png")
    },
    sendButton = {
        IconButton(iconRes = R.drawable.ic_arrow_up_24, onClick = { /* handle */ })
    },
)

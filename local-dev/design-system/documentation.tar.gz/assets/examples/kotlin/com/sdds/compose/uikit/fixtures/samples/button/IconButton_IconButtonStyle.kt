ButtonStyle.iconButtonBuilder()
    .shape(/** Токен формы (скругления) */)
    .colors {
        backgroundColor(
            Color.White.asInteractive(
                setOf(InteractiveState.Pressed)
                    to /** Цвет в состоянии pressed */,
                setOf(InteractiveState.Hovered)
                    to /** Цвет в состоянии hovered */,
            ),
        )
        spinnerColor(/** Токен цвета */)
        iconColor(/** Токен цвета */)
    }
    .dimensions {
        height(64.0.dp)
        paddingStart(28.0.dp)
        paddingEnd(28.0.dp)
        minWidth(106.0.dp)
        iconSize(24.0.dp)
        spinnerSize(24.0.dp)
        spinnerStrokeWidth(2.0.dp)
    }
    .style()

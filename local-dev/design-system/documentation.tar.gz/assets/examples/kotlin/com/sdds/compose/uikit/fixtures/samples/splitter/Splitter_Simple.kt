Splitter(
    modifier = Modifier,
    orientation = SplitterOrientation.Horizontal,
    hasHandle = true,
)

Avatar(
    status = AvatarStatus.Active,
    actionEnabled = false,
    placeholder = AvatarPlaceholder.Name("Michael Scott"),
)

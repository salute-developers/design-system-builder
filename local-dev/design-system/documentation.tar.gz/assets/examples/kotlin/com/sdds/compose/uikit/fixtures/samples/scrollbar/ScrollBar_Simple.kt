val scrollState = rememberScrollState()
Box {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(scrollState),
    ) {
        repeat(100) {
            Text(text = "Item $it")
        }
    }
    ScrollBar(
        modifier = Modifier.align(Alignment.CenterEnd),
        scrollState = scrollState,
        orientation = Orientation.Vertical,
        alwaysShowScrollbar = true,
        hasTrack = true,
        hoverExpand = false,
    )
}

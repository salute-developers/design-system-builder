EditableStyle.builder()
    .colors {
        iconColor(/** Токен цвета */)
        textColor(/** Токен цвета */)
        cursorColor(/** Токен цвета */)
    }
    .dimensions {
        iconMargin(2.dp)
        iconSize(16.dp)
    }
    .textStyle(/** Токен типографики */)
    .style()

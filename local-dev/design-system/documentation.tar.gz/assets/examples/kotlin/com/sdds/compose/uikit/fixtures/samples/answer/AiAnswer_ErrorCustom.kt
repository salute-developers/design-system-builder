AiAnswer(
    state = AiAnswerState.Error,
    error = {
        AiAnswerError(
            title = { Text("Ответ недоступен") },
            text = { Text("Попробуйте изменить запрос.") },
        )
    },
)

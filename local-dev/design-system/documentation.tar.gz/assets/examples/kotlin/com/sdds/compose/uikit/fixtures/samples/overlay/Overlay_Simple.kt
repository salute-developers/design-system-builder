Overlay(
    modifier = Modifier.fillMaxSize(),
) {
    IconButton(
        modifier = Modifier
            .align(Alignment.TopEnd)
            .padding(end = 8.dp, top = 8.dp),
        iconRes = com.sdds.icons.R.drawable.ic_close_24,
        onClick = {},
    )
}

AiInput(
    value = text,
    onValueChange = { text = it },
    modifier = Modifier.fillMaxWidth(),
    placeholder = { Text(text = "Введите сообщение") },
)

val sheetState = rememberModalBottomSheetState(
    initialValue = BottomSheetValue.Hidden,
)
val scope = rememberCoroutineScope()
Button(
    label = "показать BottomSheet",
    onClick = {
        scope.launch {
            sheetState.show()
        }
    },
)
ModalBottomSheet(
    sheetState = sheetState,
    handlePlacement = BottomSheetHandlePlacement.Inner,
    fitContent = false,
    header = {
        Column {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween,
            ) {
                Text(
                    color = /** Токен цвета */,
                    text = "Заголовок",
                )
                IconButton(
                    iconRes = R.drawable.ic_close_24,
                ) {
                    scope.launch { sheetState.hide() }
                }
            }
            Spacer(modifier = Modifier.padding(6.dp))
            Divider()
            Spacer(modifier = Modifier.padding(6.dp))
        }
    },
    body = {
        var value by remember { mutableStateOf(TextFieldValue("")) }
        TextField(
            modifier = Modifier.fillMaxWidth(),
            value = value,
            labelText = "Лейбл",
            placeholderText = "Введите текст",
            onValueChange = { value = it },
            focusSelectorSettings = FocusSelectorSettings.None,
        )
    },
    footer = {
        Button(
            modifier = Modifier.fillMaxWidth(),
            label = "Сохранить",
            spacing = ButtonSpacing.Packed,
            onClick = {},
        )
    },
)

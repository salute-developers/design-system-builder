val overlayManager = LocalOverlayManager.current

LaunchedEffect(Unit) {
    repeat(5) {
        overlayManager.showToast(
            position = OverlayPosition.BottomCenter,
        ) {
            Toast(
                contentStart = {
                    Icon(
                        painter = painterResource(com.sdds.icons.R.drawable.ic_shazam_16),
                        contentDescription = null,
                    )
                },
            ) {
                Text("First line\nSecond Line")
            }
        }
    }
}

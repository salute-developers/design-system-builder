ModalBottomSheetStyle.builder()
    .shape(/** Токен формы (скругления) */)
    .handleShape(CircleShape)
    .dimensions {
        paddingStart(16.0.dp)
        paddingEnd(16.0.dp)
        paddingTop(16.0.dp)
        paddingBottom(16.0.dp)
        handleHeight(4.0.dp)
        handleWidth(48.0.dp)
        handleOffset(6.0.dp)
    }
    .colors {
        backgroundColor(
            /** Токен цвета */.asInteractive(),
        )
        handleColor(
            /** Токен цвета */.asInteractive(),
        )
    }
    .handlePlacement(BottomSheetHandlePlacement.Auto)
    .style()

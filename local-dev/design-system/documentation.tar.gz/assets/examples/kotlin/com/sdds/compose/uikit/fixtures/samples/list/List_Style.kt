ListStyle.builder()
    .listItemStyle(
        /** Стиль компонента */,
    )
    .style()

Text(
    source = stringSource("Текст со строковым источником"),
    style = TextStyle(fontSize = 16.sp),
)

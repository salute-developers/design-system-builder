val focusRequester = remember { FocusRequester() }
val validCode = "123456"
val invalidChar = "q"
LaunchedEffect(Unit) { focusRequester.requestFocus() }
CodeField(
    modifier = Modifier.focusRequester(focusRequester),
    codeLength = 6,
    hidden = true,
    onCodeComplete = { it == validCode },
    isItemValid = { it != invalidChar },
    caption = "Caption",
    captionAlignment = CodeFieldCaptionAlignment.Center,
)

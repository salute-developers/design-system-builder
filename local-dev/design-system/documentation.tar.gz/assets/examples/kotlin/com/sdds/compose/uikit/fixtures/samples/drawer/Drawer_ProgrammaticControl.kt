val drawerState = rememberDrawerState(initialValue = DrawerValue.Closed)
val scope = rememberCoroutineScope()

Drawer(
    drawerState = drawerState,
    drawerContent = { Text("Контент") },
) {
    Row(Modifier.align(Alignment.Center)) {
        Button(label = "open()", onClick = { scope.launch { drawerState.open() } })
        Spacer(Modifier.width(8.dp))
        Button(label = "close()", onClick = { scope.launch { drawerState.close() } })
        Spacer(Modifier.width(8.dp))
        Button(
            label = "Открыть",
            onClick = { scope.launch { drawerState.snapTo(DrawerValue.Opened) } },
        )
    }
}

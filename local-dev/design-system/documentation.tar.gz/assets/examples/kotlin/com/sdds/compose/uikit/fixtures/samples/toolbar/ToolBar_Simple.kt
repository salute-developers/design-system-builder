ToolBar(
    hasDivider = true,
    orientation = ToolBarOrientation.Horizontal,
) {
    section {
        IconButton(R.drawable.ic_plasma_24) { }
    }
    section {
        IconButton(R.drawable.ic_salute_outline_24) { }
    }
    section {
        Button("Label", {})
    }
}

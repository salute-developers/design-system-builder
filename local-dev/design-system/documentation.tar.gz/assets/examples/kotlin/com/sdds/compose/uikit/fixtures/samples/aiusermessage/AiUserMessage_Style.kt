AiUserMessageStyle.builder()
    .uploadingShape(/** Токен формы (скругления) */)
    .messageShape(/** Токен формы (скругления) */)
    .textStyle(/** Токен типографики */)
    .editableStyle(
        placeholder(
            EditableStyle.builder().style(),
            "/** Стиль редактируемого поля */",
        ),
    )
    .actionsButtonGroupStyle(
        placeholder(
            ButtonGroupStyle.builder().style(),
            "/** Стиль группы кнопок, расположенных внизу */",
        ),
    )
    .editableActionsButtonGroupStyle(
        placeholder(
            ButtonGroupStyle.builder().style(),
            "/** Стиль группы кнопок, отображающихся в режиме редактирования */",
        ),
    )
    .uploadingImageStyle(
        placeholder(
            ImageStyle.builder().style(),
            "/** Стиль загружаемых изображений */",
        ),
    )
    .uploadingFileStyle(
        placeholder(
            FileStyle.builder().style(),
            "/** Стиль загружаемых файлов */",
        ),
    )
    .colors {
        textColor(/** Токен цвета */)
        uploadingBackground(/** Токен цвета */)
        messageBackground(/** Токен цвета */)
    }
    .dimensions {
        uploadingPaddingStart(0.0.dp)
        uploadingPaddingEnd(0.0.dp)
        uploadingPaddingTop(0.0.dp)
        uploadingPaddingBottom(0.0.dp)
        messagePaddingStart(18.0.dp)
        messagePaddingEnd(18.0.dp)
        messagePaddingTop(21.0.dp)
        messagePaddingBottom(21.0.dp)
        uploadingGroupGap(10.0.dp)
        uploadingFilesGap(0.0.dp)
        actionsGap(12.0.dp)
        editableActionsGap(16.0.dp)
    }
    .style()

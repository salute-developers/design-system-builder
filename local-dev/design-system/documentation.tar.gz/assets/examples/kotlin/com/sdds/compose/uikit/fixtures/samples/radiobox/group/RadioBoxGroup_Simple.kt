RadioBoxGroup(
    default = 1,
) { selection ->
    radioBoxItem(key = 1) { key ->
        RadioBox(
            checked = isChecked(selection, key),
            label = "Label",
            description = "Description",
            onClick = { updateSelection(selection, key) },
        )
    }
    radioBoxItem(key = 2) { key ->
        RadioBox(
            checked = isChecked(selection, key),
            label = "Label",
            description = "Description",
            onClick = { updateSelection(selection, key) },
        )
    }
    radioBoxItem(key = 3) { key ->
        RadioBox(
            checked = isChecked(selection, key),
            label = "Label",
            description = "Description",
            onClick = { updateSelection(selection, key) },
        )
    }
}

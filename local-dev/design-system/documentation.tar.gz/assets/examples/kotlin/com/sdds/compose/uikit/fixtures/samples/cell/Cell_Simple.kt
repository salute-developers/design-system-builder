Cell(
    modifier = Modifier
        .focusable(interactionSource = interactionSource)
        .focusSelector(
            settings = LocalFocusSelectorSettings.current,
        ) { isFocused.value },
    title = AnnotatedString("Заголовок"),
    subtitle = AnnotatedString("Подзаголовок"),
    label = AnnotatedString("Лейбл"),
    disclosureContentEnabled = true,
    startContent = {
        Icon(
            painter = painterResource(id = R.drawable.ic_plasma_16),
            contentDescription = "",
        )
    },
    endContent = {
        Icon(
            painter = painterResource(id = R.drawable.ic_plasma_16),
            contentDescription = "",
        )
    },
    interactionSource = interactionSource,
)

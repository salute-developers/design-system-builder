AiAnswer(
    title = { Text("Ответ ассистента") },
    content = {
        Text("SDDS Compose позволяет собрать ответ из обычных composable-слотов.")
    },
    actionsStart = {
        button { IconButton(iconRes = R.drawable.ic_copy_outline_24, onClick = {}) }
        button { IconButton(iconRes = R.drawable.ic_like_outline_24, onClick = {}) }
        button { IconButton(iconRes = R.drawable.ic_dislike_outline_24, onClick = {}) }
    },
    actionsEnd = {
        button { Button(label = "Повторить", onClick = {}) }
    },
    suggestions = {
        Chip(label = "Подробнее", onClick = {})
        Chip(label = "Кратко", onClick = {})
    },
)

Notification(
    hasClose = true,
    closeIcon = painterResource(com.sdds.icons.R.drawable.ic_close_24),
    onClose = { overlayManager.remove(it) },
) {
    NotificationContent(
        modifier = Modifier.fillMaxWidth(),
        title = "Title",
        text = "Notification Text",
        buttons = {
            button { Button(label = "Ok", onClick = {}) }
            button { Button(label = "Cancel", onClick = {}) }
        },
    )
}

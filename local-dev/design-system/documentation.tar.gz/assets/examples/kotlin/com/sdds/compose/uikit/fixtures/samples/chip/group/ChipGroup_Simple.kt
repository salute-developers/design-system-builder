val items: List<String> = List(3) { "label" }
ChipGroup {
    items.forEach {
        var isSelected by remember { mutableStateOf(false) }
        Chip(
            isSelected = isSelected,
            onSelectedChange = { value -> isSelected = value },
            label = it,
            endContent = {
                Icon(
                    painter = painterResource(id = R.drawable.ic_close_24),
                    contentDescription = null,
                )
            },
            enabled = true,
        )
    }
}

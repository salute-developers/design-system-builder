File(
    label = "image.png",
    description = "226 КБ",
    isLoading = true,
    image = {
        Icon(
            painterResource(com.sdds.icons.R.drawable.ic_file_check_fill_36),
            contentDescription = "",
        )
    },
    progress = {
        ProgressBar(progress = 0.4f)
    },
    action = {
        IconButton(
            iconRes = com.sdds.icons.R.drawable.ic_close_36,
            onClick = {},
        )
    },
)

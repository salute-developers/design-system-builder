FormHorizontal {
    repeat(3) {
        FormItem(
            content = { Text("Form Item Content $it") },
            title = { Text("Title $it") },
            titleCaption = { Text("TitleCaption $it") },
            caption = { Text("Caption $it") },
            counter = { Text("Counter $it") },
        )
    }
}

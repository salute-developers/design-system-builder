AvatarStyle.builder()
    .shape(CircleShape)
    .colors {
        backgroundColor(/** Токен градиента */.asStatefulValue())
        textColor(/** Токен градиента */.asStatefulValue())
    }
    .dimensions {
        width(88.0.dp)
        height(88.0.dp)
    }
    .textStyle(/** Токен типографики */)
    .badgeStyle(/** Стиль компонента */)
    .counterStyle(/** Стиль компонента */)
    .statusStyle(
        IndicatorStyle.builder()
            .color {
                backgroundColor(
                    /** Токен цвета */.asInteractive(
                        setOf(AvatarStatus.Active)
                            to /** Цвет в состоянии active */,
                    ),
                )
            }
            .style(),
    )
    .style()

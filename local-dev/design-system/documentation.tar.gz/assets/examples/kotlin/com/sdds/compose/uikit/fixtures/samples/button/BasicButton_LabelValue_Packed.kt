Button(
    label = "Label",
    value = "Value",
    spacing = ButtonSpacing.Packed,
    onClick = {},
)

val text = buildAnnotatedString {
    append("Текст с ")
    withStyle(SpanStyle(color = Color.Red)) {
        append("цветным фрагментом")
    }
}
Text(
    source = annotatedStringSource(text),
    style = TextStyle(fontSize = 16.sp),
)

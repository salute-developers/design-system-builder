TabBarStyle.builder()
    .tabBarItemStyle(
        placeholder(
            TabBarItemStyle.builder().style(),
            "/** Стиль компонента */",
        ),
    )
    .topShape(CircleShape)
    .shadow(/** Токен тени */)
    .colors {
        backgroundColor(/** Цвет фона */)
    }
    .dimensions {
        paddingStart(8.dp)
        paddingEnd(8.dp)
        contentPaddingStart(2.0.dp)
        contentPaddingEnd(2.0.dp)
        contentPaddingTop(2.0.dp)
        contentPaddingBottom(2.0.dp)
        itemSpacing(2.0.dp)
    }
    .style()

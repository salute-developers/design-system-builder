SegmentStyle.builder()
    .segmentItemStyle(/** Стиль компонента */)
    .colors {
        backgroundColor(
            /** Токен цвета */.asInteractive(),
        )
    }
    .shape(
        /** Токен формы(скругления) */.adjustBy(all = -2.0.dp),
    )
    .dimensions {
        paddingStart(2.0.dp)
        paddingEnd(2.0.dp)
        paddingTop(2.0.dp)
        paddingBottom(2.0.dp)
    }
    .style()

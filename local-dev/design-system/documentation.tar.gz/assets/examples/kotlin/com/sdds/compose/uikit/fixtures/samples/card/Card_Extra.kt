Card(
    modifier = Modifier
        .width(350.dp)
        .height(200.dp),
    focusSelectorSettings = LocalFocusSelectorSettings.current,
    extra = {
        Cell(
            modifier = Modifier
                .fillMaxWidth()
                .align(Alignment.TopCenter),
            title = AnnotatedString("Заголовок"),
            subtitle = AnnotatedString("Подзаголовок"),
            startContent = {
                Icon(
                    painter = painterResource(id = R.drawable.ic_camera_video_rec_outline_36),
                    contentDescription = "",
                )
            },
            disclosureText = AnnotatedString("Текст"),
            disclosureContentEnabled = true,
            disclosureIconRes = R.drawable.ic_chevron_right_24,
        )
    },
) {
    Box(modifier = Modifier.fillMaxSize()) {
        Image(
            modifier = Modifier.align(Alignment.Center),
            painter = painterResource(id = R.drawable.ic_video_clip_outline_36),
            colorFilter = placeholder(
                ColorFilter.tint(Color.Black),
                replace = "/** Токен цвета */",
            ),
            contentDescription = "",
        )
    }
}

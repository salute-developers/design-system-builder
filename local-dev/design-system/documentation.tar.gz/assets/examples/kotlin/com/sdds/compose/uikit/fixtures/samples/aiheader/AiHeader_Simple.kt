AiHeader(
    modifier = Modifier.fillMaxWidth(),
    titleContent = { Text(text = "Заголовок") },
)

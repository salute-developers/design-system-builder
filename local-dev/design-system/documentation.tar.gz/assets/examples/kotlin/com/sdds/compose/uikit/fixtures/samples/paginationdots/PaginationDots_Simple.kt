Column {
    var selectedIndex by remember { mutableIntStateOf(0) }
    PaginationDots(
        selectedIndex = selectedIndex,
        totalCount = 11,
        visibleCount = 5,
    )
    Spacer(Modifier.size(16.dp))
    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        IconButton(
            iconRes = com.sdds.icons.R.drawable.ic_arrow_left_24,
            onClick = {
                // для корректной работы необходимо следить, чтобы индекс не выходил за пределы totalCount
                selectedIndex = selectedIndex.minus(1).coerceIn(0, 10)
            },
        )
        IconButton(
            iconRes = com.sdds.icons.R.drawable.ic_arrow_right_24,
            onClick = {
                // для корректной работы необходимо следить, чтобы индекс не выходил за пределы totalCount
                selectedIndex = selectedIndex.plus(1).coerceIn(0, 10)
            },
        )
    }
}

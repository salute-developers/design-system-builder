Cell(
    gravity = CellGravity.Center,
    disclosureContentEnabled = false,
)

AiInput(
    value = text,
    onValueChange = { text = it },
    modifier = Modifier.fillMaxWidth(),
    style = AiInputStyle.builder().mode(AiInputMode.Extended).style(),
    placeholder = { Text(text = "Введите сообщение") },
    startControls = {
        IconButton(iconRes = R.drawable.ic_ai_outline_24, onClick = {})
    },
    sendButton = {
        IconButton(iconRes = R.drawable.ic_arrow_up_24, onClick = {})
    },
)

var checked by remember { mutableStateOf(false) }
val selected = setOf(InteractiveState.Selected)
val itemMotion = rememberSelectItemMotion(
    style = SelectItemMotionStyle.builder()
        .backgroundColor(transition { segment {} changesWith { finite(tween(200)) } })
        .style(),
)
SelectItem(
    motion = itemMotion,
    checked = checked,
    onClick = { checked = !checked },
    modifier = Modifier.fillMaxWidth(),
    style = SelectItemStyle.builder()
        .colors { backgroundColor(Color.Transparent.asStatefulBrush(selected to Color.LightGray)) }
        .dimensions { height(48.dp.asStatefulValue(selected to 56.dp)) }
        .style(),
    titleContent = { Text("Встроенная Cell разделяет контекст строки") },
)

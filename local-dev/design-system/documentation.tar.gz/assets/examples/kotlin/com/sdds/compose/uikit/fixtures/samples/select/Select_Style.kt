SelectStyle.builder()
    .textFieldStyle(
        placeholder(
            TextFieldStyle.builder().style(),
            "/** Стиль компонента */",
        ),
    )
    .buttonStyle(
        placeholder(
            ButtonStyle.basicButtonBuilder().style(),
            "/** Стиль компонента */",
        ),
    )
    .dropdownStyle(
        placeholder(
            DropdownMenuStyle.builder().style(),
            "/** Стиль компонента */",
        ),
    )
    .selectItemStyle(
        placeholder(
            SelectItemStyle.builder().style(),
            "/** Стиль компонента */",
        ),
    )
    .style()

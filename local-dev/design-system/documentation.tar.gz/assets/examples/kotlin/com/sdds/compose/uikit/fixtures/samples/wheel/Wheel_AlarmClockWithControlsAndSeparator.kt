Wheel(
    wheelCount = 2,
    visibleItemsCount = 3,
    hasControls = true,
    wheelSeparator = WheelSeparator.Dots,
    alignment = WheelAlignment.Mixed,
    onItemSelected = { wheelIndex, itemIndex ->
        println("item selected: $itemIndex in wheel $wheelIndex")
    },
) { wheelIndex ->
    return@Wheel when (wheelIndex) {
        0 -> {
            WheelDataSet(
                dataSet = List(24) {
                    WheelItemData(
                        text = "${it + 1}",
                        textAfter = "ч.",
                    )
                },
                description = "Часы",
            )
        }
        else -> {
            WheelDataSet(
                dataSet = List(60) {
                    WheelItemData(
                        text = "${it + 1}",
                        textAfter = "мин.",
                    )
                },
                description = "Минуты",
            )
        }
    }
}

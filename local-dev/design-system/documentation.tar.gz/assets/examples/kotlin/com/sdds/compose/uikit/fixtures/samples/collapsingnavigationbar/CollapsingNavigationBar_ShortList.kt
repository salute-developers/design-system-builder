val listState = rememberLazyListState()
val scrollBehavior =
    CollapsingNavigationBarDefaults.exitUntilCollapsedScrollBehavior(
        state = rememberCollapsingNavigationBarState(),
        canScroll = {
            listState.canScrollForward || listState.canScrollBackward
        },
    )

Column(
    modifier = Modifier.nestedScroll(scrollBehavior.nestedScrollConnection),
) {
    CollapsingNavigationBar(
        scrollBehavior = scrollBehavior,
        collapsedTitle = { Text("Title") },
        expandedTitle = { Text("Title") },
    )
    LazyColumn(
        state = listState,
    ) {
        items(3) {
            Text(modifier = Modifier.padding(32.dp), text = "Label text $it")
        }
    }
}

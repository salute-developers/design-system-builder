var checked by remember { mutableStateOf(false) }
val itemMotion = rememberSelectItemMotion()
SelectItem(
    motion = itemMotion,
    checked = checked,
    onClick = { checked = !checked },
    content = {
        Cell(
            motion = rememberCellMotion(motionContext = itemMotion.context),
            titleContent = { Text("Общий контекст передан явно") },
        )
    },
)

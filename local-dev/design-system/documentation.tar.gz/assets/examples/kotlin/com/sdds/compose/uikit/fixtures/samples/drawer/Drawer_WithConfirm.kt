val canClose = remember { mutableStateOf(false) }
val drawerState = rememberDrawerState(
    initialValue = DrawerValue.Closed,
    confirmStateChange = { target ->
        // Разрешаем закрытие только если canClose == true
        if (target == DrawerValue.Closed) canClose.value else true
    },
)
val scope = rememberCoroutineScope()

Drawer(
    drawerState = drawerState,
    drawerContent = {
        Column(Modifier.padding(16.dp)) {
            var active by remember { mutableStateOf(false) }
            Text("Чтобы закрыть панель, включите переключатель")
            Switch(active = active, onActiveChanged = { active = it })
            Spacer(Modifier.height(12.dp))
            Button(
                label = "Закрыть программно",
                onClick = { scope.launch { drawerState.close() } },
            )
        }
    },
) {
    Button(
        label = "Открыть",
        modifier = Modifier.align(Alignment.Center),
        onClick = { scope.launch { drawerState.open() } },
    )
}

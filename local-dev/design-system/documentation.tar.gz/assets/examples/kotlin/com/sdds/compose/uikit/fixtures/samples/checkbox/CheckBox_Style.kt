CheckBoxStyle.builder()
    .colorValues {
        labelColor(/** Токен цвета */.asInteractive())
        descriptionColor(/** Токен цвета */.asInteractive())
        toggleColor(
            /** Токен цвета */.asInteractive(
                setOf(CheckBoxStates.Checked)
                    to /** Цвет в состоянии Checked */,
                setOf(CheckBoxStates.Indeterminate)
                    to /** Цвет в состоянии Indeterminate */,
                setOf(CheckBoxStates.Error)
                    to /** Цвет в состоянии Error */,
            ),
        )
        toggleIconColor(/** Токен цвета */.asInteractive())
        toggleBorderColor(
            /** Токен цвета */.asInteractive(
                setOf(InteractiveState.Focused, CheckBoxStates.Checked)
                    to /** Цвет в состоянии Checked */,
            ),
        )
    }
    .shape(/** Токен формы (скругления) */)
    .labelStyle(/** Токен типографики */)
    .descriptionStyle(/** Токен типографики */)
    .dimensionValues {
        toggleWidth(24.0.dp)
        toggleHeight(24.0.dp)
        toggleIconHeight(
            0.0.dp.asStatefulValue(
                setOf(CheckBoxStates.Checked) to 6.0.dp,
                setOf(CheckBoxStates.Indeterminate) to
                    2.0.dp,
            ),
        )
    }
    .style()

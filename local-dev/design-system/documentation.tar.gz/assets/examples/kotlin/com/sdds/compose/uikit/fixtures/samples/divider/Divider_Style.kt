DividerStyle.builder()
    .shape(CircleShape)
    .color {
        backgroundColor(/** Токен цвета */.asInteractive())
    }
    .dimensions {
        thickness(1.0.dp)
    }
    .style()

CardStyle.builder()
    .colors {
        backgroundColor(
            Color.Black.asInteractive(/** Токен цвета */),
        )
    }
    .shape(/** Токен формы (скругления) */)
    .contentShape(/** Токен формы (скругления) */)
    .dimensions {
        paddingTop(12.0.dp)
        paddingBottom(12.0.dp)
        paddingStart(12.0.dp)
        paddingEnd(12.0.dp)
    }
    .style()

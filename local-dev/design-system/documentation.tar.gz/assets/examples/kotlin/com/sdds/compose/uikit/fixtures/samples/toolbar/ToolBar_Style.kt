ToolBarStyle.builder()
    .shadow(/** Токен тени */)
    .shape(/** Токен формы(скругления) */)
    .dividerStyle(/** Стиль разделителя */)
    .orientation(ToolBarOrientation.Horizontal)
    .dimensions {
        dividerMargin(4.dp)
        sectionPadding(4.dp)
        paddingStart(8.dp)
        paddingEnd(8.dp)
        paddingTop(8.dp)
        paddingBottom(8.dp)
    }
    .colors {
        backgroundColor(SolidColor(Color.White))
    }
    .style()

ProvideTextStyle(TextStyle(fontSize = 20.sp), color = { Color.Gray }) {
    Column {
        Text(source = stringSource("Заголовок"))
        Text(source = stringSource("Описание"))
    }
}

val sheetState = rememberModalBottomSheetState(
    initialValue = BottomSheetValue.Hidden,
)
ModalBottomSheet(
    sheetState = sheetState,
    handlePlacement = BottomSheetHandlePlacement.Inner,
    fitContent = false,
    body = { Text("Text") },
)

val showPopover = remember { mutableStateOf(false) }
val triggerInfo = remember { mutableStateOf(TriggerInfo()) }
Button(
    modifier = Modifier
        .popoverTrigger(triggerInfo),
    label = "show",
    onClick = { showPopover.value = true },
)
Popover(
    show = showPopover.value,
    triggerInfo = triggerInfo.value,
    placement = PopoverPlacement.Top,
    placementMode = PopoverPlacementMode.Loose,
    triggerCentered = false,
    alignment = PopoverAlignment.Start,
    onDismissRequest = {
        showPopover.value = false
    },
    duration = 3000,
) {
    Column(
        modifier = Modifier
            .padding(top = 12.dp, bottom = 8.dp, start = 8.dp, end = 8.dp),
    ) {
        Text("Title")
        Spacer(Modifier.height(4.dp))
        Text("Description")
    }
}

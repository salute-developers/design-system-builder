var value by remember { mutableStateOf(TextFieldValue("")) }
TextField(
    value = value,
    captionText = "Надпись",
    labelText = "Заголовок",
    placeholderText = "Введите текст",
    onValueChange = { value = it },
    startContent = {
        Icon(
            painter = painterResource(id = com.sdds.icons.R.drawable.ic_shazam_24),
            contentDescription = "",
            tint = Color.Black,
        )
    },
    chipsContent = { repeat(3) { Chip(label = "Чип") } },
    focusSelectorSettings = FocusSelectorSettings.None,
)

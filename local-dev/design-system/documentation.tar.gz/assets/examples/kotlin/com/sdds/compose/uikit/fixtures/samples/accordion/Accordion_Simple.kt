Accordion {
    repeat(4) {
        var opened by remember { mutableStateOf(false) }
        AccordionItem(
            opened = opened,
            onClick = { opened = !opened },
            title = "Title $it",
        ) { Text(text = "Content text $it") }
    }
}

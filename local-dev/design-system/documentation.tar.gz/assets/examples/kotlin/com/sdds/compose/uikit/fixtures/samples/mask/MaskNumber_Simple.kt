var text by remember { mutableStateOf("") }
MaskedTextField(
    value = text,
    onValueChange = { text = it },
    mask = remember { NumberMask() }, // Настройки по-умолчанию
    placeholderText = "Введите сумму",
    suffix = "млн. руб",
    focusSelectorSettings = FocusSelectorSettings.None,
)

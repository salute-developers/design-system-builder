var selectedIndex by remember { mutableStateOf(0) }

TabBar {
    tabItem {
        val isSelected = selectedIndex == 0
        TabBarItem(
            isSelected = isSelected,
            icon = { TabIcon(0, isSelected) },
            labelContent = { Text(getTitle(0)) },
            onClick = { selectedIndex = 0 },
        )
    }
    tabItem(weight = null) {
        Icon(
            modifier = Modifier
                .size(36.dp)
                .clickable { selectedIndex = 1 },
            source = resourceImageSource(R.drawable.ic_sb_36),
            contentDescription = null,
        )
    }
    tabItem {
        val isSelected = selectedIndex == 2
        TabBarItem(
            isSelected = isSelected,
            icon = { TabIcon(2, isSelected) },
            labelContent = { Text(getTitle(2)) },
            onClick = { selectedIndex = 2 },
        )
    }
}

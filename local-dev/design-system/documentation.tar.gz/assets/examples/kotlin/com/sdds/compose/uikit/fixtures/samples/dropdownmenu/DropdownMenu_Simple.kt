val showDropdownMenu = remember { mutableStateOf(false) }
val triggerInfo = remember { mutableStateOf(TriggerInfo()) }
Button(
    modifier = Modifier.popoverTrigger(triggerInfo),
    label = "Show dropdown menu",
    onClick = { showDropdownMenu.value = true },
)
DropdownMenu(
    opened = showDropdownMenu.value,
    onDismissRequest = {
        showDropdownMenu.value = false
    },
    triggerInfo = triggerInfo.value,
    placement = PopoverPlacement.Bottom,
    placementMode = PopoverPlacementMode.Loose,
    alignment = PopoverAlignment.Center,
) {
    List(
        modifier = Modifier
            .width(200.dp)
            .height(300.dp),
    ) {
        item {
            ListItem(
                text = "Item title 2",
                disclosureEnabled = true,
            )
        }
        item {
            Divider()
        }
        item {
            ListItem(
                text = "Item title 2",
                disclosureEnabled = true,
            )
        }
    }
}

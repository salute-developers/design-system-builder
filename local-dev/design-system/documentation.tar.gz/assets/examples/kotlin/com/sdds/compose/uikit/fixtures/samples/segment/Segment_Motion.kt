var expanded by remember { mutableStateOf(false) }
val selectedState = setOf(InteractiveState.Selected)
val style = SegmentStyle.builder()
    .colors { backgroundColor(Color.LightGray.asStatefulBrush(selectedState to Color.Gray)) }
    .dimensions { gap(4.dp.asStatefulValue(selectedState to 16.dp)) }
    .style()
val motion = rememberSegmentMotion(
    style = SegmentMotionStyle.builder()
        .gap(transition { segment {} changesWith { finite(tween(200)) } })
        .backgroundColor(transition { segment {} changesWith { finite(tween(200)) } })
        .style(),
)
SegmentHorizontal(
    motion = motion,
    style = style,
    stretch = false,
    modifier = Modifier
        .selection(expanded, motion.context.semanticStateSource)
        .clickable(interactionSource = motion.context.interactionSource, indication = null) {
            expanded = !expanded
        },
) {
    segmentItem { SegmentItem(label = "Первый", isSelected = true) }
    segmentItem { SegmentItem(label = "Второй") }
}

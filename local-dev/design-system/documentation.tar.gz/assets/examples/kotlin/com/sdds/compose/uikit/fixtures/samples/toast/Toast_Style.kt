ToastStyle.builder()
    .shape(/** Токен формы(скругления) */)
    .textStyle(/** Токен типографики */)
    .dimensions {
        contentStartSize(16.0.dp)
        contentStartPadding(4.0.dp)
        contentEndSize(16.0.dp)
        contentEndPadding(4.0.dp)
        paddingStart(8.dp)
        paddingEnd(8.dp)
        paddingTop(8.dp)
        paddingBottom(8.dp)
    }
    .colors {
        backgroundColor(SolidColor(Color.Black))
        textColor(Color.LightGray)
        contentStartColor(Color.LightGray)
        contentEndColor(Color.LightGray)
    }
    .style()

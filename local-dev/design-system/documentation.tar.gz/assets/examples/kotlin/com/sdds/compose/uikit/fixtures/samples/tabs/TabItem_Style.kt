TabItemStyle.builder()
    .colors {
        labelColor(
            /** Токен цвета */.asStatefulValue(
                setOf(InteractiveState.Selected, InteractiveState.Pressed)
                    to /** Цвет в состоянии selected + pressed */,
                setOf(InteractiveState.Selected, InteractiveState.Hovered)
                    to /** Цвет в состоянии selected + hovered */,
                setOf(InteractiveState.Hovered)
                    to /** Цвет в состоянии hovered */,
                setOf(InteractiveState.Pressed)
                    to /** Цвет в состоянии pressed */,
                setOf(InteractiveState.Selected)
                    to /** Цвет в состоянии selected */,
            ),
        )
        valueColor(
            /** Токен цвета */.asStatefulValue(
                setOf(InteractiveState.Selected, InteractiveState.Pressed)
                    to /** Цвет в состоянии selected + pressed */,
                setOf(InteractiveState.Selected, InteractiveState.Hovered)
                    to /** Цвет в состоянии selected + hovered */,
                setOf(InteractiveState.Hovered)
                    to /** Цвет в состоянии hovered */,
                setOf(InteractiveState.Pressed)
                    to /** Цвет в состоянии pressed */,
                setOf(InteractiveState.Selected)
                    to /** Цвет в состоянии selected */,
            ),
        )
        startContentColor(
            /** Токен цвета */.asStatefulValue(
                setOf(InteractiveState.Selected, InteractiveState.Pressed)
                    to /** Цвет в состоянии selected + pressed */,
                setOf(InteractiveState.Selected, InteractiveState.Hovered)
                    to /** Цвет в состоянии selected + hovered */,
                setOf(InteractiveState.Hovered)
                    to /** Цвет в состоянии hovered */,
                setOf(InteractiveState.Pressed)
                    to /** Цвет в состоянии pressed */,
                setOf(InteractiveState.Selected)
                    to /** Цвет в состоянии selected */,
            ),
        )
        endContentColor(
            /** Токен цвета */.asStatefulValue(
                setOf(InteractiveState.Selected, InteractiveState.Pressed)
                    to /** Цвет в состоянии selected + pressed */,
                setOf(InteractiveState.Selected, InteractiveState.Hovered)
                    to /** Цвет в состоянии selected + hovered */,
                setOf(InteractiveState.Hovered)
                    to /** Цвет в состоянии hovered */,
                setOf(InteractiveState.Pressed)
                    to /** Цвет в состоянии pressed */,
                setOf(InteractiveState.Selected)
                    to /** Цвет в состоянии selected */,
            ),
        )
        actionColor(
            /** Токен цвета */.asStatefulValue(
                setOf(InteractiveState.Hovered)
                    to /** Цвет в состоянии hovered */,
                setOf(InteractiveState.Pressed)
                    to /** Цвет в состоянии pressed */,
            ),
        )
    }
    .disableAlpha(0.4f)
    .labelStyle(/** Токен типографики */)
    .valueStyle(/** Токен типографики */)
    .dimensions {
        paddingStart(0.0.dp)
        paddingEnd(0.0.dp)
        minHeight(56.0.dp)
        startContentSize(24.0.dp)
        endContentSize(24.0.dp)
        counterPadding(8.0.dp)
        valuePadding(8.0.dp)
        actionPadding(10.0.dp)
    }
    .counterStyle(/** Стиль компонента */)
    .actionIcon(resourceImageSource(R.drawable.ic_close_24))
    .style()

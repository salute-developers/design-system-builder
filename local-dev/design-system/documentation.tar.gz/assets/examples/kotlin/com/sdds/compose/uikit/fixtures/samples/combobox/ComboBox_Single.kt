val comboBoxList = comboBoxSampleList()
val state = remember { SelectState(initialState = true) }
val checkedStateManager = rememberSelectSingleDataStateManager(comboBoxList)
var value by remember { mutableStateOf("") }
val filteredList = remember(value, state.isOpened) {
    comboBoxList.filteredBy(value, state.isOpened)
}

ComboBox(
    state = state,
    trigger = {
        ComboBoxTextField(
            modifier = Modifier.width(260.dp),
            value = value,
            onValueChange = { value = it },
            placeholderText = if (value.isEmpty()) "Сотрудник" else null,
            captionText = "Введите или выберите имя",
            iconOpened = R.drawable.ic_chevron_up_24,
            iconClosed = R.drawable.ic_chevron_down_24,
            startContent = {
                Icon(
                    painterResource(R.drawable.ic_search_24),
                    "",
                )
            },
        )
    },
    showEmptyState = filteredList.isEmpty(),
    emptyState = {
        EmptyState(
            iconRes = R.drawable.ic_plasma_36,
            description = "Empty State",
        )
    },
    listContent = {
        items(filteredList.size) {
            val item = filteredList[it]
            SelectItem(
                modifier = Modifier.fillMaxWidth(),
                checked = checkedStateManager.isSelected(item),
                onClick = {
                    checkedStateManager.onItemPressed(item)
                    value = item
                    state.close()
                },
            ) {
                Cell(
                    title = AnnotatedString(item),
                    disclosureIconRes = null,
                )
            }
        }
    },
)

val style = remember {
    BlurStyle.create(
        blurRadius = // Радиус размытия в dp,
        tint = // Токен цвета. Цвет должен быть с альфа-каналом,
    )
}

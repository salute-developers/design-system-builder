var text by remember { mutableStateOf("") }
MaskedTextField(
    value = text,
    onValueChange = { text = it },
    mask = remember { TimeMask() }, // Настройки по-умолчанию ЧЧ:ММ
    placeholderText = "Введите дату рождения",
    focusSelectorSettings = FocusSelectorSettings.None,
)

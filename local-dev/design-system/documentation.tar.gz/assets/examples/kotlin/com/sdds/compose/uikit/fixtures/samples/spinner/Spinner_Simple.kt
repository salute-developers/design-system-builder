Spinner(
    modifier = Modifier,
    interactionSource = remember { MutableInteractionSource() },
)

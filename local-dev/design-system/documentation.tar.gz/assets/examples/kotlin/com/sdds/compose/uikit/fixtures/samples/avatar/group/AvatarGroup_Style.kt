AvatarGroupStyle.builder()
    .avatarStyle(/** Стиль компонента */)
    .dimensions {
        itemSpacing(2.0.dp)
        itemOffset(16.0.dp)
    }
    .style()

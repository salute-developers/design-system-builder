CollapsingNavigationBarStyle.builder()
    .shadow(/** Токен тени */)
    .bottomShape(/** Токен формы(скругления) */)
    .titleStyle(/** Токен типографки */.asStatefulValue())
    .descriptionStyle(/** Токен типографки */.asStatefulValue())
    .backIcon(resourceImageSource(R.drawable.ic_disclosure_left_outline_24))
    .colors {
        backIconColor(/** Токен цвета */.asStatefulValue())
        titleColor(/** Токен цвета */.asStatefulValue())
        descriptionColor(/** Токен цвета */.asStatefulValue())
        actionStartColor(/** Токен цвета */.asStatefulValue())
        actionEndColor(/** Токен цвета */.asStatefulValue())
        backgroundColor(/** Токен цвета */.asStatefulValue())
    }
    .dimensions {
        paddingStart(20.0.dp)
        paddingEnd(20.0.dp)
        paddingTop(20.0.dp)
        paddingBottom(20.0.dp)
        backIconMargin(4.0.dp)
        textBlockTopMargin(16.0.dp)
        horizontalSpacing(16.0.dp)
        descriptionPadding(
            12.dp.asStatefulValue(
                setOf(CollapsingNavigationBarStates.Collapsed) to 4.dp,
            ),
        )
    }
    .style()

Icon(
    source = { painterResource(com.sdds.icons.R.drawable.ic_alarm_done_fill_36) },
    contentDescription = "Иконка из Painter",
)

ButtonGroup(
    orientation = ButtonGroupOrientation.Horizontal,
) {
    button {
        IconButton(
            iconRes = R.drawable.ic_plasma_24,
            onClick = {},
        )
    }
    button {
        IconButton(
            iconRes = R.drawable.ic_plasma_24,
            onClick = {},
        )
    }
    button {
        IconButton(
            iconRes = R.drawable.ic_plasma_24,
            onClick = {},
        )
    }
}

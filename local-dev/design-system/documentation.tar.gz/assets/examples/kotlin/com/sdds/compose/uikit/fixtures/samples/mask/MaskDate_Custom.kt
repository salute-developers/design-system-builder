var text by remember { mutableStateOf("") }
MaskedTextField(
    value = text,
    onValueChange = { text = it },
    mask = remember {
        DateMask(
            pattern = listOf("ММ", "ГГ"), // оставляем только месяц и год
            separator = '_', // используем кастомный разделитель
        )
    },
    placeholderText = "Введите дату рождения",
    focusSelectorSettings = FocusSelectorSettings.None,
)

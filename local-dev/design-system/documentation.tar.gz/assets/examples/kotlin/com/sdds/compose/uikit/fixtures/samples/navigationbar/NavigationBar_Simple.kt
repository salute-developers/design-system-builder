NavigationBar(
    textPlacement = NavigationBarTextPlacement.Inline,
    textContent = { Text("Text") },
    actionStart = {
        Icon(
            modifier = Modifier.clickable { /* действие */ },
            painter = painterResource(com.sdds.icons.R.drawable.ic_search_24),
            contentDescription = "",
        )
    },
    actionEnd = {
        Icon(
            modifier = Modifier.clickable { /* действие */ },
            painter = painterResource(com.sdds.icons.R.drawable.ic_menu_24),
            contentDescription = "",
        )
    },
)

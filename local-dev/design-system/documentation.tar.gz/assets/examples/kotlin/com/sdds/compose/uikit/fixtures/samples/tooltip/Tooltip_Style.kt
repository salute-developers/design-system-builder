TooltipStyle.builder()
    .shadow(/** Токен тени */)
    .shape(/** Токен формы(скругления) */)
    .dimensions {
        offset(8.0.dp)
        tailWidth(20.0.dp)
        tailHeight(8.0.dp)
        tailPadding(20.0.dp)
        contentStartSize(16.dp)
        contentStartPadding(4.dp)
        paddingStart(8.dp)
        paddingEnd(8.dp)
        paddingTop(8.dp)
        paddingBottom(8.dp)
    }
    .colors {
        backgroundColor(SolidColor(Color.Gray))
        textColor(SolidColor(Color.Black))
        contentStartColor(Color.Black)
    }
    .style()

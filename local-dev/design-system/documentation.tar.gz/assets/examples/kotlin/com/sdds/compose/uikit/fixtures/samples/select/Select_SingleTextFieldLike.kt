val selectList = listOf(
    "Иван Иванов",
    "Пётр Петров",
    "Сергей Сергеев",
)
val state = remember { SelectState(initialState = true) }
val checkedStateManager = rememberSelectSingleDataStateManager(selectList, selectList[0])

Select(
    state = state,
    trigger = {
        SelectTextField(
            modifier = Modifier.width(260.dp),
            value = checkedStateManager.selectedItems.firstOrNull().orEmpty(),
            placeholderText = "Сотрудник",
            iconOpened = com.sdds.icons.R.drawable.ic_chevron_up_24,
            iconClosed = com.sdds.icons.R.drawable.ic_chevron_down_24,
            startContent = {
                Icon(
                    painterResource(R.drawable.ic_search_24),
                    "",
                )
            },
        )
    },
    listContent = {
        items(selectList.size) {
            SelectItem(
                modifier = Modifier.fillMaxWidth(),
                checked = checkedStateManager.isSelected(selectList[it]),
                onClick = { checkedStateManager.onItemPressed(selectList[it]) },
            ) {
                Cell(
                    title = AnnotatedString(selectList[it]),
                    disclosureIconRes = null,
                )
            }
        }
    },
)

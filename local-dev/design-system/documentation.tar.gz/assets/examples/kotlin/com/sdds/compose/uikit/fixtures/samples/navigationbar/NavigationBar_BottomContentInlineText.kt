NavigationBar(
    textPlacement = NavigationBarTextPlacement.Inline,
    contentPlacement = NavigationBarContentPlacement.Bottom,
    textAlign = NavigationBarTextAlign.Start,
    textContent = { Text("Text") },
    content = { Text("Content") },
    actionEnd = {
        Icon(
            modifier = Modifier.clickable { /* действие */ },
            painter = painterResource(com.sdds.icons.R.drawable.ic_menu_24),
            contentDescription = "",
        )
    },
)

Column(
    verticalArrangement = Arrangement.spacedBy(8.dp),
) {
    Text(text = "Text")
    Box {
        val showTooltip = remember { mutableStateOf(false) }
        val triggerInfo = remember { mutableStateOf(TriggerInfo()) }
        Button(
            modifier = Modifier
                .popoverTrigger(triggerInfo),
            label = "show",
            onClick = { showTooltip.value = true },
        )
        Tooltip(
            show = showTooltip.value,
            triggerInfo = { triggerInfo.value },
            placement = PopoverPlacement.Top,
            placementMode = PopoverPlacementMode.Loose,
            triggerCentered = false,
            alignment = PopoverAlignment.Start,
            onDismissRequest = {
                showTooltip.value = false
            },
            duration = 3000,
            text = AnnotatedString("Tooltip Text"),
        )
    }
}

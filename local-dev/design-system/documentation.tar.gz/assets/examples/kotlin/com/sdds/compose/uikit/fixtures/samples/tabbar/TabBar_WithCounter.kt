var selectedIndex by remember { mutableStateOf(0) }

TabBar {
    repeat(3) { index ->
        tabItem {
            val isSelected = index == selectedIndex
            TabBarItem(
                isSelected = isSelected,
                icon = { TabIcon(index, isSelected) },
                labelContent = { Text(getTitle(index)) },
                extra = if (index == 2) {
                    { Counter(count = "3") }
                } else {
                    null
                },
                onClick = {
                    selectedIndex = index
                },
            )
        }
    }
}

val showModal = remember { mutableStateOf(false) }
Button(
    label = "Show modal",
    onClick = { showModal.value = true },
)
Modal(
    show = showModal.value,
    onDismissRequest = { showModal.value = false },
    modifier = Modifier.width(300.dp),
    hasClose = true,
    closeIcon = painterResource(com.sdds.icons.R.drawable.ic_close_24),
    dimBackground = true,
    useNativeBlackout = true,
) {
    Column {
        Text("Заголовок")
        Spacer(modifier = Modifier.padding(8.dp))
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.Center,
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Button(
                    modifier = Modifier.align(Alignment.CenterVertically),
                    label = "Ок",
                    onClick = {
                        showModal.value = false
                    },
                )
                Button(
                    modifier = Modifier.align(Alignment.CenterVertically),
                    label = "Отмена",
                    onClick = {
                        showModal.value = false
                    },
                )
            }
        }
    }
}

SegmentItemStyle.builder()
    .colors {
        labelColor(
            /** Цвет токена */.asInteractive(
                setOf(InteractiveState.Hovered)
                    to /** Цвет в состоянии hovered */,
            ),
        )
        valueColor(
            /** Токен типографики */.asInteractive(
                setOf(InteractiveState.Hovered)
                    to /** Цвет в состоянии hovered */,
            ),
        )
        backgroundColor(
            /** Токен типографики */.asInteractive(
                setOf(InteractiveState.Hovered)
                    to /** Цвет в состоянии hovered */,
            ),
        )
        startContentColor(
            /** Цвет токена */.asInteractive(
                setOf(InteractiveState.Hovered)
                    to /** Цвет в состоянии hovered */,
            ),
        )
        endContentColor(
            /** Цвет токена */.asInteractive(
                setOf(InteractiveState.Hovered)
                    to /** Цвет в состоянии hovered */,
            ),
        )
    }
    .shape(/** Токе формы(скругления) */.adjustBy(all = 0.0.dp))
    .labelStyle(/** Токен типографики */)
    .valueStyle(/** Токен типографики */)
    .dimensions {
        minWidth(110.0.dp)
        minHeight(64.0.dp)
        paddingStart(28.0.dp)
        paddingEnd(28.0.dp)
        startContentSize(24.0.dp)
        endContentSize(24.0.dp)
        valueMargin(6.0.dp)
    }
    .counterStyle(/** Стиль компонента */)
    .style()

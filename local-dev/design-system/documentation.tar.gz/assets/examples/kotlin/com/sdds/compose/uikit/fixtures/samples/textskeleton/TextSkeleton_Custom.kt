TextSkeleton(
    textStyle = /** Токен стиля текста */,
    lineCount = 5,
    lineWidthProvider = SkeletonLineWidthProvider.RandomDeviation(),
    brush = /** Токен градиента */,
    duration = 1000,
    shape = /** Токен формы(скругления) */,
)

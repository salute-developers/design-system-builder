CompositionLocalProvider(LocalIconDefaultSize provides DpSize(24.dp, 24.dp)) {
    Icon(
        source = resourceImageSource(com.sdds.icons.R.drawable.ic_alarm_done_fill_36),
        contentDescription = null,
    )
}

SwitchStyle.builder()
    .toggleTrackShape(CircleShape)
    .toggleThumbShape(CircleShape)
    .colorValues {
        labelColor(/** Токен цвета */.asInteractive())
        descriptionColor(/** Токен цвета */.asInteractive())
        toggleTrackColor(
            /** Токен цвета */.asInteractive(
                setOf(SwitchStates.Checked)
                    to /** Цвет в состоянии checked */,
            ),
        )
        toggleTrackBorderColor(/** Токен цвета */.asInteractive())
        toggleThumbColor(/** Токен цвета */.asInteractive())
    }
    .labelStyle(/** Токен типографики */)
    .descriptionStyle(/** Токен типографики */)
    .dimensionValues {
        toggleTrackWidth(44.0.dp)
        toggleTrackHeight(28.0.dp)
        toggleThumbWidth(24.0.dp)
        toggleThumbHeight(24.0.dp)
        textPadding(12.0.dp)
        descriptionPadding(4.0.dp)
    }
    .style()

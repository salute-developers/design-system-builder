AccordionItemStyle.builder()
    .iconPlacement(AccordionIconPlacement.End)
    .iconRotation(90.0f)
    .shape(/** Токен формы (скругления) */)
    .titleStyle(/** Токен типографики */)
    .contentTextStyle(/** Токен типографики */)
    .colors {
        backgroundColor(
            Color.White.asInteractive(
                setOf(InteractiveState.Pressed)
                    to /** Цвет в состоянии pressed */,
            ),
        )
        titleColor(
            Color.LightGray.asInteractive(
                setOf(InteractiveState.Hovered)
                    to /** Цвет в состоянии hovered */,
            ),
        )
        contentTextColor(
            Color.LightGray.asInteractive(
                setOf(InteractiveState.Hovered)
                    to /** Цвет в состоянии hovered */,
            ),
        )
    }
    .dimensions {
        contentPaddingStart(12.0.dp)
        contentPaddingEnd(12.0.dp)
        contentPaddingBottom(10.0.dp)
        paddingStart(12.0.dp)
        paddingEnd(12.0.dp)
        paddingTop(8.0.dp)
        paddingBottom(8.0.dp)
        iconPadding(10.0.dp)
    }
    .iconClosed(resourceImageSource(com.sdds.icons.R.drawable.ic_plus_16))
    .iconOpened(resourceImageSource(com.sdds.icons.R.drawable.ic_minus_16))
    .style()

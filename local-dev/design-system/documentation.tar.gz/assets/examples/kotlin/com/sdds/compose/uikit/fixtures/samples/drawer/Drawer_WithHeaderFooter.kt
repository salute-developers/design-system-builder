val drawerState = rememberDrawerState(initialValue = DrawerValue.Opened)
val scope = rememberCoroutineScope()
val items = listOf(
    R.drawable.ic_mail_outline_24 to "Пример текста",
    R.drawable.ic_star_outline_24 to "Пример текста",
    R.drawable.ic_settings_outline_24 to "Пример текста",
    R.drawable.ic_tag_badge_outline_24 to "Пример текста",
    R.drawable.ic_folder_outline_24 to "Пример текста",
)
Column {
    Drawer(
        drawerState = drawerState,
        openOnFocus = false,
        drawerHeader = {
            Row(
                modifier = Modifier.padding(8.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Avatar(
                    status = AvatarStatus.Active,
                    placeholder = AvatarPlaceholder.Name("Michael Scott"),
                )
                Text("Заголовок", modifier = Modifier.padding(16.dp))
            }
            Divider()
        },
        drawerFooter = {
            Divider(modifier = Modifier.padding(top = 48.dp))
            Button(
                label = "Выйти",
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(16.dp),
                spacing = ButtonSpacing.Packed,
                onClick = { scope.launch { drawerState.close() } },
            )
        },
        drawerContent = {
            Column {
                items.forEachIndexed { index, item ->
                    Row(
                        modifier = Modifier.padding(12.dp),
                        verticalAlignment = Alignment.CenterVertically,
                    ) {
                        Image(
                            modifier = Modifier.size(24.dp),
                            colorFilter = /** Токен цвета */,
                            painter = painterResource(item.first),
                            contentDescription = "image",
                        )
                        Spacer(modifier = Modifier.width(12.dp))
                        Text(item.second)
                        if (index == 0) {
                            Spacer(modifier = Modifier.weight(1f))
                            Badge(
                                modifier = Modifier
                                    .padding(12.dp),
                                label = "Новых: 5",
                            )
                        }
                    }
                    if (index < items.lastIndex) {
                        Divider(modifier = Modifier.padding(start = 48.dp))
                    }
                }
            }
        },
    ) {
        Button(
            label = "Открыть",
            modifier = Modifier.align(Alignment.Center),
            onClick = { scope.launch { drawerState.open() } },
        )
    }
}

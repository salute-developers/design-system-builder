Box(modifier = Modifier.fillMaxSize()) {
    val blurState = rememberBlurState()

    // Источник размытия. Какой-то фоновый контент.
    Box(Modifier.blurSource(blurState))

    // Контент, у которого будет размыт фон.
    Box(
        modifier = Modifier
            .align(Alignment.Center)
            .blurEffect(blurState),
    )
}

RectSkeleton(
    modifier = Modifier
        .width(128.dp)
        .height(32.dp),
)

ButtonGroup(
    orientation = ButtonGroupOrientation.Horizontal,
) {
    button { Button(label = "label", onClick = {}) }
    button { Button(label = "label", onClick = {}) }
    button { Button(label = "label", onClick = {}) }
}

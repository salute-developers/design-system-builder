val cutoutState = rememberCutoutState()

ProvideCutoutState(cutoutState) {
    Box {
        Box(
            modifier = Modifier
                .size(56.dp)
                .background(Color.Gray, CircleShape)
                .cutoutTarget(),
        )

        Box(
            modifier = Modifier
                .align(Alignment.BottomEnd)
                .size(16.dp)
                .cutout(
                    shape = CircleShape,
                    padding = PaddingValues(2.dp, 2.dp),
                )
                .background(Color.Red, CircleShape),
        )
    }
}

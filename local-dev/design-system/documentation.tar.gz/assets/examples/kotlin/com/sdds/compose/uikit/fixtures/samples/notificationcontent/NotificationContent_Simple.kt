NotificationContent(
    modifier = Modifier.fillMaxWidth(),
    title = "Title",
    text = "Notification Text",
    buttons = {
        button { Button(label = "Ok", onClick = {}) }
        button { Button(label = "Cancel", onClick = {}) }
    },
)

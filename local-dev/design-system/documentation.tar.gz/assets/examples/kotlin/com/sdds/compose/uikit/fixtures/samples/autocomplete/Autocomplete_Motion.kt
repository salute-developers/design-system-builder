var value by remember { mutableStateOf("") }
var showDropdown by remember { mutableStateOf(false) }
val suggestions = listOf("Москва", "Мурманск", "Самара").filter { it.contains(value, ignoreCase = true) }
val fieldMotion = rememberTextFieldMotion(
    style = TextFieldMotionStyle.builder().backgroundColor(
        transition { segment {} changesWith { finite(tween(200)) } },
    ).style(),
)
val dropdownMotion = rememberDropdownMenuMotion()
Autocomplete(
    dropdownMotion = dropdownMotion,
    style = AutocompleteStyle.builder().textFieldStyle(
        TextFieldStyle.builder().colors {
            backgroundColor(
                Color.LightGray.asStatefulBrush(setOf(InteractiveState.Focused) to Color.White),
            )
        }.style(),
    ).style(),
    showDropdown = showDropdown,
    onDismissRequest = { showDropdown = false },
    field = {
        TextField(
            value = value,
            onValueChange = {
                value = it
                showDropdown = true
            },
            modifier = Modifier.width(260.dp),
            placeholderText = "Город",
            focusSelectorSettings = FocusSelectorSettings.None,
            motion = fieldMotion,
        )
    },
    listContent = {
        items(suggestions.size) { index ->
            ListItem(
                text = suggestions[index],
                modifier = Modifier.clickable {
                    value = suggestions[index]
                    showDropdown = false
                },
            )
        }
    },
)

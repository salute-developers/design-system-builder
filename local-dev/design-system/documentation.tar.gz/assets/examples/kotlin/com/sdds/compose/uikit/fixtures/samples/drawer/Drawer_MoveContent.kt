val drawerState = rememberDrawerState(
    initialValue = placeholder(
        DrawerValue.Opened,
        "DrawerValue.Closed",
    ),
)
val scope = rememberCoroutineScope()

Drawer(
    drawerState = drawerState,
    moveContentEnabled = true,
    drawerContent = { Text("Контент панели", modifier = Modifier.padding(16.dp)) },
) {
    Button(
        label = "Открыть",
        modifier = Modifier.align(Alignment.Center),
        onClick = { scope.launch { drawerState.open() } },
    )
}

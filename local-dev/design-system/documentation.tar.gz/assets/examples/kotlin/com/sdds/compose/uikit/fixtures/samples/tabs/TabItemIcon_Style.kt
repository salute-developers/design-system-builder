TabItemStyle.builder()
    .colors {
        startContentColor(
            /** Токен цвета */.asStatefulValue(
                setOf(InteractiveState.Selected, InteractiveState.Pressed)
                    to /** Цвет в состоянии selected + pressed */,
                setOf(InteractiveState.Selected, InteractiveState.Hovered)
                    to /** Цвет в состоянии selected + hovered */,
                setOf(InteractiveState.Hovered)
                    to /** Цвет в состоянии hovered */,
                setOf(InteractiveState.Pressed)
                    to /** Цвет в состоянии pressed */,
                setOf(InteractiveState.Selected)
                    to /** Цвет в состоянии selected */,
            ),
        )
        endContentColor(
            /** Токен цвета */.asStatefulValue(
                setOf(InteractiveState.Selected, InteractiveState.Pressed)
                    to /** Цвет в состоянии selected + pressed */,
                setOf(InteractiveState.Selected, InteractiveState.Hovered)
                    to /** Цвет в состоянии selected + hovered */,
                setOf(InteractiveState.Hovered)
                    to /** Цвет в состоянии hovered */,
                setOf(InteractiveState.Pressed)
                    to /** Цвет в состоянии pressed */,
                setOf(InteractiveState.Selected)
                    to /** Цвет в состоянии selected */,
            ),
        )
        actionColor(
            /** Токен цвета */.asStatefulValue(
                setOf(InteractiveState.Hovered)
                    to /** Цвет в состоянии hovered */,
                setOf(InteractiveState.Pressed)
                    to /** Цвет в состоянии pressed */,
            ),
        )
    }
    .disableAlpha(0.4f)
    .dimensions {
        minHeight(56.0.dp)
        paddingStart(18.0.dp)
        paddingEnd(18.0.dp)
        startContentSize(24.0.dp)
        endContentSize(24.0.dp)
        actionPadding(10.0.dp)
        counterPadding(0.0.dp)
        counterOffsetX(8.0.dp)
        counterOffsetY(8.0.dp)
    }
    .counterStyle(/** Стиль компонента */)
    .actionIcon(resourceImageSource(R.drawable.ic_close_24))
    .style()

AiInputStyle.builder()
    .mode(AiInputMode.Condensed)
    .inputStyle(/** Токен типографики */)
    .placeholderStyle(/** Токен типографики */)
    .colors {
        backgroundColor(/** Токен цвета фона */)
        inputColor(/** Токен цвета текста */)
        placeholderColor(/** Токен цвета placeholder */)
        cursorColor(/** Токен цвета курсора */)
    }
    .dimensions {
        paddingStart(0.dp)
        paddingEnd(0.dp)
        paddingTop(0.dp)
        paddingBottom(0.dp)
        textFieldPaddingStart(12.dp)
        textFieldPaddingEnd(12.dp)
        textFieldPaddingTop(8.dp)
        textFieldPaddingBottom(8.dp)
        contentPadding(8.dp)
    }
    .startButtonGroupStyle(
        /** Стиль группы слева */,
    )
    .endButtonGroupStyle(
        /** Стиль группы справа */,
    )
    .sendButtonStyle(
        /** Стиль кнопки отправки */,
    )
    .style()

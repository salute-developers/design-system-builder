SplitterStyle.builder()
    .dividerShape(CircleShape)
    .handleShape(CircleShape)
    .color {
        dividerColor(/** Токен цвета */.asInteractive())
        handleColor(/** Токен цвета */.asInteractive())
    }
    .dimensions {
        dividerThickness(2.0.dp)
        handleThickness(1.0.dp)
        handleStartPadding(3.0.dp)
        handleEndPadding(3.0.dp)
        handleTopPadding(3.0.dp)
        handleBottomPadding(3.0.dp)
        handleSpacer(5.0.dp)
        gap(22.0.dp)
    }
    .style()

TabBarItemStyle.builder()
    .shape(/** Токе формы(скругления) */)
    .labelStyle(/** Токен типографики */)
    .labelPlacement(TabBarLabelPlacement.Bottom)
    .colors {
        backgroundColor(
            /** Токен цвета */.asInteractive(
                setOf(InteractiveState.Selected)
                    to /** Цвет в состоянии selected */,
            ),
        )
        labelColor(
            /** Токен цвета */.asInteractive(
                setOf(InteractiveState.Selected)
                    to /** Цвет в состоянии selected */,
            ),
        )
        iconColor(
            /** Токен цвета */.asInteractive(
                setOf(InteractiveState.Selected)
                    to /** Цвет в состоянии selected */,
            ),
        )
    }
    .dimensions {
        paddingTop(10.dp)
        paddingBottom(10.dp)
        iconSize(32.dp)
        minHeight(48.dp)
        labelPadding(2.dp)
    }
    .counterStyle(/** Стиль компонента */)
    .badgeStyle(/** Стиль компонента */)
    .indicatorStyle(
        placeholder(
            IndicatorStyle.builder().style(),
            "/** Стиль компонента */",
        ),
    )
    .style()

val sheetState = rememberModalBottomSheetState(
    initialValue = BottomSheetValue.Hidden,
)
val scrollState = rememberScrollState()
ModalBottomSheet(
    // Обрабатываем отступы statusBar снаружи, чтобы ModalBottomSheet открывался до границ statusBar
    modifier = Modifier.statusBarsPadding(),
    sheetState = sheetState,
    onDismiss = { /* Колбэк закрытия ModalBottomSheet */ },
    fitContent = true,
) {
    Column(
        modifier = Modifier
            // Отступы navigationBar обрабатываем внутри, чтобы ModalBottomSheet рисовался под navigationBar
            .navigationBarsPadding()
            // Аналогично поступаем с отступами IME
            .imePadding()
            .verticalScroll(scrollState),
    ) {
        Text("Заголовок ModalBottomSheet")

        TextField(
            modifier = Modifier
                .heightIn(min = 50.dp, max = 100.dp)
                .fillMaxWidth(),
            value = "",
            placeholderText = "Введите значение",
            onValueChange = {},
            focusSelectorSettings = FocusSelectorSettings.None,
        )
    }
}

object ThumbProgressKey : MotionChannelKey

val thumbOffsetMotion = interpolation<Dp>(
    channelKey = ThumbProgressKey,
    label = "ThumbOffset",
) {
    segment {
        condition { it changes InteractiveState.Selected }
    } evaluatesBy { dpEvaluator() }
}

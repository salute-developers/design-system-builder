SpinnerStyle.builder()
    .angle(360f)
    .strokeCap(SpinnerStrokeCap.Round)
    .dimensions {
        size(16.0.dp)
        strokeWidth(2.dp)
        padding(1.dp)
    }
    .colors {
        backgroundColor(Color.LightGray)
        startColor(Color.LightGray)
        endColor(Color.Black)
    }
    .style()

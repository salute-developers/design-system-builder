TabsStyle.builder()
    .colors {
        indicatorColor(/** Токен цвета */.asInteractive())
        overflowNextIconColor(/** Токен цвета */.asInteractive())
        overflowPrevIconColor(/** Токен цвета */.asInteractive())
        disclosureColor(
            /** Токен цвета */.asInteractive(
                setOf(InteractiveState.Hovered)
                    to /** Цвет в состоянии hovered */,
                setOf(InteractiveState.Pressed)
                    to /** Цвет в состоянии pressed */,
            ),
        )
    }
    .dimensions {
        indicatorThickness(2.0.dp)
        minSpacing(0.0.dp)
        minHeight(68.dp)
    }
    .orientation(TabsOrientation.Vertical)
    .dividerStyle(/** Стиль компонента */)
    .overflowNextIcon(resourceImageSource(R.drawable.ic_disclosure_right_outline_24))
    .overflowPrevIcon(resourceImageSource(R.drawable.ic_disclosure_left_outline_24))
    .dividerEnabled(true)
    .indicatorEnabled(true)
    .dropdownMenuStyle(/** Стиль компонента */)
    .disclosureTextStyle(/** Токен типографики */)
    .tabItemStyle(/** Стиль компонента */)
    .style()

CheckBoxGroupStyle.builder()
    .checkBoxStyle(/** Стиль компонента */)
    .dimensions {
        itemSpacing(14.0.dp)
        itemOffset(36.0.dp)
    }
    .style()

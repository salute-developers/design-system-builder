var text by remember { mutableStateOf("text") }
AiUserMessage(
    modifier = Modifier.fillMaxWidth(),
    value = text,
    isInEdit = true,
    onValueChange = { text = it },
    editableActions = {
        button {
            Button(label = "Сохранить", onClick = {})
        }
        button {
            Button(label = "Отменить", onClick = {})
        }
    },
    actions = {
        button { IconButton(iconRes = R.drawable.ic_backward_outline_24, onClick = {}) }
        button { IconButton(iconRes = R.drawable.ic_copy_outline_24, onClick = {}) }
    },
)

var dragOver by remember { mutableStateOf(false) }
var state by remember { mutableStateOf(DropZoneState.Idle) }
Column(
    verticalArrangement = Arrangement.spacedBy(32.dp),
    horizontalAlignment = Alignment.CenterHorizontally,
) {
    Box(
        modifier = Modifier.dragAndDropTarget(
            shouldStartDragAndDrop = { true },
            target = remember {
                object : DragAndDropTarget {
                    override fun onEntered(event: DragAndDropEvent) {
                        dragOver = true
                    }

                    override fun onExited(event: DragAndDropEvent) {
                        dragOver = false
                    }

                    override fun onEnded(event: DragAndDropEvent) {
                        dragOver = false
                    }

                    override fun onDrop(event: DragAndDropEvent): Boolean {
                        dragOver = false
                        return true
                    }
                }
            },
        ),
    ) {
        val motion = rememberDropZoneMotion()
        DropZone(
            modifier = Modifier
                .focusable(state != DropZoneState.Disabled, motion.context.interactionSource),
            state = if (dragOver) DropZoneState.DraggingOver else state,
            motion = motion,
            iconPlacement = DropZoneIconPlacement.Top,
            title = {
                Text(text = "title")
            },
            description = {
                Text(text = "description")
            },
            icon = {
                Icon(
                    painter = painterResource(R.drawable.ic_salute_outline_24),
                    contentDescription = null,
                )
            },
        )
    }

    File(
        modifier = Modifier.dragAndDropSource(transferData = {
            DragAndDropTransferData(
                clipData = ClipData.newPlainText("demo", "demo"),
            )
        }),
        labelContent = {
            Text(
                text = "Draggable file",
            )
        },
        descriptionContent = {},
        image = {
            Icon(
                painter = painterResource(R.drawable.ic_file_check_fill_36),
                contentDescription = null,
            )
        },
    )
}

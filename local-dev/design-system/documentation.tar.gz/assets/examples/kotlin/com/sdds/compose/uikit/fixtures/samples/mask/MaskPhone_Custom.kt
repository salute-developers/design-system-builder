var text by remember { mutableStateOf("") }
MaskedTextField(
    value = text,
    onValueChange = { text = it },
    mask = remember {
        PhoneMask(
            mask = "+365 (###) ###_##_##", // используем кастомный код и разделители '_',
            digitPlaceholder = '1', // используем символ подсказки 1 вместо 0
        )
    },
    placeholderText = "Введите номер телефона",
    focusSelectorSettings = FocusSelectorSettings.None,
)

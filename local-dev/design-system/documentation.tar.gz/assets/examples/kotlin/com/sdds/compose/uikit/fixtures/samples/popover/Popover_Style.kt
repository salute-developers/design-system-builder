PopoverStyle.builder()
    .shadow(/** Токен тени */)
    .shape(/** Токен формы (скругления) */)
    .dimensions {
        width(182.0.dp)
        offset(8.0.dp)
        tailWidth(20.0.dp)
        tailHeight(8.0.dp)
        tailPadding(20.0.dp)
    }
    .colors {
        backgroundColor(SolidColor(Color.Gray))
    }
    .style()

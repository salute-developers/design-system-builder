ProgressBar(
    progress = 0.25f,
    modifier = Modifier.width(240.dp),
)

val containerColor by colors.container.getColorAsState(
    context = motion.context,
    motionProperty = motion.style.container,
)

val contentColor by colors.content.getColorAsState(
    context = motion.context,
    motionProperty = motion.style.content,
)

val elevation by dimensions.elevation.getDpAsState(
    context = motion.context,
    motionProperty = motion.style.elevation,
)

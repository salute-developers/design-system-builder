Avatar(
    placeholder = AvatarPlaceholder.Name("Michael Scott"),
    extra = {
        Counter(
            modifier = Modifier.align(Alignment.TopEnd),
            count = "1",
        )
    },
    content = { },
)

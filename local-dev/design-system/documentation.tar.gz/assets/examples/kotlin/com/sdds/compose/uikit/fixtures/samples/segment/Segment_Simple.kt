SegmentHorizontal(
    stretch = false,
    hasBackground = true,
) {
    repeat(3) { index ->
        segmentItem {
            SegmentItem(
                isSelected = index == 0,
                label = "Label",
                value = "Value",
                startIcon = painterResource(id = com.sdds.icons.R.drawable.ic_scribble_diagonal_24),
                counter = "55",
                enabled = true,
            )
        }
    }
}

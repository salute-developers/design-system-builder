var selected by remember { mutableStateOf(false) }
val selectedState = setOf(InteractiveState.Selected)
val counterStyle = CounterStyle.builder()
    .colors { backgroundBrush(Color.LightGray.asStatefulBrush(selectedState to Color.Green)) }
    .style()
val style = SegmentItemStyle.builder()
    .colors { backgroundColor(Color.LightGray.asStatefulBrush(selectedState to Color.Cyan)) }
    .labelStyle(TextStyle(fontSize = 14.sp))
    .dimensions {
        minHeight(40.dp.asStatefulValue(selectedState to 48.dp))
        valueMargin(4.dp.asStatefulValue(selectedState to 12.dp))
    }
    .counterStyle(counterStyle)
    .style()
val motion = rememberSegmentItemMotion(
    style = SegmentItemMotionStyle.builder()
        .backgroundColor(transition { segment {} changesWith { finite(tween(200)) } })
        .minHeight(transition { segment {} changesWith { finite(tween(200)) } })
        .valueMargin(transition { segment {} changesWith { finite(tween(200)) } })
        .style(),
)
SegmentItem(
    motion = motion,
    style = style,
    label = "Сообщения",
    value = "Новые",
    counter = "7",
    isSelected = selected,
    modifier = Modifier.clickable(
        interactionSource = motion.context.interactionSource,
        indication = null,
    ) { selected = !selected },
)

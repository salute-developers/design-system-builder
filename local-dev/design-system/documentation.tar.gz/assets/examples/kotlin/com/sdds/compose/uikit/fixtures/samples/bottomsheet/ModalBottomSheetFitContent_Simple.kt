val sheetState = rememberModalBottomSheetState(
    initialValue = BottomSheetValue.Hidden,
)
ModalBottomSheet(
    sheetState = sheetState,
    fitContent = true,
    body = { Text("Заголовок") },
)

ListItemStyle.builder()
    .shape(/** Токен формы (скругления) */)
    .titleStyle(/** Токен типографики */)
    .disclosureIcon(resourceImageSource(com.sdds.icons.R.drawable.ic_disclosure_right_outline_24))
    .colors {
        titleColor(Color.Black)
        disclosureIconColor(Color.Gray)
        backgroundColor(Color.Transparent)
    }
    .dimensions {
        contentPaddingEnd(4.dp)
        height(32.dp)
        paddingStart(8.dp)
        paddingEnd(8.dp)
        paddingTop(8.dp)
        paddingBottom(8.dp)
    }
    .style()

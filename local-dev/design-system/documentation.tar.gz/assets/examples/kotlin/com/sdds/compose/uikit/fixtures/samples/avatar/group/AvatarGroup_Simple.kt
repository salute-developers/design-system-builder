AvatarGroup(
    threshold = 1,
) {
    repeat(3) {
        avatar {
            Avatar(
                status = AvatarStatus.Active,
                placeholder = AvatarPlaceholder.Name("Michael Scott"),
            )
        }
        counter {
            AvatarCounter(3)
        }
    }
}

ProgressBarStyle.builder()
    .colorValues {
        backgroundColor(/** Токен цвета */.asInteractive())
        indicatorColor(/** Токен цвета */.asInteractive())
    }
    .indicatorShape(CircleShape)
    .backgroundShape(CircleShape)
    .dimensionValues {
        indicatorHeight(4.0.dp)
        backgroundHeight(4.0.dp)
    }
    .style()

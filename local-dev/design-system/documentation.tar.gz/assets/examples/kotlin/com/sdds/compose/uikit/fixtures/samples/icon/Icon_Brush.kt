Icon(
    source = resourceImageSource(com.sdds.icons.R.drawable.ic_alarm_done_fill_36),
    contentDescription = "Иконка с brush",
    brush = {
        Brush.linearGradient(
            colors = listOf(Color(0xFFF2994A), Color(0xFFEB5757)),
        )
    },
)

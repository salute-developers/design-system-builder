NavigationBar(
    centerAlignmentStrategy = NavBarCenterAlignmentStrategy.Relative,
    textPlacement = NavigationBarTextPlacement.Inline,
    titleContent = { Text("Title") },
    descriptionContent = { Text("Description") },
    actionEnd = {
        Icon(
            modifier = Modifier.clickable { /* действие */ },
            painter = painterResource(com.sdds.icons.R.drawable.ic_search_24),
            contentDescription = "",
        )
        Icon(
            modifier = Modifier.clickable { /* действие */ },
            painter = painterResource(com.sdds.icons.R.drawable.ic_menu_24),
            contentDescription = "",
        )
    },
)

LoaderStyle.builder()
    .spinnerStyle(/** Стиль комопнента */)
    .circularProgressStyle(/** Стиль комопнента */)
    .style()

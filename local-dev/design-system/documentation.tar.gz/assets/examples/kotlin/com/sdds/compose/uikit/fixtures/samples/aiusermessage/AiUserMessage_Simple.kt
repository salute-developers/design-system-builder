var text by remember { mutableStateOf("text") }
AiUserMessage(
    modifier = Modifier.fillMaxWidth(),
    value = text,
    onValueChange = { text = it },
)

ChipStyle.builder()
    .colors {
        backgroundColor(
            /** Токен цвета */.asInteractive(
                setOf(InteractiveState.Pressed)
                    to /** Цвет в состоянии pressed */,
                setOf(InteractiveState.Hovered)
                    to /** Цвет в состоянии hovered */,
            ),
        )
            .contentStartColor(/** Токен цвета */)
            .contentEndColor(/** Токен цвета */)
            .labelColor(/** Токен цвета */)
    }
    .shape(/** Токен формы (скругления) */)
    .labelStyle(/** Токен стиля текста */)
    .dimensions {
        height(48.0.dp)
        paddingStart(16.0.dp)
        paddingEnd(16.0.dp)
        contentStartPadding(8.0.dp)
        contentEndPadding(8.0.dp)
        contentStartSize(24.0.dp)
        contentEndSize(24.0.dp)
    }
    .style()

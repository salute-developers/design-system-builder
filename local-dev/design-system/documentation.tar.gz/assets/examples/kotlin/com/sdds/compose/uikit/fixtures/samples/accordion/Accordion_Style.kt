AccordionStyle.builder()
    .accordionItemStyle(/** Стиль компонента */)
    .dividerStyle(/** Стиль компонента */)
    .dimensions {
        itemSpacing(4.0.dp)
    }
    .style()

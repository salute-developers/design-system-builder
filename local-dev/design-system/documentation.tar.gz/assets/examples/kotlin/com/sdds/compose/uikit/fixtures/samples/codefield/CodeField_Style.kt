CodeFieldStyle.builder()
    .itemShape(/** Токен формы (скругления) */)
    .groupShape(/** Токен формы (скругления) */)
    .valueStyle(/** Токен типографики */)
    .captionStyle(/** Токен типографики */)
    .colors {
        valueColor(
            /** Токен цвета */.asStatefulValue(
                setOf(CodeInputStates.Error)
                    to /** Цвет в состоянии error */,
            ),
        )
        captionColor(
            /** Токен цвета */.asStatefulValue(
                setOf(CodeInputStates.Error)
                    to /** Цвет в состоянии error */,
            ),
        )
        dotColor(
            /** Токен цвета */.asStatefulValue(
                setOf(CodeInputStates.Error)
                    to /** Токен цвета */,
            ),
        )
        backgroundColor(
            /** Токен цвета */.asStatefulValue(
                setOf(CodeInputStates.Error)
                    to /** Цвет в состоянии error */,
                setOf(InteractiveState.Activated)
                    to /** Цвет в состоянии activated */,
            ),
        )
        cursorColor(/** Токен цвета */)
    }
    .dimensions {
        dotSize(16.0.dp)
        height(36.0.dp)
        width(60.0.dp)
        itemSpacing(8.0.dp)
        groupSpacing(28.0.dp)
        captionSpacing(28.0.dp)
    }
    .style()

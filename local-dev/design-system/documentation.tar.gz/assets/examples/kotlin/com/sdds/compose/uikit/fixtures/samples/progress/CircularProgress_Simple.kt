CircularProgressBar(
    progress = 0.5f,
    trackEnabled = true,
)

NavigationBar(
    textPlacement = NavigationBarTextPlacement.Bottom,
    contentPlacement = NavigationBarContentPlacement.Bottom,
    textAlign = NavigationBarTextAlign.Center,
    titleContent = { Text("Text") },
    actionEnd = {
        Icon(
            modifier = Modifier.clickable { /* действие */ },
            painter = painterResource(com.sdds.icons.R.drawable.ic_search_24),
            contentDescription = "",
        )
        Icon(
            modifier = Modifier.clickable { /* действие */ },
            painter = painterResource(com.sdds.icons.R.drawable.ic_menu_24),
            contentDescription = "",
        )
    },
)

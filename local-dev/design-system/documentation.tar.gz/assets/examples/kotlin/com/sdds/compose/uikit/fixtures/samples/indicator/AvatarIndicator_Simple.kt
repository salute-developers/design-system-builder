Avatar(
    modifier = Modifier
        .indicator(
            alignment = Alignment.TopEnd,
            horizontalPadding = 2.dp,
            verticalPadding = 2.dp,
            horizontalMode = IndicatorMode.Inner,
            verticalMode = IndicatorMode.Inner,
        ),
    status = AvatarStatus.None,
    actionEnabled = false,
    placeholder = AvatarPlaceholder.Name("Michael Scott"),
)

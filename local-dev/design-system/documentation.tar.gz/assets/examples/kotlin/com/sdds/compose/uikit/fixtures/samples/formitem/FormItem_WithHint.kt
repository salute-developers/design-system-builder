val hintTriggerInfo = remember { mutableStateOf(TriggerInfo()) }
var showTooltip by remember { mutableStateOf(false) }
FormItem(
    content = { Text("Form Item Content") },
    title = { Text("Title") },
    titleCaption = { Text("TitleCaption") },
    caption = { Text("Caption") },
    counter = { Text("Counter") },
    hasHint = true,
    onHintPressed = { showTooltip = true },
    hintTriggerInfo = hintTriggerInfo,
)

Tooltip(
    show = showTooltip,
    onDismissRequest = { showTooltip = false },
    triggerInfo = { hintTriggerInfo.value },
    text = AnnotatedString("Tooltip text"),
    alignment = PopoverAlignment.Center,
)

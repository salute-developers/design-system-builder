var text by remember { mutableStateOf("") }
MaskedTextField(
    value = text,
    onValueChange = { text = it },
    mask = remember {
        TimeMask(
            pattern = listOf("ЧЧ", "ММ", "СС"), // добавляем секунды
            separator = '_', // используем кастомный разделитель
        )
    },
    placeholderText = "Введите время",
    focusSelectorSettings = FocusSelectorSettings.None,
)

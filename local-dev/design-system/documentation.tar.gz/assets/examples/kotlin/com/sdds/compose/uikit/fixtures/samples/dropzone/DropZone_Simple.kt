DropZone(
    state = DropZoneState.Idle,
    iconPlacement = DropZoneIconPlacement.Top,
    title = {
        Text(text = "title")
    },
    description = {
        Text(text = "description")
    },
    icon = {
        Icon(
            source = resourceImageSource(R.drawable.ic_salute_outline_24),
            contentDescription = null,
        )
    },
)

NotificationStyle.builder()
    .shadow(/** Токен тени */)
    .shape(/** Токе формы(скругления) */)
    .dimensions {
        closeSize(16.0.dp)
        paddingStart(8.dp)
        paddingEnd(8.dp)
        paddingTop(8.dp)
        paddingBottom(8.dp)
    }
    .colors {
        backgroundColor(SolidColor(Color.Gray))
        closeColor(Color.LightGray)
    }
    .notificationContentStyle(
        /** Стиль компонента */,
    )
    .style()

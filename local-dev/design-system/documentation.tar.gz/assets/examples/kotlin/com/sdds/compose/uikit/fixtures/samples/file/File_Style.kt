FileStyle.builder()
    .colors {
        iconColor(Color.Cyan)
        descriptionColor(Color.Gray)
        labelColor(Color.Black)
    }
    .dimensions {
        descriptionPadding(2.dp)
        startContentPadding(12.dp)
        endContentPadding(12.dp)
        bottomContentPadding(12.dp)
    }
    .labelStyle(/** Токен типографики */)
    .descriptionStyle(/** Токен типографики */)
    .actionButtonStyle(/** Стиль компонента */)
    .circularProgressBarStyle(
        /** Стиль компонента */,
    )
    .style()

PaginationDotsStyle.builder()
    .orientation(PaginationDotsOrientation.Vertical)
    .edgeShrinkFactor(0.3f)
    .edgeCount(2)
    .colors {
        dotBackgroundColor(
            /** Токен цвета */.asStatefulValue(
                setOf(InteractiveState.Activated)
                    to /** Цвет в состоянии activated */,
            ),
        )
    }
    .dimensions {
        gap(6.0.dp)
        dotWidth(8.0.dp)
        dotHeight(
            8.0.dp.asStatefulValue(
                setOf(InteractiveState.Activated) to 32.0.dp,
            ),
        )
    }
    .style()

val blurState = rememberBlurState()

Box(
    modifier = Modifier.blurEffect(
        state = blurState,
        style = BlurStyle.create(
            blurRadius = 32.dp,
            noiseFactor = 0.15f,
        ),
    ),
)

val drawerState = rememberDrawerState(
    initialValue = placeholder(
        DrawerValue.Opened,
        "DrawerValue.Closed",
    ),
)
val scope = rememberCoroutineScope()
Drawer(
    drawerState = drawerState,
    closeIconAlignment = CloseIconAlignment.End,
    closeIconPlacement = CloseIconPlacement.Outer,
    closeIcon = {
        Icon(
            painter = painterResource(R.drawable.ic_close_24),
            contentDescription = "",
        )
    },
    drawerContent = {
        Text(
            "Панель с кастомной иконкой",
            modifier = Modifier.padding(16.dp),
        )
    },
) {
    Button(
        label = "Открыть",
        modifier = Modifier.align(Alignment.Center),
        onClick = { scope.launch { drawerState.open() } },
    )
}

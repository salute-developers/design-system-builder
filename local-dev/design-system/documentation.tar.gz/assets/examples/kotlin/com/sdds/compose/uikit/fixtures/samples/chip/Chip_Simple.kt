Chip(
    label = "label",
    isSelected = true,
    startContent = {
        Icon(
            painter = painterResource(id = com.sdds.icons.R.drawable.ic_accessibility_24),
            contentDescription = "",
        )
    },
    endContent = {
        Icon(
            painter = painterResource(id = com.sdds.icons.R.drawable.ic_close_24),
            contentDescription = "",
        )
    },
)

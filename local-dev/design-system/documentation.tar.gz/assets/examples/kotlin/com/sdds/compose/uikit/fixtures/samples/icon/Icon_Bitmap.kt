Icon(
    source = bitmapSource(yourBitmap),
    contentDescription = "Иконка из ImageBitmap",
)

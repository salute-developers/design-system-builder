val carouselState = rememberPagerState { carouselData.size }
Carousel(
    state = carouselState,
    hasControls = false,
    pageSize = PageSize.Fixed(250.dp),
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .height(250.dp),
    ) {
        Text(carouselData[it])
    }
}

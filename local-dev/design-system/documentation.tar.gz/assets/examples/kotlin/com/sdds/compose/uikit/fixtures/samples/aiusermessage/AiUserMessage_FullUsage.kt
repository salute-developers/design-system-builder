var editMode by remember { mutableStateOf(false) }
var message by remember { mutableStateOf("Text") }
var draftMessage by remember { mutableStateOf("") }

AiUserMessage(
    modifier = Modifier.fillMaxWidth(),
    value = if (editMode) draftMessage else message,
    onValueChange = { draftMessage = it },
    isInEdit = editMode,
    uploadingContent =
    {
        repeat(5) {
            File(
                modifier = Modifier.width(200.dp),
                label = "some_file$it.pdf",
                isLoading = false,
                image = {
                    Icon(
                        painterResource(R.drawable.ic_file_check_fill_24),
                        contentDescription = "",
                    )
                },
                action = {
                    IconButton(
                        iconRes = R.drawable.ic_close_16,
                        onClick = {},
                    )
                },
                actionPlacement = FileActionPlacement.End,
            )
        }
    },
    editableActions =
    {
        button {
            Button(label = "Сохранить", onClick = {
                message = draftMessage
                editMode = false
            })
        }
        button {
            Button(label = "Отменить", onClick = {
                draftMessage = message
                editMode = false
            })
        }
    },
    actions =
    {
        button { IconButton(iconRes = R.drawable.ic_backward_outline_24, onClick = {}) }
        button { IconButton(iconRes = R.drawable.ic_copy_outline_24, onClick = {}) }
        button { IconButton(iconRes = R.drawable.ic_plasma_24, onClick = {}) }
        button {
            IconButton(iconRes = R.drawable.ic_edit_outline_24, onClick = {
                draftMessage = message
                editMode = true
            })
        }
    },
)

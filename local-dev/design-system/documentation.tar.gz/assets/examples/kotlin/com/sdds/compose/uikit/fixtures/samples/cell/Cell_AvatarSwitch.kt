Cell(
    modifier = Modifier
        .fillMaxWidth()
        .focusable(interactionSource = interactionSource)
        .focusSelector(
            settings = LocalFocusSelectorSettings.current,
        ) { isFocused.value },
    title = AnnotatedString("Заголовок"),
    subtitle = AnnotatedString("Подзаголовок"),
    label = AnnotatedString("Лейбл"),
    disclosureContentEnabled = false,
    startContent = {
        Avatar(
            status = AvatarStatus.Active,
            placeholder = AvatarPlaceholder.Name("Michael Scott"),
        )
    },
    endContent = {
        var active by remember { mutableStateOf(false) }
        Switch(active = active, onActiveChanged = { active = it })
    },
)

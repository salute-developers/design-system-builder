CheckBoxGroup {
    rootCheckbox {
        CheckBox(
            state = ToggleableState.On,
            label = "Label",
            description = "Description",
        )
    }
    checkbox {
        CheckBox(
            state = ToggleableState.On,
            label = "Label",
            description = "Description",
        )
    }
    checkbox {
        CheckBox(
            state = ToggleableState.On,
            label = "Label",
            description = "Description",
        )
    }
}

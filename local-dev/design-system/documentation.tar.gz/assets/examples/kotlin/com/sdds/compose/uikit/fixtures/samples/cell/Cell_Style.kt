CellStyle.builder()
    .colors {
        labelColor(/** Токен цвета */)
        titleColor(/** Токен цвета */)
        subtitleColor(/** Токен цвета */)
        disclosureTextColor(/** Токен цвета */)
        disclosureIconColor(/** Токен цвета */)
    }
    .labelStyle(/** Токен типографики */)
    .titleStyle(/** Токен типографики */)
    .subtitleStyle(/** Токен типографики */)
    .disclosureTextStyle(/** Токен типографики */)
    .disclosureIcon(resourceImageSource(R.drawable.ic_disclosure_right_outline_24))
    .dimensions {
        contentPaddingStart(8.0.dp)
        contentPaddingEnd(8.0.dp)
    }
    .avatarStyle(/** Стиль компонента Avatar */)
    .iconButtonStyle(
        /** Стиль компонента IconButton */,
    )
    .checkBoxStyle(/** Стиль компонента CheckBox */)
    .radioBoxStyle(/** Стиль компонента RadioBox */)
    .switchStyle(/** Стиль компонента Switch */)
    .style()

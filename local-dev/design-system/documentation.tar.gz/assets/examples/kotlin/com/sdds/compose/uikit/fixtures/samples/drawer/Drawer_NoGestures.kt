val drawerState = rememberDrawerState(
    initialValue = placeholder(
        DrawerValue.Opened,
        "DrawerValue.Closed",
    ),
)
val scope = rememberCoroutineScope()

Drawer(
    drawerState = drawerState,
    gesturesEnabled = false,
    drawerContent = { Text("Жесты отключены", modifier = Modifier.padding(16.dp)) },
) {
    Row(Modifier.align(Alignment.Center)) {
        Button(label = "Открыть", onClick = { scope.launch { drawerState.open() } })
        Spacer(Modifier.width(12.dp))
        Button(label = "Закрыть", onClick = { scope.launch { drawerState.close() } })
    }
}

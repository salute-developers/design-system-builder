val sheetState = rememberModalBottomSheetState(
    initialValue = BottomSheetValue.Hidden,
    halfExpandedSettings = HalfExpandedSettings.Height(500.dp),
)
val scope = rememberCoroutineScope()
Button(
    label = "показать BottomSheet",
    onClick = {
        scope.launch {
            sheetState.show()
        }
    },
)
ModalBottomSheet(
    sheetState = sheetState,
    handlePlacement = BottomSheetHandlePlacement.Auto,
    fitContent = false,
    header = { Text("Header") },
    footer = { Text("Footer") },
) {
    Text("Text")
}

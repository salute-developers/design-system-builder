val inlineContent = mapOf(
    "icon" to InlineTextContent(
        placeholder = Placeholder(16.sp, 16.sp, PlaceholderVerticalAlign.Center),
    ) {
        Icon(
            source = resourceImageSource(com.sdds.icons.R.drawable.ic_alarm_done_fill_36),
            contentDescription = null,
            brush = { Color.Red.asBrush() },
        )
    },
)

val text = buildAnnotatedString {
    append("Добавляем иконку")
    appendInlineContent("icon", "[icon]")
}

Text(
    source = annotatedStringSource(text),
    inlineContent = inlineContent,
)

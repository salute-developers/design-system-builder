IconButton(
    icon = {
        Icon(
            painter = painterResource(com.sdds.icons.R.drawable.ic_alarm_done_fill_36),
            contentDescription = "Будильник",
        )
    },
    onClick = { },
    enabled = true,
    loading = false,
)

IndicatorStyle.builder(this)
    .color {
        backgroundColor(
            /** Токен цвета */.asInteractive(),
        )
    }
    .dimensions {
        height(12.0.dp)
        width(12.0.dp)
    }
    .style()

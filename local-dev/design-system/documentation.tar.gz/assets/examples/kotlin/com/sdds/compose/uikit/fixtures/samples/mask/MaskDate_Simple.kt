var text by remember { mutableStateOf("") }
MaskedTextField(
    value = text,
    onValueChange = { text = it },
    mask = remember { DateMask() }, // Настройки по-умолчанию ДД:ММ:ГГ
    placeholderText = "Введите дату рождения",
    focusSelectorSettings = FocusSelectorSettings.None,
)

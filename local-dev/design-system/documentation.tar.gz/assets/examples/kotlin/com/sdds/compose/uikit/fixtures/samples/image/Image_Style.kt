ImageStyle.builder()
    .ratio(2f)
    .style()

Avatar(
    placeholder = AvatarPlaceholder.Name("Michael Scott"),
    extra = {
        Badge(
            modifier = Modifier
                .align(Alignment.BottomEnd)
                .cutout(
                    shape = CircleShape,
                    padding = PaddingValues(2.dp, 2.dp),
                ),
            label = "3",
        )
    },
) {
    // Avatar Image
}

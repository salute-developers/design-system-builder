val selectList = listOf(
    "Иван Иванов",
    "Пётр Петров",
    "Сергей Сергеев",
)
val state = remember { SelectState(initialState = true) }
val checkedStateManager = rememberSelectMultipleDataStateManager(
    selectList,
    { true },
)

Select(
    state = state,
    trigger = {
        SelectButton(
            modifier = Modifier.width(260.dp),
            label = checkedStateManager.selectedItems
                .joinToString(", ")
                .ifEmpty { "Value" },
            iconOpened = resourceImageSource(com.sdds.icons.R.drawable.ic_chevron_up_24),
            iconClosed = resourceImageSource(com.sdds.icons.R.drawable.ic_chevron_down_24),
        )
    },
    listContent = {
        items(selectList.size) {
            SelectItem(
                modifier = Modifier.fillMaxWidth(),
                checked = checkedStateManager.isSelected(selectList[it]),
                onClick = { checkedStateManager.onItemPressed(selectList[it]) },
            ) {
                Cell(
                    title = AnnotatedString(selectList[it]),
                    disclosureIconRes = null,
                )
            }
        }
    },
)

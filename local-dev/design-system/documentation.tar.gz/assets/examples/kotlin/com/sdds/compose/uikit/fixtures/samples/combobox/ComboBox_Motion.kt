val state = remember { SelectState() }
var value by remember { mutableStateOf("") }
val fieldMotion = rememberTextFieldMotion(
    style = TextFieldMotionStyle.builder().backgroundColor(
        transition { segment {} changesWith { finite(tween(200)) } },
    ).style(),
)
// Передаётся существующий Motion меню. Доступные переходы задаёт DropdownMenuMotionStyle.
val dropdownMotion = rememberDropdownMenuMotion()
ComboBox(
    dropdownMotion = dropdownMotion,
    state = state,
    trigger = {
        ComboBoxTextField(
            motion = fieldMotion,
            value = value,
            onValueChange = { value = it },
            modifier = Modifier.width(260.dp),
            style = TextFieldStyle.builder().colors {
                backgroundColor(
                    Color.LightGray.asStatefulBrush(
                        setOf(InteractiveState.Activated) to Color.White,
                    ),
                )
            }.style(),
        )
    },
    listContent = {
        item {
            SelectItem(
                checked = value == "Москва",
                onClick = {
                    value = "Москва"
                    state.close()
                },
                titleContent = { Text("Москва") },
            )
        }
    },
)

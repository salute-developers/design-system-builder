Text(
    source = stringSource("Длинное описание чего то, содержащее много строк"),
    maxLines = 2,
    overflow = TextOverflow.Ellipsis,
    softWrap = true,
)

CounterStyle.builder()
    .colors {
        backgroundColor(
            /** Токен цвета */.asInteractive(
                setOf(InteractiveState.Pressed)
                    to /** Цвет в состоянии pressed */,
                setOf(InteractiveState.Hovered)
                    to /** Цвет в состоянии hovered */,
            ),
        )
        textColor(
            /** Токен цвета */.asInteractive(
                setOf(InteractiveState.Pressed)
                    to /** Цвет в состоянии pressed */,
                setOf(InteractiveState.Hovered)
                    to /** Цвет в состоянии hovered */,
            ),
        )
    }
    .textStyle(/** Токен типографики */)
    .dimensions {
        minHeight(28.0.dp)
        minWidth(28.0.dp)
        paddingStart(10.0.dp)
        paddingEnd(10.0.dp)
    }
    .style()

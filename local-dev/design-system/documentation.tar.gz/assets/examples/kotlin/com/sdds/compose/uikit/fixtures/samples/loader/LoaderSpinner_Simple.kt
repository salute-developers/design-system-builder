Loader(
    progress = 0.4f,
    trackEnabled = true,
    valueContent = {
        Icon(
            painter = painterResource(id = com.sdds.icons.R.drawable.ic_close_16),
            contentDescription = "",
        )
    },
    loaderType = LoaderType.Spinner,
)

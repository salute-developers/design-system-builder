Icon(
    source = imageVectorSource(yourImageVector),
    contentDescription = "Иконка из ImageVector",
)

AiHeader(
    modifier = Modifier.fillMaxWidth(),
    actionBefore = {
        IconButton(iconRes = R.drawable.ic_panel_sidebar_l_outline_24, onClick = { /* handle */ })
    },
    actionAfter = {
        IconButton(iconRes = R.drawable.ic_close_24, onClick = { /* handle */ })
    },
    titleContent = { Text(text = "Заголовок") },
    subtitleContent = { Text(text = "Подзаголовок") },
)

BadgeStyle.badgeBuilder()
    .shape(CircleShape)
    .colors {
        backgroundColor(
            /** Токен цвета */.asInteractive(),
        )
        labelColor(
            /** Токен цвета */.asInteractive(),
        )
        startContentColor(
            /** Токен цевета */.asInteractive(),
        )
        endContentColor(
            /** Токен цвета */.asInteractive(),
        )
    }
    .labelStyle(/** Токен типографики */)
    .dimensions {
        height(28.0.dp)
        startContentSize(16.0.dp)
        endContentSize(16.0.dp)
        startContentMargin(4.0.dp)
        endContentMargin(4.0.dp)
        startPadding(11.0.dp)
        endPadding(11.0.dp)
    }
    .style()

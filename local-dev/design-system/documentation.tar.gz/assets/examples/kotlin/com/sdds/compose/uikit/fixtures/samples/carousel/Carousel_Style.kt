CarouselStyle.builder()
    .dimensions {
        nextButtonPadding(8.0.dp)
        prevButtonPadding(8.0.dp)
        indicatorPadding(8.0.dp)
        gap(8.dp)
    }
    .prevButtonStyle(/** Стиль компонента IconButton */)
    .nextButtonStyle(/** Стиль компонента IconButton */)
    .indicatorStyle(
        /** Стиль компонента PaginationDots */,
    )
    .prevButtonIcon(resourceImageSource(R.drawable.ic_chevron_left_36))
    .nextButtonIcon(resourceImageSource(R.drawable.ic_chevron_right_36))
    .buttonsPlacement(CarouselButtonsPlacement.Inner)
    .style()

File(
    label = "image.png",
    description = "226 КБ",
    isLoading = true,
    image = {
        Icon(
            painterResource(com.sdds.icons.R.drawable.ic_file_check_fill_36),
            contentDescription = "",
        )
    },
    progress = {
        CircularProgressBar(
            progress = 0.4f,
            valueContent = {
                Icon(
                    modifier = Modifier.size(12.dp),
                    painter = painterResource(id = com.sdds.icons.R.drawable.ic_close_16),
                    contentDescription = "",
                )
            },
        )
    },
    action = {
        IconButton(
            iconRes = com.sdds.icons.R.drawable.ic_close_36,
            onClick = {},
        )
    },
)

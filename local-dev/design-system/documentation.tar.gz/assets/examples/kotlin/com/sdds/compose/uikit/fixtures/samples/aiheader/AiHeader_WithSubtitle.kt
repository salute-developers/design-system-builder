AiHeader(
    modifier = Modifier.fillMaxWidth(),
    titleContent = { Text(text = "Заголовок") },
    subtitleContent = { Text(text = "Подзаголовок") },
)

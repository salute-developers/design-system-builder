SegmentItem(
    isSelected = true,
    label = "Label",
    value = "Value",
    startIcon = painterResource(id = com.sdds.icons.R.drawable.ic_scribble_diagonal_24),
    counter = "55",
    enabled = true,
)

val angleMotion = interpolation<Float> {
    segment { } evaluatesBy {
        MotionEvaluator { from, to, fraction ->
            from + (to - from) * fraction
        }
    }
}

var text by remember { mutableStateOf("text") }
AiUserMessage(
    modifier = Modifier.fillMaxWidth(),
    value = text,
    onValueChange = { text = it },
    actions = {
        button { IconButton(iconRes = R.drawable.ic_backward_outline_24, onClick = {}) }
        button { IconButton(iconRes = R.drawable.ic_copy_outline_24, onClick = {}) }
    },
)

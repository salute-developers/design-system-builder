val containerColorMotion = transition<Color>(label = "ContainerColor") {
    segment {
        condition { it changesTo InteractiveState.Pressed }
    } changesWith { finite(tween(durationMillis = 120)) }

    segment {
        condition { it changesFrom InteractiveState.Pressed }
    } changesWith { finite(tween(durationMillis = 180)) }
}

NavigationBarStyle.builder()
    .shadow(/** Токен тени */)
    .bottomShape(/** Токен формы(скругления) */)
    .textStyle(/** Токен типографки */)
    .backIcon(resourceImageSource(com.sdds.icons.R.drawable.ic_disclosure_left_outline_24))
    .colors {
        backIconColor(/** Токен цвета */.asInteractive())
        textColor(/** Токен цвета */.asInteractive())
        actionStartColor(/** Токен цвета */.asInteractive())
        actionEndColor(/** Токен цвета */.asInteractive())
        backgroundColor(/** Токен цвета */.asInteractive())
    }
    .dimensions {
        paddingStart(20.0.dp)
        paddingEnd(20.0.dp)
        paddingTop(20.0.dp)
        paddingBottom(20.0.dp)
        backIconMargin(4.0.dp)
        textBlockTopMargin(16.0.dp)
        horizontalSpacing(16.0.dp)
    }
    .style()

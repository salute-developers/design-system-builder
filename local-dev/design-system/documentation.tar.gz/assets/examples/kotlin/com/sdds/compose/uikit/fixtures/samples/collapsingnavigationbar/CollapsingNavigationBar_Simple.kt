val scrollBehavior =
    CollapsingNavigationBarDefaults.exitUntilCollapsedScrollBehavior(
        rememberCollapsingNavigationBarState(),
    )
Column(
    modifier = Modifier.nestedScroll(scrollBehavior.nestedScrollConnection),
) {
    CollapsingNavigationBar(
        scrollBehavior = scrollBehavior,
        collapsedTitle = { Text("Title") },
        expandedTitle = { Text("Title") },
        collapsedDescription = { Text("Description") },
        expandedDescription = { Text("Description") },
        content = { Text("Content") },
        actionStart = {
            Icon(
                painter = painterResource(com.sdds.icons.R.drawable.ic_search_24),
                contentDescription = "",
            )
        },
        actionEnd = {
            Icon(
                painter = painterResource(com.sdds.icons.R.drawable.ic_menu_24),
                contentDescription = "",
            )
        },
        onBackPressed = {
            println("Back button was pressed")
        },
    )
    LazyColumn {
        items(100) {
            Text(modifier = Modifier.padding(32.dp), text = "Label text $it")
        }
    }
}

CodeInputStyle.builder()
    .codeStyle(/** Токен типографики */)
    .captionStyle(/** Токен типографики */)
    .colors {
        codeColor(
            /** Токен цвета */.asStatefulValue(
                setOf(CodeInputStates.Error)
                    to /** Цвет в состоянии error */,
            ),
        )
        captionColor(
            /** Токен типографики */.asStatefulValue(
                setOf(CodeInputStates.Error)
                    to /** Цвет в состоянии error */,
            ),
        )
        fillColor(
            /** Токен цвета */.asStatefulValue(
                setOf(CodeInputStates.Error)
                    to /** Цвет в состоянии error */,
            ),
        )
        strokeColor(
            /** Токен цвета */.asStatefulValue(
                setOf(CodeInputStates.Error)
                    to /** Цвет в состоянии error */,
            ),
        )
    }
    .dimensions {
        circleSize(16.0.dp)
        strokeWidth(1.5.dp)
        itemHeight(36.0.dp)
        itemWidth(60.0.dp)
        itemSpacing(8.0.dp)
        groupSpacing(28.0.dp)
        captionPadding(28.0.dp)
    }
    .style()

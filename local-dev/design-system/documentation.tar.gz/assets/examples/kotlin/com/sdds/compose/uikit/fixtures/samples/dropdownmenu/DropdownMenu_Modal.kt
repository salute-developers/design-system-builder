val showDropdownMenu = remember { mutableStateOf(false) }
val triggerInfo = remember { mutableStateOf(TriggerInfo()) }
Button(
    style = buttonStyle,
    modifier = Modifier.popoverTrigger(
        triggerInfo = triggerInfo,
        shape = buttonStyle.shape,
        cutoutPaddings = PaddingValues(3.dp),
    ),
    label = "Show dropdown menu",
    onClick = { showDropdownMenu.value = true },
)
ModalDropdownMenu(
    opened = showDropdownMenu.value,
    onDismissRequest = {
        showDropdownMenu.value = false
    },
    triggerInfo = triggerInfo.value,
    placement = PopoverPlacement.Bottom,
    placementMode = PopoverPlacementMode.Loose,
    alignment = PopoverAlignment.Center,
) {
    List(
        modifier = Modifier
            .width(200.dp)
            .height(300.dp),
    ) {
        item {
            ListItem(
                text = "Item title 2",
                disclosureEnabled = true,
            )
        }
        item {
            Divider()
        }
        item {
            ListItem(
                text = "Item title 2",
                disclosureEnabled = true,
            )
        }
    }
}

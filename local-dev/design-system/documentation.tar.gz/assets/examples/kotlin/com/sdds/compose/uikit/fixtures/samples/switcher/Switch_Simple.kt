Switch(
    active = true,
    label = "Label",
    description = "Description",
    enabled = true,
)

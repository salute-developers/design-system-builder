---
title: AvatarGroup
---

Контент AvatarGroup формируется с помощью функций avatar(), avatars() и counter() из скоупа AvatarGroupScope.
Counter - счетчик Avatar's, которые не отображаются на экране.

```kotlin
AvatarGroup(
    threshold = 1,
) {
    repeat(3) {
        avatar {
            Avatar(
                status = AvatarStatus.Active,
                placeholder = AvatarPlaceholder.Name("Michael Scott"),
            )
        }
        counter {
            AvatarCounter(3)
        }
    }
}
```

<!-- @screenshot: com.sdds.compose.uikit.fixtures.samples.avatar.group.AvatarGroup_Simple -->

## Стиль AvatarGroup

В большинстве случаев можно использовать готовые сгенерированные стили, а при необходимости создать собственный стиль через соответствующий builder. Подробнее о том, как работают `Style`, `StyleBuilder` и stateful-параметры стиля, см. в разделе [Стилизация компонентов](../theme/Styles.md).

### Параметры стиля

| Параметр | Тип | Возможные значения |
| --- | --- | --- |
| `size` | `AvatarGroupSize` | `S` |

Пример выбора готового стиля:
```kotlin
val style = AvatarGroupStyles.style(
    size = AvatarGroupSize.S
)

// или через dot notation
val style = AvatarGroup.S.style()
```


### Создание стиля с помощью builder()

```kotlin
AvatarGroupStyle.builder()
    .avatarStyle(/** Стиль компонента */)
    .dimensions {
        itemSpacing(2.0.dp)
        itemOffset(16.0.dp)
    }
    .style()
```

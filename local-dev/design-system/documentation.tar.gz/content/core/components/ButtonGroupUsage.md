---
title: ButtonGroup
---
Группа кнопок.

В качестве контента ожидает [Button](BasicButtonUsage.md) либо [IconButton](BasicButtonUsage.md). Кнопки стилизуются автоматически.

### Группа кнопок BasicButton
```kotlin
ButtonGroup(
    orientation = ButtonGroupOrientation.Horizontal,
) {
    button { Button(label = "label", onClick = {}) }
    button { Button(label = "label", onClick = {}) }
    button { Button(label = "label", onClick = {}) }
}
```

<!-- @screenshot: com.sdds.compose.uikit.fixtures.samples.buttongroup.ButtonGroup_Simple -->

### Группа кнопок IconButton
```kotlin
ButtonGroup(
    orientation = ButtonGroupOrientation.Horizontal,
) {
    button {
        IconButton(
            iconRes = R.drawable.ic_plasma_24,
            onClick = {},
        )
    }
    button {
        IconButton(
            iconRes = R.drawable.ic_plasma_24,
            onClick = {},
        )
    }
    button {
        IconButton(
            iconRes = R.drawable.ic_plasma_24,
            onClick = {},
        )
    }
}
```

## Стиль ButtonGroup

В большинстве случаев можно использовать готовые сгенерированные стили, а при необходимости создать собственный стиль через соответствующий builder. Подробнее о том, как работают `Style`, `StyleBuilder` и stateful-параметры стиля, см. в разделе [Стилизация компонентов](../theme/Styles.md).

### Параметры стиля `BasicButtonGroup`

| Параметр | Тип | Возможные значения |
| --- | --- | --- |
| `size` | `BasicButtonGroupSize` | `Xxs`, `Xs`, `S`, `M`, `L` |
| `gap` | `BasicButtonGroupGap` | `Wide`, `Dense`, `None` |
| `shape` | `BasicButtonGroupShape` | `Default`, `Segmented` |

Пример выбора готового стиля:
```kotlin
val style = ButtonGroupStyles.BasicButtonGroup.style(
    size = BasicButtonGroupSize.Xxs,
    gap = BasicButtonGroupGap.Wide,
    shape = BasicButtonGroupShape.Default
)

// или через dot notation
val style = BasicButtonGroup.Xxs.style()
```


### Параметры стиля `IconButtonGroup`

| Параметр | Тип | Возможные значения |
| --- | --- | --- |
| `size` | `IconButtonGroupSize` | `Xs`, `S`, `M`, `L` |
| `gap` | `IconButtonGroupGap` | `Wide`, `Dense`, `None` |
| `shape` | `IconButtonGroupShape` | `Default`, `Pilled`, `Segmented` |

Пример выбора готового стиля:
```kotlin
val style = ButtonGroupStyles.IconButtonGroup.style(
    size = IconButtonGroupSize.Xs,
    gap = IconButtonGroupGap.Wide,
    shape = IconButtonGroupShape.Default
)

// или через dot notation
val style = IconButtonGroup.Xs.style()
```


### Параметры стиля `AiHeaderEmbeddedIconButtonGroup`

| Параметр | Тип | Возможные значения |
| --- | --- | --- |
| `size` | `AiHeaderEmbeddedIconButtonGroupSize` | `S`, `M`, `L`, `Xl` |

Пример выбора готового стиля:
```kotlin
val style = ButtonGroupStyles.AiHeaderEmbeddedIconButtonGroup.style(
    size = AiHeaderEmbeddedIconButtonGroupSize.M
)

// или через dot notation
val style = AiHeaderEmbeddedIconButtonGroup.M.style()
```


### Параметры стиля `EmbeddedIconButtonGroup`

| Параметр | Тип | Возможные значения |
| --- | --- | --- |
| `size` | `EmbeddedIconButtonGroupSize` | `Xs`, `S`, `M`, `L` |
| `gap` | `EmbeddedIconButtonGroupGap` | `Wide`, `Dense`, `None` |

Пример выбора готового стиля:
```kotlin
val style = ButtonGroupStyles.EmbeddedIconButtonGroup.style(
    size = EmbeddedIconButtonGroupSize.M,
    gap = EmbeddedIconButtonGroupGap.Wide
)

// или через dot notation
val style = EmbeddedIconButtonGroup.M.style()
```


### Параметры стиля `AiAnswerIconButtonGroup`

| Параметр | Тип | Возможные значения |
| --- | --- | --- |
| `size` | `AiAnswerIconButtonGroupSize` | `Xs`, `S`, `M`, `L` |

Пример выбора готового стиля:
```kotlin
val style = ButtonGroupStyles.AiAnswerIconButtonGroup.style(
    size = AiAnswerIconButtonGroupSize.M
)

// или через dot notation
val style = AiAnswerIconButtonGroup.M.style()
```


### Параметры стиля `AiAnswerBasicButtonGroup`

| Параметр | Тип | Возможные значения |
| --- | --- | --- |
| `size` | `AiAnswerBasicButtonGroupSize` | `Xs`, `S`, `M`, `L` |

Пример выбора готового стиля:
```kotlin
val style = ButtonGroupStyles.AiAnswerBasicButtonGroup.style(
    size = AiAnswerBasicButtonGroupSize.M
)

// или через dot notation
val style = AiAnswerBasicButtonGroup.M.style()
```


### Параметры стиля `AiInputIconButtonGroup`

| Параметр | Тип | Возможные значения |
| --- | --- | --- |
| `size` | `AiInputIconButtonGroupSize` | `Xs`, `S`, `M`, `L` |
| `gap` | `AiInputIconButtonGroupGap` | `Wide`, `Dense`, `None` |
| `shape` | `AiInputIconButtonGroupShape` | `Default`, `Pilled`, `Segmented` |

Пример выбора готового стиля:
```kotlin
val style = ButtonGroupStyles.AiInputIconButtonGroup.style(
    size = AiInputIconButtonGroupSize.Xs,
    gap = AiInputIconButtonGroupGap.Wide,
    shape = AiInputIconButtonGroupShape.Default
)

// или через dot notation
val style = AiInputIconButtonGroup.Xs.style()
```


### Параметры стиля `AiUserMessageEmbeddedIconButtonGroup`

| Параметр | Тип | Возможные значения |
| --- | --- | --- |
| `size` | `AiUserMessageEmbeddedIconButtonGroupSize` | `S`, `M` |

Пример выбора готового стиля:
```kotlin
val style = ButtonGroupStyles.AiUserMessageEmbeddedIconButtonGroup.style(
    size = AiUserMessageEmbeddedIconButtonGroupSize.M
)

// или через dot notation
val style = AiUserMessageEmbeddedIconButtonGroup.M.style()
```


### Создание стиля с помощью builder() для базовой кнопки BasicButton

```kotlin
ButtonGroupStyle.builder()
    .externalShape(CircleShape)
    .internalShape(RoundedCornerShape(5))
    .buttonStyle(
        /** Стиль компонента */,
    )
    .dimensions {
        spacing(2.dp)
    }
    .style()
```

### Создание стиля с помощью builder() для кнопки с иконкой IconButton

```kotlin
ButtonGroupStyle.builder()
    .externalShape(CircleShape)
    .internalShape(RoundedCornerShape(5))
    .buttonStyle(
        /** Стиль компонента */,
    )
    .dimensions {
        spacing(2.dp)
    }
    .style()
```

<!-- @screenshot: com.sdds.compose.uikit.fixtures.samples.buttongroup.IconButtonGroup_Simple -->

## ButtonGroupOrientation

Способ расположения кнопок: по вертикали либо по горизонтали. Возможные значения: Horizontal, Vertical

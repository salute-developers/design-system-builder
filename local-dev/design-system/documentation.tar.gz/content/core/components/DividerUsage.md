---
title: Divider
---

Компонент Divider используется для визуального разделения контента.

```kotlin
Divider(
    modifier = Modifier,
    orientation = DividerOrientation.Horizontal,
)
```

## Стиль Divider

В большинстве случаев можно использовать готовые сгенерированные стили, а при необходимости создать собственный стиль через соответствующий builder. Подробнее о том, как работают `Style`, `StyleBuilder` и stateful-параметры стиля, см. в разделе [Стилизация компонентов](../theme/Styles.md).

Пример выбора готового стиля:
```kotlin
val style = DividerStyles.style()

// или через dot notation
val style = Divider.Default.style()
```


### Создание стиля с помощью builder()

```kotlin
DividerStyle.builder()
    .shape(CircleShape)
    .color {
        backgroundColor(/** Токен цвета */.asInteractive())
    }
    .dimensions {
        thickness(1.0.dp)
    }
    .style()
```

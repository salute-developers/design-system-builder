---
title: Notification
---

Всплывающий элемент — уведомление поверх контента.
В качестве контента ожидает [NotificationContent](NotificationContentUsage.md) либо произвольный контент.

Для корректной работы компонента необходимо обернуть контент в OverlayHost либо вручную провайдить менеджер уведомлений в [LocalOverlayManager](#overlaymanager).

```kotlin
Notification(
    hasClose = true,
    closeIcon = painterResource(com.sdds.icons.R.drawable.ic_close_24),
    onClose = { overlayManager.remove(it) },
) {
    NotificationContent(
        modifier = Modifier.fillMaxWidth(),
        title = "Title",
        text = "Notification Text",
        buttons = {
            button { Button(label = "Ok", onClick = {}) }
            button { Button(label = "Cancel", onClick = {}) }
        },
    )
}
```

<!-- @screenshot: com.sdds.compose.uikit.fixtures.samples.notification.Notification_Simple -->

## Стиль Notification

В большинстве случаев можно использовать готовые сгенерированные стили, а при необходимости создать собственный стиль через соответствующий builder. Подробнее о том, как работают `Style`, `StyleBuilder` и stateful-параметры стиля, см. в разделе [Стилизация компонентов](../theme/Styles.md).

### Параметры стиля `NotificationCompact`

| Параметр | Тип | Возможные значения |
| --- | --- | --- |
| `size` | `NotificationCompactSize` | `L`, `M`, `S` |

Пример выбора готового стиля:
```kotlin
val style = NotificationStyles.Compact.style(
    size = NotificationCompactSize.L
)

// или через dot notation
val style = NotificationCompact.L.style()
```


### Параметры стиля `NotificationLoose`

| Параметр | Тип | Возможные значения |
| --- | --- | --- |
| `size` | `NotificationLooseSize` | `L`, `M`, `S` |

Пример выбора готового стиля:
```kotlin
val style = NotificationStyles.Loose.style(
    size = NotificationLooseSize.L
)

// или через dot notation
val style = NotificationLoose.L.style()
```


### Создание стиля с помощью builder()

```kotlin
NotificationStyle.builder()
    .shadow(/** Токен тени */)
    .shape(/** Токе формы(скругления) */)
    .dimensions {
        closeSize(16.0.dp)
        paddingStart(8.dp)
        paddingEnd(8.dp)
        paddingTop(8.dp)
        paddingBottom(8.dp)
    }
    .colors {
        backgroundColor(SolidColor(Color.Gray))
        closeColor(Color.LightGray)
    }
    .notificationContentStyle(
        /** Стиль компонента */,
    )
    .style()
```

## OverlayManager

Менеджер уведомлений.

Можно использовать OverlayHost, который провайдит преднастроенный менеджер OverlayManager в контент.
Также менеджер можно создать с помощью функции overlayManager() и вручную провайдить созданный экземпляр в LocalOverlayManager.

```kotlin
OverlayHost {
    ...
    val overlayManager = LocalOverlayManager.current
    overlayManager.showNotification(
        durationMillis = 3000,
        position = OverlayPosition.BottomEnd,
        isFocusable = false,
    ) {...}
}
```

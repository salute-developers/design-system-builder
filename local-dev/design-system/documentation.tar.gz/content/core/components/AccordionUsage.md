---
title: Accordion
---
Вертикальный список с возможностью показать или скрыть связанный компонент.

В качестве контента ожидает AccordionItem и [Divider](DividerUsage.md#divider), стилизует их автоматически.

```kotlin
Accordion {
    repeat(4) {
        var opened by remember { mutableStateOf(false) }
        AccordionItem(
            opened = opened,
            onClick = { opened = !opened },
            title = "Title $it",
        ) { Text(text = "Content text $it") }
    }
}
```

<!-- @screenshot: com.sdds.compose.uikit.fixtures.samples.accordion.Accordion_Simple -->

## Стиль Accordion и AccordionItem

В большинстве случаев можно использовать готовые сгенерированные стили, а при необходимости создать собственный стиль через соответствующий builder. Подробнее о том, как работают `Style`, `StyleBuilder` и stateful-параметры стиля, см. в разделе [Стилизация компонентов](../theme/Styles.md).

### Параметры стиля `AccordionSolidActionStart`

| Параметр | Тип | Возможные значения |
| --- | --- | --- |
| `size` | `AccordionSolidActionStartSize` | `Xs`, `S`, `M`, `L`, `H2`, `H3`, `H4`, `H5` |

Пример выбора готового стиля:
```kotlin
val style = AccordionStyles.SolidActionStart.style(
    size = AccordionSolidActionStartSize.Xs
)

// или через dot notation
val style = AccordionSolidActionStart.Xs.style()
```


### Параметры стиля `AccordionSolidActionEnd`

| Параметр | Тип | Возможные значения |
| --- | --- | --- |
| `size` | `AccordionSolidActionEndSize` | `Xs`, `S`, `M`, `L`, `H2`, `H3`, `H4`, `H5` |

Пример выбора готового стиля:
```kotlin
val style = AccordionStyles.SolidActionEnd.style(
    size = AccordionSolidActionEndSize.Xs
)

// или через dot notation
val style = AccordionSolidActionEnd.Xs.style()
```


### Параметры стиля `AccordionClearActionStart`

| Параметр | Тип | Возможные значения |
| --- | --- | --- |
| `size` | `AccordionClearActionStartSize` | `Xs`, `S`, `M`, `L`, `H2`, `H3`, `H4`, `H5` |

Пример выбора готового стиля:
```kotlin
val style = AccordionStyles.ClearActionStart.style(
    size = AccordionClearActionStartSize.Xs
)

// или через dot notation
val style = AccordionClearActionStart.Xs.style()
```


### Параметры стиля `AccordionClearActionEnd`

| Параметр | Тип | Возможные значения |
| --- | --- | --- |
| `size` | `AccordionClearActionEndSize` | `Xs`, `S`, `M`, `L`, `H2`, `H3`, `H4`, `H5` |

Пример выбора готового стиля:
```kotlin
val style = AccordionStyles.ClearActionEnd.style(
    size = AccordionClearActionEndSize.Xs
)

// или через dot notation
val style = AccordionClearActionEnd.Xs.style()
```


### Создание стиля AccordionItemStyle с помощью builder()

```kotlin
AccordionItemStyle.builder()
    .iconPlacement(AccordionIconPlacement.End)
    .iconRotation(90.0f)
    .shape(/** Токен формы (скругления) */)
    .titleStyle(/** Токен типографики */)
    .contentTextStyle(/** Токен типографики */)
    .colors {
        backgroundColor(
            Color.White.asInteractive(
                setOf(InteractiveState.Pressed)
                    to /** Цвет в состоянии pressed */,
            ),
        )
        titleColor(
            Color.LightGray.asInteractive(
                setOf(InteractiveState.Hovered)
                    to /** Цвет в состоянии hovered */,
            ),
        )
        contentTextColor(
            Color.LightGray.asInteractive(
                setOf(InteractiveState.Hovered)
                    to /** Цвет в состоянии hovered */,
            ),
        )
    }
    .dimensions {
        contentPaddingStart(12.0.dp)
        contentPaddingEnd(12.0.dp)
        contentPaddingBottom(10.0.dp)
        paddingStart(12.0.dp)
        paddingEnd(12.0.dp)
        paddingTop(8.0.dp)
        paddingBottom(8.0.dp)
        iconPadding(10.0.dp)
    }
    .iconClosed(resourceImageSource(com.sdds.icons.R.drawable.ic_plus_16))
    .iconOpened(resourceImageSource(com.sdds.icons.R.drawable.ic_minus_16))
    .style()
```

### Создание стиля AccordionStyle с помощью builder()

```kotlin
AccordionStyle.builder()
    .accordionItemStyle(/** Стиль компонента */)
    .dividerStyle(/** Стиль компонента */)
    .dimensions {
        itemSpacing(4.0.dp)
    }
    .style()
```

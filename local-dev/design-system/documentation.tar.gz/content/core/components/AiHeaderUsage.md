---
title: AiHeader
---
Компонент шапки для AI-интерфейсов.

Содержит два опциональных слота для кнопок по краям и текстовый блок с заголовком и подзаголовком между ними.

```kotlin
AiHeader(
    modifier = Modifier.fillMaxWidth(),
    titleContent = { Text(text = "Заголовок") },
)
```

<!-- @screenshot: com.sdds.compose.uikit.fixtures.samples.aiheader.AiHeader_Simple -->

## Стиль AiHeader

В большинстве случаев можно использовать готовые сгенерированные стили, а при необходимости создать собственный стиль через соответствующий builder. Подробнее о том, как работают `Style`, `StyleBuilder` и stateful-параметры стиля, см. в разделе [Стилизация компонентов](../theme/Styles.md).

### Параметры стиля

| Параметр | Тип | Возможные значения |
| --- | --- | --- |
| `size` | `AiHeaderSize` | `Xs`, `S`, `M`, `L`, `Xl`, `H5`, `H4`, `H3`, `H2` |
| `view` | `AiHeaderView` | `Default`, `Secondary`, `Clear` |

Пример выбора готового стиля:
```kotlin
val style = AiHeaderStyles.style(
    size = AiHeaderSize.Xs,
    view = AiHeaderView.Default
)

// или через dot notation
val style = AiHeader.Xs.Default.style()
```


### Создание стиля с помощью builder()

```kotlin
AiHeaderStyle.builder()
    .shape(/** Токен формы (скругления) */)
    .titleStyle(/** Токен типографики */)
    .subtitleStyle(/** Токен типографики */)
    .colors {
        backgroundColor(/** Токен цвета */)
        titleColor(/** Токен цвета */)
        subtitleColor(/** Токен цвета */)
        dividerColor(/** Токен цвета */)
    }
    .dimensions {
        paddingStart(0.0.dp)
        paddingEnd(0.0.dp)
        paddingTop(0.0.dp)
        paddingBottom(0.0.dp)
        textPaddingStart(10.0.dp)
        textPaddingEnd(10.0.dp)
        textPaddingTop(9.0.dp)
        textPaddingBottom(9.0.dp)
        subtitlePadding(4.0.dp)
        dividerThickness(1.0.dp)
    }
    .startButtonStyle(
        /** Стиль кнопки слева */,
    )
    .endButtonStyle(
        /** Стиль кнопки справа */,
    )
    .style()
```

## Заголовок и подзаголовок

Заголовок передаётся в слот `titleContent`, подзаголовок — в `subtitleContent`. Если `subtitleContent` равен `null`, отступ между заголовком и подзаголовком не добавляется.

```kotlin
AiHeader(
    modifier = Modifier.fillMaxWidth(),
    titleContent = { Text(text = "Заголовок") },
    subtitleContent = { Text(text = "Подзаголовок") },
)
```

<!-- @screenshot: com.sdds.compose.uikit.fixtures.samples.aiheader.AiHeader_WithSubtitle -->

## AiHeaderTitleAlignment

Горизонтальное выравнивание текстового блока задаётся через параметр `titleAlignment`.
Возможные значения:

- `Start` — текст выровнен по левому краю (по умолчанию)
- `Center` — текст выровнен по центру
- `End` — текст выровнен по правому краю

```kotlin
AiHeader(
    modifier = Modifier.fillMaxWidth(),
    titleAlignment = AiHeaderTitleAlignment.Center,
    actionBefore = {
        IconButton(iconRes = R.drawable.ic_panel_sidebar_l_outline_24, onClick = {})
    },
    actionAfter = {
        IconButton(iconRes = R.drawable.ic_close_24, onClick = {})
    },
    titleContent = { Text(text = "Заголовок") },
    subtitleContent = { Text(text = "Подзаголовок") },
)
```

## Кнопки

Кнопки слева и справа управляются флагами `hasStartButton` и `hasEndButton`. Иконки и стили кнопок задаются в `AiHeaderStyle` через `startButtonIcon`, `startButtonStyle`, `endButtonIcon` и `endButtonStyle`.

```kotlin
AiHeader(
    modifier = Modifier.fillMaxWidth(),
    actionBefore = {
        IconButton(iconRes = R.drawable.ic_panel_sidebar_l_outline_24, onClick = { /* handle */ })
    },
    actionAfter = {
        IconButton(iconRes = R.drawable.ic_close_24, onClick = { /* handle */ })
    },
    titleContent = { Text(text = "Заголовок") },
    subtitleContent = { Text(text = "Подзаголовок") },
)
```

<!-- @screenshot: com.sdds.compose.uikit.fixtures.samples.aiheader.AiHeader_WithButtons -->

## Разделитель

Разделитель по нижнему краю компонента включается флагом `hasDivider`. Цвет и толщина разделителя задаются в стиле через `AiHeaderColors.dividerBrush` и `AiHeaderDimensions.dividerThickness`.

```kotlin
AiHeader(
    modifier = Modifier.fillMaxWidth(),
    separationType = AiHeaderSeparationType.Divider,
    actionBefore = {
        IconButton(iconRes = R.drawable.ic_panel_sidebar_l_outline_24, onClick = {})
    },
    actionAfter = {
        IconButton(iconRes = R.drawable.ic_close_24, onClick = {})
    },
    titleContent = { Text(text = "Заголовок") },
    subtitleContent = { Text(text = "Подзаголовок") },
)
```

<!-- @screenshot: com.sdds.compose.uikit.fixtures.samples.aiheader.AiHeader_WithDivider -->

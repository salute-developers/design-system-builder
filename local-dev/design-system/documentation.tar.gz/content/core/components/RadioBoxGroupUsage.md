---
title: RadioBoxGroup
---

Контент RadioBoxGroup формируется с помощью функции radioBoxItem() из скоупа RadioBoxGroupScope,
в которую передается уникальный ключ элмента группы.

```kotlin
RadioBoxGroup(
    default = 1,
) { selection ->
    radioBoxItem(key = 1) { key ->
        RadioBox(
            checked = isChecked(selection, key),
            label = "Label",
            description = "Description",
            onClick = { updateSelection(selection, key) },
        )
    }
    radioBoxItem(key = 2) { key ->
        RadioBox(
            checked = isChecked(selection, key),
            label = "Label",
            description = "Description",
            onClick = { updateSelection(selection, key) },
        )
    }
    radioBoxItem(key = 3) { key ->
        RadioBox(
            checked = isChecked(selection, key),
            label = "Label",
            description = "Description",
            onClick = { updateSelection(selection, key) },
        )
    }
}
```

<!-- @screenshot: com.sdds.compose.uikit.fixtures.samples.radiobox.group.RadioBoxGroup_Simple -->

## Стиль RadioBoxGroup

В большинстве случаев можно использовать готовые сгенерированные стили, а при необходимости создать собственный стиль через соответствующий builder. Подробнее о том, как работают `Style`, `StyleBuilder` и stateful-параметры стиля, см. в разделе [Стилизация компонентов](../theme/Styles.md).

### Параметры стиля

| Параметр | Тип | Возможные значения |
| --- | --- | --- |
| `size` | `RadioBoxGroupSize` | `M`, `S` |

Пример выбора готового стиля:
```kotlin
val style = RadioBoxGroupStyles.style(
    size = RadioBoxGroupSize.M
)

// или через dot notation
val style = RadioBoxGroup.M.style()
```


### Создание стиля с помощью builder()

```kotlin
RadioBoxGroupStyle.builder()
    .radioBoxStyle(/** Стиль компонента */)
    .dimensions {
        itemSpacing(12.0.dp)
    }
    .style()
```

---
title: CodeInput
---
Компонент CodeInput представляет собой горизонтальный ряд графических элементов (точек). Каждая точка вмещает в себя один символ, введеный с клавиатуры.

После каждого ввода символа происходит автоматических переход к следующему. 
После заполнения всех символов, если код верный, осуществляется автоматических переход к следующему действию. 
Если код неверный - значения в полях сбрасываются и ввод осуществляется снова с первого символа.

Заполнение полей возможно только по порядку. Если требуется вернуться назад к одному из символов - необходимо удалить все впереди стоящие символы тоже.

```kotlin
val focusRequester = remember { FocusRequester() }
val validCode = "123456"
val invalidChar = "q"
LaunchedEffect(Unit) { focusRequester.requestFocus() }
CodeInput(
    modifier = Modifier.focusRequester(focusRequester),
    codeLength = 6,
    hidden = true,
    onCodeComplete = { it == validCode },
    isItemValid = { it != invalidChar },
    caption = "Caption",
    captionAlignment = CodeInputCaptionAlignment.Center,
)
```

<!-- @screenshot: com.sdds.compose.uikit.fixtures.samples.codeinput.CodeInput_Simple -->

## Стиль CodeInput

В большинстве случаев можно использовать готовые сгенерированные стили, а при необходимости создать собственный стиль через соответствующий builder. Подробнее о том, как работают `Style`, `StyleBuilder` и stateful-параметры стиля, см. в разделе [Стилизация компонентов](../theme/Styles.md).

### Параметры стиля

| Параметр | Тип | Возможные значения |
| --- | --- | --- |
| `size` | `CodeInputSize` | `S`, `M`, `L` |

Пример выбора готового стиля:
```kotlin
val style = CodeInputStyles.style(
    size = CodeInputSize.S
)

// или через dot notation
val style = CodeInput.S.style()
```


### Создание стиля CodeInputStyle с помощью builder()

```kotlin
CodeInputStyle.builder()
    .codeStyle(/** Токен типографики */)
    .captionStyle(/** Токен типографики */)
    .colors {
        codeColor(
            /** Токен цвета */.asStatefulValue(
                setOf(CodeInputStates.Error)
                    to /** Цвет в состоянии error */,
            ),
        )
        captionColor(
            /** Токен типографики */.asStatefulValue(
                setOf(CodeInputStates.Error)
                    to /** Цвет в состоянии error */,
            ),
        )
        fillColor(
            /** Токен цвета */.asStatefulValue(
                setOf(CodeInputStates.Error)
                    to /** Цвет в состоянии error */,
            ),
        )
        strokeColor(
            /** Токен цвета */.asStatefulValue(
                setOf(CodeInputStates.Error)
                    to /** Цвет в состоянии error */,
            ),
        )
    }
    .dimensions {
        circleSize(16.0.dp)
        strokeWidth(1.5.dp)
        itemHeight(36.0.dp)
        itemWidth(60.0.dp)
        itemSpacing(8.0.dp)
        groupSpacing(28.0.dp)
        captionPadding(28.0.dp)
    }
    .style()
```

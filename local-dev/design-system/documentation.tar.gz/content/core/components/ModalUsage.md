---
title: Modal
---

Модальное окно — это всплывающее окно, появляющееся поверх текущей страницы и блокирующее доступ к основному содержимому страницы. 
Если модальное окно необходимо наложить поверх затемненного экрана, то используйте фон с токенами цвета из группы Overlay.

```kotlin
val showModal = remember { mutableStateOf(false) }
Button(
    label = "Show modal",
    onClick = { showModal.value = true },
)
Modal(
    show = showModal.value,
    onDismissRequest = { showModal.value = false },
    modifier = Modifier.width(300.dp),
    hasClose = true,
    closeIcon = painterResource(com.sdds.icons.R.drawable.ic_close_24),
    dimBackground = true,
    useNativeBlackout = true,
) {
    Column {
        Text("Заголовок")
        Spacer(modifier = Modifier.padding(8.dp))
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.Center,
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Button(
                    modifier = Modifier.align(Alignment.CenterVertically),
                    label = "Ок",
                    onClick = {
                        showModal.value = false
                    },
                )
                Button(
                    modifier = Modifier.align(Alignment.CenterVertically),
                    label = "Отмена",
                    onClick = {
                        showModal.value = false
                    },
                )
            }
        }
    }
}
```

<!-- @screenshot: com.sdds.compose.uikit.fixtures.samples.modal.Modal_Simple -->

## Стиль Modal

В большинстве случаев можно использовать готовые сгенерированные стили, а при необходимости создать собственный стиль через соответствующий builder. Подробнее о том, как работают `Style`, `StyleBuilder` и stateful-параметры стиля, см. в разделе [Стилизация компонентов](../theme/Styles.md).

Пример выбора готового стиля:
```kotlin
val style = ModalStyles.style()

// или через dot notation
val style = Modal.Default.style()
```


### Создание стиля с помощью builder()

```kotlin
ModalStyle.builder()
    .shadow(/** Токен тени */)
    .shape(/** Токен формы (скругления) */)
    .dimensions {
        closeSize(16.0.dp)
        paddingStart(8.dp)
        paddingEnd(8.dp)
        paddingTop(8.dp)
        paddingBottom(8.dp)
    }
    .colors {
        backgroundColor(SolidColor(Color.Gray))
        closeColor(Color.LightGray)
    }
    .style()
```

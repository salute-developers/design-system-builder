---
title: ProgressBar
---

Горизонтальный прогресс.

```kotlin
ProgressBar(
    progress = 0.25f,
    modifier = Modifier.width(240.dp),
)
```

<!-- @screenshot: com.sdds.compose.uikit.fixtures.samples.progress.Progress_Simple -->

## Стиль ProgressBar

В большинстве случаев можно использовать готовые сгенерированные стили, а при необходимости создать собственный стиль через соответствующий builder. Подробнее о том, как работают `Style`, `StyleBuilder` и stateful-параметры стиля, см. в разделе [Стилизация компонентов](../theme/Styles.md).

### Параметры стиля

| Параметр | Тип | Возможные значения |
| --- | --- | --- |
| `view` | `ProgressBarView` | `Default`, `Secondary`, `Accent`, `Gradient`, `Info`, `Negative`, `Positive`, `Warning` |

Пример выбора готового стиля:
```kotlin
val style = ProgressBarStyles.style(
    view = ProgressBarView.Default
)

// или через dot notation
val style = ProgressBar.Default.style()
```


### Создание стиля с помощью builder()

```kotlin
ProgressBarStyle.builder()
    .colorValues {
        backgroundColor(/** Токен цвета */.asInteractive())
        indicatorColor(/** Токен цвета */.asInteractive())
    }
    .indicatorShape(CircleShape)
    .backgroundShape(CircleShape)
    .dimensionValues {
        indicatorHeight(4.0.dp)
        backgroundHeight(4.0.dp)
    }
    .style()
```

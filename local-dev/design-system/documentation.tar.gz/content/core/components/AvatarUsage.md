---
title: Avatar
---

```kotlin
Avatar(
    status = AvatarStatus.Active,
    placeholder = AvatarPlaceholder.Name("Michael Scott"),
)
```

<!-- @screenshot: com.sdds.compose.uikit.fixtures.samples.avatar.Avatar_Simple -->

## Стиль Avatar

В большинстве случаев можно использовать готовые сгенерированные стили, а при необходимости создать собственный стиль через соответствующий builder. Подробнее о том, как работают `Style`, `StyleBuilder` и stateful-параметры стиля, см. в разделе [Стилизация компонентов](../theme/Styles.md).

### Параметры стиля

| Параметр | Тип | Возможные значения |
| --- | --- | --- |
| `size` | `AvatarSize` | `Xxl`, `L`, `M`, `S` |

Пример выбора готового стиля:
```kotlin
val style = AvatarStyles.style(
    size = AvatarSize.Xxl
)

// или через dot notation
val style = Avatar.Xxl.style()
```


### Создание стиля с помощью builder()

```kotlin
AvatarStyle.builder()
    .shape(CircleShape)
    .colors {
        backgroundColor(/** Токен градиента */.asStatefulValue())
        textColor(/** Токен градиента */.asStatefulValue())
    }
    .dimensions {
        width(88.0.dp)
        height(88.0.dp)
    }
    .textStyle(/** Токен типографики */)
    .badgeStyle(/** Стиль компонента */)
    .counterStyle(/** Стиль компонента */)
    .statusStyle(
        IndicatorStyle.builder()
            .color {
                backgroundColor(
                    /** Токен цвета */.asInteractive(
                        setOf(AvatarStatus.Active)
                            to /** Цвет в состоянии active */,
                    ),
                )
            }
            .style(),
    )
    .style()
```

## Статус Avatar

Статус задается с помощью свойства status. Возможные значения: "active", "inactive", "none".

```kotlin
Avatar(status = AvatarStatus.Active)
```

## Инициалы вместо фотографии

Если не задан ресурс изображения, инициалы можно задать с помощью свойства placeholder -> name. Желательный формат строки - "Имя Фамилия".

```kotlin
Avatar(
    status = AvatarStatus.Active,
    actionEnabled = false,
    placeholder = AvatarPlaceholder.Name("Michael Scott"),
)
```

## Дополнительный контент

Дополнительный контент ("обвесы") устанавливается с помощью свойства extra.
В качестве дополнительного контента предполагается использование Counter или Badge, стиль которых уже определен стилем самого Avatar.
В этом случае в extra нужно передать Badge с параметром label или Counter c параметром count.
Положение extra контента задается через Modifier.align.

```kotlin
Avatar(
    placeholder = AvatarPlaceholder.Name("Michael Scott"),
    extra = {
        Counter(
            modifier = Modifier.align(Alignment.TopEnd),
            count = "1",
        )
    },
    content = { },
)
```

<!-- @screenshot: com.sdds.compose.uikit.fixtures.samples.avatar.Avatar_Extra -->

## Avatar как extension к Modifier

Модификатор, который декорирует компонент как аватар. Его можно использовать в ситуациях, когда Avatar использовать не удается.
Например, когда используются собственная или библиотечная реализация: GlideImage() библиотеки Glide Compose или AsyncImage библиотеки coil.

```kotlin
AsyncImage(
    modifier = Modifier.avatar(
        shape: Shape = RoundedCornerShape(50),
        statusColor: Color = Color.DarkGray,
        statusSize: Dp = 8.dp,
        statusOffset: Offset = Offset.Zero,
    ),
    model = "https://cdn.example.com/test.png",
)
```

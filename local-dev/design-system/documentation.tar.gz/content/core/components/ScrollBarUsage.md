---
title: ScrollBar
---

Интерактивный индикатор для горизонтального или вертикального перемещения по контенту.

Предусмотрены две Composable функции для работы с ScrollState и LazyListState.

### ScrollBar для обычного списка

```kotlin
val scrollState = rememberScrollState()
Box {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(scrollState),
    ) {
        repeat(100) {
            Text(text = "Item $it")
        }
    }
    ScrollBar(
        modifier = Modifier.align(Alignment.CenterEnd),
        scrollState = scrollState,
        orientation = Orientation.Vertical,
        alwaysShowScrollbar = true,
        hasTrack = true,
        hoverExpand = false,
    )
}
```

### ScrollBar для ленивого списка

```kotlin
val lazyState = rememberLazyListState()
Box {
    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        state = lazyState,
    ) {
        items(100) {
            Text(text = "Item $it")
        }
    }
    ScrollBar(
        modifier = Modifier.align(Alignment.CenterEnd),
        scrollState = lazyState,
        alwaysShowScrollbar = true,
        hasTrack = true,
        hoverExpand = true,
    )
}
```

## Стиль ScrollBar

В большинстве случаев можно использовать готовые сгенерированные стили, а при необходимости создать собственный стиль через соответствующий builder. Подробнее о том, как работают `Style`, `StyleBuilder` и stateful-параметры стиля, см. в разделе [Стилизация компонентов](../theme/Styles.md).

### Параметры стиля

| Параметр | Тип | Возможные значения |
| --- | --- | --- |
| `size` | `ScrollBarSize` | `S`, `M` |

Пример выбора готового стиля:
```kotlin
val style = ScrollBarStyles.style(
    size = ScrollBarSize.S
)

// или через dot notation
val style = ScrollBar.S.style()
```


### Создание стиля с помощью builder()

```kotlin
ScrollBarStyle.builder()
    .colors {
        trackColor(/** Токен цвета */.asInteractive())
        thumbColor(/** Токен цвета */.asInteractive())
    }
    .shape(CircleShape)
    .hoverExpandFactor(2.0f)
    .dimensions {
        width(4.0.dp)
    }
    .style()
```

---
title: Overlay
---

Стилизованный контейнер на основе Box, который располагается поверх остального контента и используется для оформления полупрозрачных подложек, модальных слоёв и вспомогательных поверхностeй.

Overlay можно использовать, например, для:

- затемнения (scrim) основного экрана при показе модальных окон или bottom sheet;
- подложки под плавающие кнопки управления, тулбары, панели действий;
- отображения системных оверлеев: лоадеров, тостов, хинтов;
- блокировки/перехвата ввода поверх основного экрана.


```kotlin
Overlay(
    modifier = Modifier.fillMaxSize(),
) {
    IconButton(
        modifier = Modifier
            .align(Alignment.TopEnd)
            .padding(end = 8.dp, top = 8.dp),
        iconRes = com.sdds.icons.R.drawable.ic_close_24,
        onClick = {},
    )
}
```

## Параметр `alpha`

Параметр `alpha` в `Overlay` задаётся как лямбда `() -> Float`, а не как простое значение. Это позволяет:

- удобно подключить анимации появления/исчезновения (fade in / fade out) через `animateFloatAsState`, `updateTransition` или любые другие анимационные API;
- динамически менять прозрачность оверлея в зависимости от состояния экрана (например, от прогресса жеста, значения скролла или текущего шага сценария).

Примеры сценариев:

- **Анимация появления модального слоя** — при показе диалога анимируйте `alpha` от `0f` до значения, определённого стилем (например, `0.6f`), чтобы фон плавно затемнялся.
- **Зависимость от скролла** — считайте коэффициент прозрачности из позиции списка или `NestedScrollConnection` и возвращайте его из лямбды `alpha`, чтобы оверлей становился более/менее заметным при прокрутке.

Благодаря тому, что `alpha` — это функция, Overlay всегда читает актуальное значение прозрачности при каждом ре-композе, и вам не нужно вручную обновлять модификатор.

### Пример изменения alpha в зависимости от скролла

Для List:
```kotlin
val listState = rememberLazyListState()
val scrollOffset by remember {
    derivedStateOf {
        listState.firstVisibleItemIndex * (
            listState.layoutInfo.visibleItemsInfo.firstOrNull()?.size
                ?: 0
            ) +
            listState.firstVisibleItemScrollOffset
    }
}
```

Для Modifier.verticalScroll():
```kotlin
val scrollState = rememberScrollState()
val scrollOffset by remember {
    derivedStateOf {
        scrollState.value.toFloat()
    }
}
```

Изменяем альфу в Overlay:
```kotlin
Overlay(
style = Overlay.Default.style(),
alpha = {
(scrollOffset / ScrollThresholdPx).coerceIn(0f, 1f)
},
) {
    // content
}
```

## Параметры компонента Overlay

| Параметр           | Тип                                              | Описание                                                                                          |
|--------------------|--------------------------------------------------|---------------------------------------------------------------------------------------------------|
| modifier           | Modifier                                         | Модификатор для изменения внешнего вида и поведения компонента.                                   |
| style              | OverlayStyle                                     | Стиль оформления Overlay (цвета и др.).                                                           |
| interactionSource  | MutableInteractionSource                         | Источник взаимодействий для отслеживания состояний взаимодействия.                                |
| alpha              | () -> Float                                      | Лямбда, возвращающая прозрачность Overlay (поддержка анимаций и динамики).                        |
| content            | @Composable BoxScope.() -> Unit                  | Контент, размещаемый внутри Overlay.                                                              |

## Параметры OverlayStyle

| Параметр           | Тип                                              | Описание                                                                                          |
|--------------------|--------------------------------------------------|---------------------------------------------------------------------------------------------------|
| colors.backgroundColor | `StatefulValue<Brush>`                         | Цвет фона Overlay. Может быть SolidColor или градиент, поддерживает состояния взаимодействия.      |

В большинстве случаев можно использовать готовые сгенерированные стили, а при необходимости создать собственный стиль через соответствующий builder. Подробнее о том, как работают `Style`, `StyleBuilder` и stateful-параметры стиля, см. в разделе [Стилизация компонентов](../theme/Styles.md).

Пример выбора готового стиля:
```kotlin
val style = OverlayStyles.style()

// или через dot notation
val style = Overlay.Default.style()
```


### Создание стиля с помощью builder()

```kotlin
OverlayStyle.builder()
    .color {
        backgroundColor(SolidColor(Color.Gray))
    }
    .style()
```

---
title: CodeField
---
Компонент CodeField представляет собой горизонтальный ряд текстовых полей. Каждое поле вмещает в себя один символ, введеный с клавиатуры.

После каждого ввода символа происходит автоматических переход к следующему.  
После заполнения всех символов, если код верный, осуществляется автоматических переход к следующему действию.  
Если код неверный - значения в полях сбрасываются и ввод осуществляется снова с первого символа.

Заполнение полей возможно только по порядку. Если требуется вернуться назад к одному из символов - необходимо удалить все впереди стоящие символы тоже.

```kotlin
val focusRequester = remember { FocusRequester() }
val validCode = "123456"
val invalidChar = "q"
LaunchedEffect(Unit) { focusRequester.requestFocus() }
CodeField(
    modifier = Modifier.focusRequester(focusRequester),
    codeLength = 6,
    hidden = true,
    onCodeComplete = { it == validCode },
    isItemValid = { it != invalidChar },
    caption = "Caption",
    captionAlignment = CodeFieldCaptionAlignment.Center,
)
```

<!-- @screenshot: com.sdds.compose.uikit.fixtures.samples.codefield.CodeField_Simple -->

## Стиль CodeField

В большинстве случаев можно использовать готовые сгенерированные стили, а при необходимости создать собственный стиль через соответствующий builder. Подробнее о том, как работают `Style`, `StyleBuilder` и stateful-параметры стиля, см. в разделе [Стилизация компонентов](../theme/Styles.md).

### Параметры стиля

| Параметр | Тип | Возможные значения |
| --- | --- | --- |
| `size` | `CodeFieldSize` | `L`, `M` |
| `shape` | `CodeFieldShape` | `Default`, `Segmented` |

Пример выбора готового стиля:
```kotlin
val style = CodeFieldStyles.style(
    size = CodeFieldSize.L,
    shape = CodeFieldShape.Default
)

// или через dot notation
val style = CodeField.L.style()
```


### Создание стиля CodeFieldStyle с помощью builder()

```kotlin
CodeFieldStyle.builder()
    .itemShape(/** Токен формы (скругления) */)
    .groupShape(/** Токен формы (скругления) */)
    .valueStyle(/** Токен типографики */)
    .captionStyle(/** Токен типографики */)
    .colors {
        valueColor(
            /** Токен цвета */.asStatefulValue(
                setOf(CodeInputStates.Error)
                    to /** Цвет в состоянии error */,
            ),
        )
        captionColor(
            /** Токен цвета */.asStatefulValue(
                setOf(CodeInputStates.Error)
                    to /** Цвет в состоянии error */,
            ),
        )
        dotColor(
            /** Токен цвета */.asStatefulValue(
                setOf(CodeInputStates.Error)
                    to /** Токен цвета */,
            ),
        )
        backgroundColor(
            /** Токен цвета */.asStatefulValue(
                setOf(CodeInputStates.Error)
                    to /** Цвет в состоянии error */,
                setOf(InteractiveState.Activated)
                    to /** Цвет в состоянии activated */,
            ),
        )
        cursorColor(/** Токен цвета */)
    }
    .dimensions {
        dotSize(16.0.dp)
        height(36.0.dp)
        width(60.0.dp)
        itemSpacing(8.0.dp)
        groupSpacing(28.0.dp)
        captionSpacing(28.0.dp)
    }
    .style()
```

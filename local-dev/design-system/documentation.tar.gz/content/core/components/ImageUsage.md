---
title: Image
---

Технический компонент отображения изображений.

В качестве источника поддерживает Painter, ImageVector или ImageBitmap.

```kotlin
Image(
    modifier = Modifier
        .width(100.dp)
        .background(Color.Gray),
    painter = painterResource(com.sdds.icons.R.drawable.ic_alarm_done_fill_36),
    contentDescription = "image",
    contentScale = ContentScale.Fit,
    alignment = Alignment.Center,
)
```

<!-- @screenshot: com.sdds.compose.uikit.fixtures.samples.image.Image_Simple -->

## Стиль Image

В большинстве случаев можно использовать готовые сгенерированные стили, а при необходимости создать собственный стиль через соответствующий builder. Подробнее о том, как работают `Style`, `StyleBuilder` и stateful-параметры стиля, см. в разделе [Стилизация компонентов](../theme/Styles.md).

### Параметры стиля

| Параметр | Тип | Возможные значения |
| --- | --- | --- |
| `ratio` | `ImageRatio` | `Ratio12`, `Ratio916`, `Ratio34`, `Ratio21`, `Ratio169`, `Ratio43`, `Ratio11` |

Пример выбора готового стиля:
```kotlin
val style = ImageStyles.style(
    ratio = ImageRatio.Ratio12
)

// или через dot notation
val style = Image.Ratio1x2.style()
```


### Создание стиля с помощью builder()

```kotlin
ImageStyle.builder()
    .ratio(2f)
    .style()
```

## Поддержка стиля Image для других компонентов

Чтобы поддержать стиль Image в произвольном компоненте, нужно использовать модификатор image(style: ImageStyle)

```kotlin
AsyncImage(
    modifier = Modifier
        .width(100.dp)
        .image(Image.Ratio3x4.style())
        .background(Color.Gray),
    model = "https://cdn.costumewall.com/wp-content/uploads/2018/09/michael-scott.jpg",
    contentDescription = "image",
    contentScale = ContentScale.Crop,
)
```
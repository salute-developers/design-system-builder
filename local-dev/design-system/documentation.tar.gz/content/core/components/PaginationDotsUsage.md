---
title: PaginationDots
---

`PaginationDots` — индикатор пагинации в виде ряда точек. Компонент подходит для каруселей, горизонтальных/вертикальных списков и любых сценариев, где нужно показать общее количество страниц и текущую.

Поддерживает анимации активной точки, окно видимости (если страниц больше, чем точек на экране), уменьшение «краевых» индикаторов и настраиваемые размеры/цвета через StatefulValue.

## Основные возможности

- Отображение текущей страницы среди общего количества.
- Окно видимости при большом количестве страниц (скролл точек с анимацией).
- «Краевые» индикаторы с постепенным уменьшением (подсказка о скрытых страницах).
- Горизонтальная или вертикальная ориентация.
- Кастомизация размеров и цвета точки по состояниям (обычная/активная).

## Пример использования

```kotlin
Column {
    var selectedIndex by remember { mutableIntStateOf(0) }
    PaginationDots(
        selectedIndex = selectedIndex,
        totalCount = 11,
        visibleCount = 5,
    )
    Spacer(Modifier.size(16.dp))
    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        IconButton(
            iconRes = com.sdds.icons.R.drawable.ic_arrow_left_24,
            onClick = {
                // для корректной работы необходимо следить, чтобы индекс не выходил за пределы totalCount
                selectedIndex = selectedIndex.minus(1).coerceIn(0, 10)
            },
        )
        IconButton(
            iconRes = com.sdds.icons.R.drawable.ic_arrow_right_24,
            onClick = {
                // для корректной работы необходимо следить, чтобы индекс не выходил за пределы totalCount
                selectedIndex = selectedIndex.plus(1).coerceIn(0, 10)
            },
        )
    }
}
```

<!-- @screenshot: com.sdds.compose.uikit.fixtures.samples.paginationdots.PaginationDots_Simple -->

> Для корректной работы необходимо следить, чтобы selectedIndex не выходил за пределы общего количества точек totalCount

## Стиль PaginationDots

В большинстве случаев можно использовать готовые сгенерированные стили, а при необходимости создать собственный стиль через соответствующий builder. Подробнее о том, как работают `Style`, `StyleBuilder` и stateful-параметры стиля, см. в разделе [Стилизация компонентов](../theme/Styles.md).

### Параметры стиля `PaginationDotsHorizontal`

| Параметр | Тип | Возможные значения |
| --- | --- | --- |
| `size` | `PaginationDotsHorizontalSize` | `M`, `S` |
| `activeType` | `PaginationDotsHorizontalActiveType` | `Default`, `Line` |

Пример выбора готового стиля:
```kotlin
val style = PaginationDotsStyles.Horizontal.style(
    size = PaginationDotsHorizontalSize.M,
    activeType = PaginationDotsHorizontalActiveType.Default
)

// или через dot notation
val style = PaginationDotsHorizontal.M.style()
```


### Параметры стиля `PaginationDotsVertical`

| Параметр | Тип | Возможные значения |
| --- | --- | --- |
| `size` | `PaginationDotsVerticalSize` | `M`, `S` |
| `activeType` | `PaginationDotsVerticalActiveType` | `Default`, `Line` |

Пример выбора готового стиля:
```kotlin
val style = PaginationDotsStyles.Vertical.style(
    size = PaginationDotsVerticalSize.M,
    activeType = PaginationDotsVerticalActiveType.Default
)

// или через dot notation
val style = PaginationDotsVertical.M.style()
```


### Создание стиля с помощью builder()

```kotlin
PaginationDotsStyle.builder()
    .orientation(PaginationDotsOrientation.Vertical)
    .edgeShrinkFactor(0.3f)
    .edgeCount(2)
    .colors {
        dotBackgroundColor(
            /** Токен цвета */.asStatefulValue(
                setOf(InteractiveState.Activated)
                    to /** Цвет в состоянии activated */,
            ),
        )
    }
    .dimensions {
        gap(6.0.dp)
        dotWidth(8.0.dp)
        dotHeight(
            8.0.dp.asStatefulValue(
                setOf(InteractiveState.Activated) to 32.0.dp,
            ),
        )
    }
    .style()
```
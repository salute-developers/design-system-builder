---
title: Splitter
---

Компонент Splitter используется для разделения контента. В отличие от компонента Divider  
имеет возможность отображать ручку. Splitter применяется в интерфейсах, когда пользователь  
должен изменить соотношение размеров между двумя (или более) соседними областями.  

```kotlin
Splitter(
    modifier = Modifier,
    orientation = SplitterOrientation.Horizontal,
    hasHandle = true,
)
```

## Стиль Splitter

В большинстве случаев можно использовать готовые сгенерированные стили, а при необходимости создать собственный стиль через соответствующий builder. Подробнее о том, как работают `Style`, `StyleBuilder` и stateful-параметры стиля, см. в разделе [Стилизация компонентов](../theme/Styles.md).

:::warning
Компонент не входит в текущую дизайн-систему.
:::

### Создание стиля с помощью builder()

```kotlin
SplitterStyle.builder()
    .dividerShape(CircleShape)
    .handleShape(CircleShape)
    .color {
        dividerColor(/** Токен цвета */.asInteractive())
        handleColor(/** Токен цвета */.asInteractive())
    }
    .dimensions {
        dividerThickness(2.0.dp)
        handleThickness(1.0.dp)
        handleStartPadding(3.0.dp)
        handleEndPadding(3.0.dp)
        handleTopPadding(3.0.dp)
        handleBottomPadding(3.0.dp)
        handleSpacer(5.0.dp)
        gap(22.0.dp)
    }
    .style()
```
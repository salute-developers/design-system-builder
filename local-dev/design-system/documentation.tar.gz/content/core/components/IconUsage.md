---
title: Icon
---

`Icon` используется для отображения изображений в разных форматах через `ImageSource`,  
с поддержкой окрашивания через `brushProducer` и семантического описания контента для систем доступности.  

```kotlin
Icon(
    source = resourceImageSource(com.sdds.icons.R.drawable.ic_alarm_done_fill_36),
    contentDescription = "Будильник",
)
```

<!-- @screenshot: com.sdds.compose.uikit.fixtures.samples.icon.Icon_Simple -->

## Варианты использования

`Icon` принимает `ImageSource`, который можно создать из нескольких типов источников:

- drawable-ресурс

- Painter

- ImageVector

- ImageBitmap

### Drawable resource

Для ресурсов удобно использовать `resourceImageSource`. 

```kotlin
Icon(
    source = resourceImageSource(com.sdds.icons.R.drawable.ic_alarm_done_fill_36),
    contentDescription = "Будильник",
)
```

### Painter

Используется, если необходимо вручную создать `ImageSource` на основе `Painter`:  

```kotlin
Icon(
    source = { painterResource(com.sdds.icons.R.drawable.ic_alarm_done_fill_36) },
    contentDescription = "Иконка из Painter",
)
```

### ImageVector

Используется для отображения векторной иконки через `ImageVector`.

```kotlin
Icon(
    source = imageVectorSource(yourImageVector),
    contentDescription = "Иконка из ImageVector",
)
```

<!-- @screenshot: com.sdds.compose.uikit.fixtures.samples.icon.Icon_Image -->

### ImageBitmap

Используется для отображения растровых изображений:

```kotlin
Icon(
    source = bitmapSource(yourBitmap),
    contentDescription = "Иконка из ImageBitmap",
)
```

## Цвет и кисть

Если нужен общий цвет по умолчанию, его можно задать через composition local `LocalTintBrushProducer`:

```kotlin
CompositionLocalProvider(LocalTintBrushProducer provides { Color.Red.asBrush() }) {
    Icon(
        source = resourceImageSource(com.sdds.icons.R.drawable.ic_alarm_done_fill_36),
        contentDescription = null,
    )
}
```

или напрямую через `brushProducer`:

```kotlin
Icon(
    source = resourceImageSource(com.sdds.icons.R.drawable.ic_alarm_done_fill_36),
    contentDescription = "Иконка с brush",
    brush = {
        Brush.linearGradient(
            colors = listOf(Color(0xFFF2994A), Color(0xFFEB5757)),
        )
    },
)
```

<!-- @screenshot: com.sdds.compose.uikit.fixtures.samples.icon.IconCompositionLocal_Simple -->

## Настройка размера

Размер изображения (иконки) определяется:  

- либо intrinsic-size Painter,

- либо значением из `LocalIconDefaultSize` (специальный CompositionLocal)

```kotlin
CompositionLocalProvider(LocalIconDefaultSize provides DpSize(24.dp, 24.dp)) {
    Icon(
        source = resourceImageSource(com.sdds.icons.R.drawable.ic_alarm_done_fill_36),
        contentDescription = null,
    )
}
```

<!-- @screenshot: com.sdds.compose.uikit.fixtures.samples.icon.IconCompositionLocalSize_Simple -->

## Semantics

 Если передан contentDescription, иконка будет доступна для систем доступности (например TalkBack).  
 Если contentDescripition не указан, иконка считается декоративной и не будет озвучиваться.

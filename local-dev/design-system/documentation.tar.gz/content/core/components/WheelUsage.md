---
title: Wheel
---

Вертикальное колесо выбора. 
Используется для выбора одного значения из списка с визуальным фокусом на текущем значении.

### Простой пример Wheel с одним колесом

```kotlin
Wheel(
    wheelCount = 1,
    visibleItemsCount = 3,
    onItemSelected = { wheelIndex, itemIndex ->
        println("item selected: $itemIndex in wheel $wheelIndex")
    },
) { wheelIndex ->
    WheelDataSet(
        dataSet = List(10) {
            WheelItemData(
                text = "Label$wheelIndex",
                textAfter = "TA$wheelIndex",
            )
        },
        description = "Description",
    )
}
```

<!-- @screenshot: com.sdds.compose.uikit.fixtures.samples.wheel.Wheel_Simple -->

### Пример будильника с контролами и разделителем "двоеточие"
```kotlin
Wheel(
    wheelCount = 2,
    visibleItemsCount = 3,
    hasControls = true,
    wheelSeparator = WheelSeparator.Dots,
    alignment = WheelAlignment.Mixed,
    onItemSelected = { wheelIndex, itemIndex ->
        println("item selected: $itemIndex in wheel $wheelIndex")
    },
) { wheelIndex ->
    return@Wheel when (wheelIndex) {
        0 -> {
            WheelDataSet(
                dataSet = List(24) {
                    WheelItemData(
                        text = "${it + 1}",
                        textAfter = "ч.",
                    )
                },
                description = "Часы",
            )
        }
        else -> {
            WheelDataSet(
                dataSet = List(60) {
                    WheelItemData(
                        text = "${it + 1}",
                        textAfter = "мин.",
                    )
                },
                description = "Минуты",
            )
        }
    }
}
```

<!-- @screenshot: com.sdds.compose.uikit.fixtures.samples.wheel.Wheel_AlarmClockWithControlsAndSeparator -->

### Пример будильника с выраниванием по центру и Divider в качестве разделителя
```kotlin
Wheel(
    wheelCount = 2,
    visibleItemsCount = 5,
    hasControls = true,
    wheelSeparator = WheelSeparator.Divider,
    alignment = WheelAlignment.Center,
    onItemSelected = { wheelIndex, itemIndex ->
        println("item selected: $itemIndex in wheel $wheelIndex")
    },
) { wheelIndex ->
    return@Wheel when (wheelIndex) {
        0 -> {
            WheelDataSet(
                dataSet = List(24) {
                    WheelItemData(
                        text = "${it + 1}",
                        textAfter = "ч.",
                    )
                },
                description = "Часы",
            )
        }
        else -> {
            WheelDataSet(
                dataSet = List(60) {
                    WheelItemData(
                        text = "${it + 1}",
                        textAfter = "мин.",
                    )
                },
                description = "Минуты",
            )
        }
    }
}
```

<!-- @screenshot: com.sdds.compose.uikit.fixtures.samples.wheel.Wheel_CenteredAlarmClockWithControlsAndDivider -->

### Пример будильника с расположением чисел на колесе, начиная сверху колеса
```kotlin
Wheel(
    wheelCount = 2,
    dataEdgePlacement = DataEdgePlacement.WheelEdge,
    onItemSelected = { wheelIndex, itemIndex ->
        println("item selected: $itemIndex in wheel $wheelIndex")
    },
) { wheelIndex ->
    return@Wheel when (wheelIndex) {
        0 -> {
            WheelDataSet(
                dataSet = List(24) {
                    WheelItemData(
                        text = "${it + 1}",
                        textAfter = "ч.",
                    )
                },
                description = "Часы",
            )
        }
        else -> {
            WheelDataSet(
                dataSet = List(60) {
                    WheelItemData(
                        text = "${it + 1}",
                        textAfter = "мин.",
                    )
                },
                description = "Минуты",
            )
        }
    }
}
```

<!-- @screenshot: com.sdds.compose.uikit.fixtures.samples.wheel.Wheel_AlarmClockWithEdgePlacement -->

## Стиль Wheel

В большинстве случаев можно использовать готовые сгенерированные стили, а при необходимости создать собственный стиль через соответствующий builder. Подробнее о том, как работают `Style`, `StyleBuilder` и stateful-параметры стиля, см. в разделе [Стилизация компонентов](../theme/Styles.md).

:::warning
Компонент не входит в текущую дизайн-систему.
:::

### Создание стиля с помощью builder()

```kotlin
WheelStyle.builder()
    .controlIconUp(resourceImageSource(com.sdds.icons.R.drawable.ic_disclosure_up_outline_36))
    .controlIconDown(resourceImageSource(com.sdds.icons.R.drawable.ic_disclosure_down_outline_36))
    .wheelCount(3)
    .visibleItemsCount(3)
    .colors {
        itemTextColor(/** Токен цвета */.asInteractive())
        itemTextAfterColor(/** Токен цвета */.asInteractive())
        descriptionColor(/** Токен цвета */.asInteractive())
        controlIconUpColor(
            /** Токен цвета */.asInteractive(
                setOf(InteractiveState.Focused)
                    to /** Токен цвета в состоянии focused */,
            ),
        )
        controlIconDownColor(
            /** Токен цвета */.asInteractive(
                setOf(InteractiveState.Focused)
                    to /** Токен цвета в состоянии focused */,
            ),
        )
        separatorColor(/** Токен цвета */.asInteractive())
    }
    .itemTextStyle(/** Токен типографики */)
    .itemTextAfterStyle(/** Токен типографики */)
    .descriptionStyle(/** Токен типографики */)
    .dimensions {
        itemTextAfterPadding(2.0.dp)
        descriptionPadding(8.0.dp)
        separatorSpacing(40.0.dp)
        itemMinSpacing(20.0.dp)
    }
    .itemAlignment(WheelAlignment.Center)
    .style()
```

## Индикатор выбранного элемента

Компонент поддерживает отображение прямоугольного индикатора, выделяющего центральный (выбранный) элемент. Индикатор рисуется под всеми колёсами как единый прямоугольник, охватывающий всю группу.

Индикатор настраивается через `WheelStyle` и включается флагом `itemSelectorEnabled`:

```kotlin
WheelStyle.builder()
    .itemSelectorEnabled(true)
    .itemSelectorShape(RoundedCornerShape(8.dp))
    .colors {
        itemSelectorColor(Color(0x1A0066FF))
    }
    .dimensions {
        itemSelectorPaddingTop(2.dp)
        itemSelectorPaddingBottom(2.dp)
    }
    .style()
```

## WheelConstraints

Ограничение колёс по ширине.
Возможные значения:
- `Strict` Каждое колесо ограничено по ширине 1/3 доступного пространства в компоненте
- `Loose` У колёс нет ограничений по ширине

### WheelAlignment

Выравнивание составных частей компонента. 
Возможные значения:
- `Start` Все колёса имеют выравнивание по левому краю
- `End` Все колёса имеют выравнивание по правому краю
- `Center` Все колёса имеют выравнивание по центру
- `Mixed` Колеса до центрального имеют выравнивание по левому краю, центральное - по центру, колеса после центрального - по правому краю

### DataEdgePlacement

Способ размещения данных на колесе. 
Возможные значения:
- `WheelCenter` Данные начинаются и заканчиваются на середине колеса
- `WheelEdge` Данные начинаются и заканчиваются на краю колеса

### WheelSeparator

Тип разделителя. 
Возможные значения:
- `None` Разделитель отсутствует
- `Dots` Две точки в качестве разделителя
- `Divider` Divider в качестве разделителя

### WheelDataSet

Набор данных, необходимый для отображения колеса.

Свойства:
- `dataSet: List<WheelItemData>`
Основной набор данных. Содержит список элементов колеса типа WheelItemData.

- `description: String?` 
Опциональное, значение по умолчанию: null
Текстовое описание набора данных. Может быть пустым или отсутствовать.

- `initialIndex: Int`
Значение по умолчанию: 0
Начальный индекс, указывающий на позицию элемента, который должен быть виден первым при отображении колеса.

### WheelItemData

Класс, описывающий данные отдельного элемента колеса.

Свойства:
- `text: String`
Значение по умолчанию: ""
Основной текст элемента колеса. Отображается как ключевая информация.

- `textAfter: String`
Значение по умолчанию: ""
Дополнительный текст, который может отображаться после основного текста элемента. Используется для уточнений или вспомогательной информации.
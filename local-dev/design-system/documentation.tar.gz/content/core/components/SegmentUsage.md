---
title: Segment
---

Компонент Segment - контейнер для отображения  SegmentItem.
Контент Segment формируется с помощью функции segmentItem() из скоупа SegmentScope,

```kotlin
SegmentHorizontal(
    stretch = false,
    hasBackground = true,
) {
    repeat(3) { index ->
        segmentItem {
            SegmentItem(
                isSelected = index == 0,
                label = "Label",
                value = "Value",
                startIcon = painterResource(id = com.sdds.icons.R.drawable.ic_scribble_diagonal_24),
                counter = "55",
                enabled = true,
            )
        }
    }
}
```

<!-- @screenshot: com.sdds.compose.uikit.fixtures.samples.segment.Segment_Simple -->

## Стиль Segment

В большинстве случаев можно использовать готовые сгенерированные стили, а при необходимости создать собственный стиль через соответствующий builder. Подробнее о том, как работают `Style`, `StyleBuilder` и stateful-параметры стиля, см. в разделе [Стилизация компонентов](../theme/Styles.md).

### Параметры стиля

| Параметр | Тип | Возможные значения |
| --- | --- | --- |
| `size` | `SegmentSize` | `Xl`, `L`, `M`, `S`, `Xs` |
| `shape` | `SegmentShape` | `Default`, `Pilled` |
| `view` | `SegmentView` | `Primary`, `Secondary`, `Accent` |

Пример выбора готового стиля:
```kotlin
val style = SegmentStyles.style(
    size = SegmentSize.Xl,
    shape = SegmentShape.Default,
    view = SegmentView.Primary
)

// или через dot notation
val style = Segment.Xl.Primary.style()
```


### Создание стиля с помощью builder()

```kotlin
SegmentStyle.builder()
    .segmentItemStyle(/** Стиль компонента */)
    .colors {
        backgroundColor(
            /** Токен цвета */.asInteractive(),
        )
    }
    .shape(
        /** Токен формы(скругления) */.adjustBy(all = -2.0.dp),
    )
    .dimensions {
        paddingStart(2.0.dp)
        paddingEnd(2.0.dp)
        paddingTop(2.0.dp)
        paddingBottom(2.0.dp)
    }
    .style()
```

## Ориентация Segment

Для горизонтальной ориентации используйте SegmentHorizontal, для вертикальной - SegmentVertical

## Background Segment

Для включения/отключения background, нужно установить параметр hasBackground в true/false

```kotlin
SegmentHorizontal(
    ...
    hasBackground = false,
) {...}
```

## Segment с Divider

Чтобы добавить разделители между `SegmentItem`, используйте слот `divider { ... }` внутри `SegmentHorizontal/SegmentVertical`.
Обычно divider добавляется **между** элементами, поэтому удобно делать это в цикле и проверять индекс, но 
можно использовать и свою логику

```kotlin
SegmentHorizontal(
    stretch = false,
    hasBackground = true,
) {
    repeat(segmentCount) {
        segmentItem {
            SegmentItem(
                isSelected = true,
                label = "Label",
                value = "Value",
                startIcon = painterResource(id = com.sdds.icons.R.drawable.ic_scribble_diagonal_24),
                counter = "55",
                enabled = true,
            )
        }

        if (it < segmentCount - 1) divider { Divider() }
    }
}
```

<!-- @screenshot: com.sdds.compose.uikit.fixtures.samples.segment.Segment_Dividers -->

## Состояния и Motion API

В перегрузки `SegmentHorizontal` и `SegmentVertical` можно передать `motion: Motion<SegmentMotionStyle>`.
`rememberSegmentMotion()` использует `LocalSegmentMotionStyle`, если стиль переходов не указан явно.
`StatefulValue` задаёт значения для состояний, а `SegmentMotionStyle` — переходы фона, отступов, gap и отступов разделителей.
По умолчанию все переходы используют `noMotion()`: значения меняются без анимации.

```kotlin
var expanded by remember { mutableStateOf(false) }
val selectedState = setOf(InteractiveState.Selected)
val style = SegmentStyle.builder()
    .colors { backgroundColor(Color.LightGray.asStatefulBrush(selectedState to Color.Gray)) }
    .dimensions { gap(4.dp.asStatefulValue(selectedState to 16.dp)) }
    .style()
val motion = rememberSegmentMotion(
    style = SegmentMotionStyle.builder()
        .gap(transition { segment {} changesWith { finite(tween(200)) } })
        .backgroundColor(transition { segment {} changesWith { finite(tween(200)) } })
        .style(),
)
SegmentHorizontal(
    motion = motion,
    style = style,
    stretch = false,
    modifier = Modifier
        .selection(expanded, motion.context.semanticStateSource)
        .clickable(interactionSource = motion.context.interactionSource, indication = null) {
            expanded = !expanded
        },
) {
    segmentItem { SegmentItem(label = "Первый", isSelected = true) }
    segmentItem { SegmentItem(label = "Второй") }
}
```

Для передачи взаимодействий используйте `motion.context.interactionSource` также в `clickable`.
Семантические состояния задаются через `motion.context.semanticStateSource`.
Контейнер не объединяет автоматически состояния своих `SegmentItem`: у каждого элемента остаётся собственный контекст.
`hasBackground = false` отключает фон, сохраняя изменение размеров по состояниям.
Неопределённый gap отображается как нулевой; размеры с неопределёнными значениями переключаются без интерполяции.

### Переход со старых свойств

Существующие вызовы компонентов и builder-ов со статическими значениями сохраняются.
Для чтения текущих значений используйте stateful-свойства `shapes`, `colors.backgroundBrush`
и размерные свойства с суффиксом `Values`, например `dimensions.gapValues`.
Старые свойства помечены deprecated: размеры и форма возвращают default-значение,
а цветовое представление сохраняет однотонные состояния. Для градиентов старый Color API возвращает прозрачный цвет;
для отображения градиентов используйте `backgroundBrush`.
Форма переключается по состоянию без плавной анимации. Собственные реализации style/builder-интерфейсов
необходимо дополнить новыми контрактами.

---
title: RectSkeleton
---
Компонент для анимированного отображения загрузки областей на экране любой формы.
Для текста лучше использовать [TextSkeleton](TextSkeletonUsage.md)

Поддерживает два типа анимации: перемещающийся градиент и фон, плавно изменюящий альфу.

### Простой пример использования
```kotlin
RectSkeleton(
    modifier = Modifier
        .width(128.dp)
        .height(32.dp),
)
```

<!-- @screenshot: com.sdds.compose.uikit.fixtures.samples.rectskeleton.RectSkeleton_Simple -->

### Пример использования с кастомизацией параметров
```kotlin
RectSkeleton(
    modifier = Modifier.size(64.dp),
    shape = CircleShape, // кастомная форма
    duration = 1200, // кастомная длительность анимации
    brush = /** Токен градиента */
        .asStatefulValue(), // кастомный градиент
)
```

<!-- @screenshot: com.sdds.compose.uikit.fixtures.samples.rectskeleton.RectSkeleton_Custom -->

> Параметр `brush` влияет на тип анимации. Если в brush установлен градиент, то скелетон будет выглядеть как перемещающийся в пространстве градиент.
> Если в brush передан SolidColor(), будет анимация мерцания - изменение альфы исходного цвета.

## Стиль RectSkeleton

В большинстве случаев можно использовать готовые сгенерированные стили, а при необходимости создать собственный стиль через соответствующий builder. Подробнее о том, как работают `Style`, `StyleBuilder` и stateful-параметры стиля, см. в разделе [Стилизация компонентов](../theme/Styles.md).

### Параметры стиля

| Параметр | Тип | Возможные значения |
| --- | --- | --- |
| `view` | `RectSkeletonView` | `Default`, `Lighter` |

Пример выбора готового стиля:
```kotlin
val style = RectSkeletonStyles.style(
    view = RectSkeletonView.Default
)

// или через dot notation
val style = RectSkeleton.Default.style()
```


### Создание стиля с помощью builder()

```kotlin
RectSkeletonStyle.builder()
    .gradient(Color.Cyan)
    .shape(CircleShape)
    .duration(700)
    .style()
```
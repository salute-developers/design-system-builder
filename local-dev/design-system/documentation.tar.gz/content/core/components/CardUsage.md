---
title: Card
---

Визуальный контейнер, который объединяет различные элементы, такие как изображения, текст и кнопки, в единый блок.
Настройка размера осуществляется явным образом или в зависимости от содержимого.
Компонент Card является базовым контейнером. CardContent используется для вложенного контента внутри Card, имеет свою форму.

```kotlin
Card(
    modifier = Modifier
        .width(150.dp)
        .height(200.dp),
    focusSelectorSettings = LocalFocusSelectorSettings.current,
) {
    Column(
        modifier = Modifier
            .fillMaxSize(),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center,
    ) {
        Text(
            text = "Заголовок",
            color = placeholder({ Color.Gray }, replace = "/** Токен цвета */"),
        )
        CardContent(
            modifier = Modifier,
            focusSelectorSettings = FocusSelectorSettings.None,
        ) {
            Column(
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.Center,
                modifier = Modifier.fillMaxSize(),
            ) {
                Image(
                    contentScale = ContentScale.Crop,
                    painter = painterResource(id = R.drawable.ic_bulb_diode_fill_36),
                    colorFilter = ColorFilter.tint(Color.Black),
                    contentDescription = "Android",
                )
                Spacer(modifier = Modifier.height(8.dp))
                Text(
                    text = "Подзаголовок",
                    color = placeholder({ Color.Black }, replace = "/** Токен цвета */"),
                )
                Row(
                    modifier = Modifier.padding(top = 12.dp),
                    horizontalArrangement = Arrangement.spacedBy(12.dp),
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    Image(
                        contentScale = ContentScale.Crop,
                        painter = painterResource(id = R.drawable.ic_power_16),
                        colorFilter = ColorFilter.tint(Color.Black),
                        contentDescription = "Power",
                    )

                    Image(
                        contentScale = ContentScale.Crop,
                        painter = painterResource(id = R.drawable.ic_reset_outline_16),
                        colorFilter = ColorFilter.tint(Color.Black),
                        contentDescription = "Reset",
                    )

                    Image(
                        contentScale = ContentScale.Crop,
                        painter = painterResource(id = R.drawable.ic_settings_outline_16),
                        colorFilter = ColorFilter.tint(Color.Black),
                        contentDescription = "Settings",
                    )
                }
            }
        }
    }
}
```

<!-- @screenshot: com.sdds.compose.uikit.fixtures.samples.card.Card_Simple -->

Еще один вариант функции Card, в компановку которой добавлены слоты для Label и Extra, возможность указать  
ориентацию (вид компановки контента внутри карточки) и отступы внутри слота Content.

```kotlin
Card(
    modifier = Modifier
        .width(350.dp)
        .height(200.dp),
    focusSelectorSettings = LocalFocusSelectorSettings.current,
    extra = {
        Cell(
            modifier = Modifier
                .fillMaxWidth()
                .align(Alignment.TopCenter),
            title = AnnotatedString("Заголовок"),
            subtitle = AnnotatedString("Подзаголовок"),
            startContent = {
                Icon(
                    painter = painterResource(id = R.drawable.ic_camera_video_rec_outline_36),
                    contentDescription = "",
                )
            },
            disclosureText = AnnotatedString("Текст"),
            disclosureContentEnabled = true,
            disclosureIconRes = R.drawable.ic_chevron_right_24,
        )
    },
) {
    Box(modifier = Modifier.fillMaxSize()) {
        Image(
            modifier = Modifier.align(Alignment.Center),
            painter = painterResource(id = R.drawable.ic_video_clip_outline_36),
            colorFilter = placeholder(
                ColorFilter.tint(Color.Black),
                replace = "/** Токен цвета */",
            ),
            contentDescription = "",
        )
    }
}
```

<!-- @screenshot: com.sdds.compose.uikit.fixtures.samples.card.Card_Extra -->

Перегрузка Card с обязательным слотом title и опциональным subtitle позволяет описать заголовочную область без ручной сборки label.

```kotlin
Card(
    modifier = Modifier
        .width(220.dp)
        .height(260.dp),
    focusSelectorSettings = LocalFocusSelectorSettings.current,
    title = {
        Text("Заголовок")
    },
    subtitle = {
        Text("Подзаголовок")
    },
) {
    CardContent(
        modifier = Modifier.fillMaxSize(),
        focusSelectorSettings = FocusSelectorSettings.None,
    ) {
        Image(
            painter = painterResource(id = R.drawable.ic_bulb_diode_fill_36),
            contentDescription = "",
        )
    }
}
```

## Стиль Card

В большинстве случаев можно использовать готовые сгенерированные стили, а при необходимости создать собственный стиль через соответствующий builder. Подробнее о том, как работают `Style`, `StyleBuilder` и stateful-параметры стиля, см. в разделе [Стилизация компонентов](../theme/Styles.md).

### Параметры стиля `CardSolid`

| Параметр | Тип | Возможные значения |
| --- | --- | --- |
| `size` | `CardSolidSize` | `L`, `M`, `S` |

Пример выбора готового стиля:
```kotlin
val style = CardStyles.Solid.style(
    size = CardSolidSize.L
)

// или через dot notation
val style = CardSolid.L.style()
```


### Параметры стиля `CardClear`

| Параметр | Тип | Возможные значения |
| --- | --- | --- |
| `size` | `CardClearSize` | `L`, `M`, `S` |

Пример выбора готового стиля:
```kotlin
val style = CardStyles.Clear.style(
    size = CardClearSize.L
)

// или через dot notation
val style = CardClear.L.style()
```


## Создание стиля с помощью builder()

```kotlin
CardStyle.builder()
    .colors {
        backgroundColor(
            Color.Black.asInteractive(/** Токен цвета */),
        )
    }
    .shape(/** Токен формы (скругления) */)
    .contentShape(/** Токен формы (скругления) */)
    .dimensions {
        paddingTop(12.0.dp)
        paddingBottom(12.0.dp)
        paddingStart(12.0.dp)
        paddingEnd(12.0.dp)
    }
    .style()
```

### Примечание

При установке contentPaddings, отступы будут применятся на внутренний контент, при этом слот extra  
будет игнорировать эти паддинги.  При смене orintation, контент будет размещаться в Row (для горизонталоной  
ориентации) или в Column (для вертикальной ориентации).

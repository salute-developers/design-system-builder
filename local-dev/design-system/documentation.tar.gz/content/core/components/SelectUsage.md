---
title: Select
---

`Select` — Компонент с возможностью выбора одного или нескольких вариантов в выпадающем списке.
В качестве триггера ожидает `SelectButton` или `SelectTextField`. В качестве контента - список из `SelectItem`.

## Примеры использования

Select нужно использовать с `SelectTextField` либо с `SelectButton`. 
Они представляют собой обертки над `TextField` и `Button`, принимают их стиль и предоставляют часть их api, 
а также содержат дополнительный функционал, необходимый для `Select`.

### SelectTextField

Пример с `SelectTextField` и множественным выбором:

```kotlin
val selectList = listOf(
    "Иван Иванов",
    "Пётр Петров",
    "Сергей Сергеев",
)
val state = remember { SelectState(initialState = true) }
val checkedStateManager = rememberSelectMultipleDataStateManager(selectList, { true })

Select(
    state = state,
    trigger = {
        SelectTextField(
            modifier = Modifier.width(260.dp),
            value = "",
            placeholderText = "Сотрудник",
            iconOpened = com.sdds.icons.R.drawable.ic_chevron_up_24,
            iconClosed = com.sdds.icons.R.drawable.ic_chevron_down_24,
            chipsContent = if (checkedStateManager.selectedItems.isNotEmpty()) {
                { checkedStateManager.selectedItems.forEach { Chip(label = it) } }
            } else {
                null
            },
            startContent = {
                Icon(
                    painterResource(R.drawable.ic_search_24),
                    "",
                )
            },
        )
    },
    listContent = {
        items(selectList.size) {
            SelectItem(
                modifier = Modifier.fillMaxWidth(),
                checked = checkedStateManager.isSelected(selectList[it]),
                onClick = { checkedStateManager.onItemPressed(selectList[it]) },
            ) {
                Cell(
                    title = AnnotatedString(selectList[it]),
                    disclosureIconRes = null,
                )
            }
        }
    },
)
```

<!-- @screenshot: com.sdds.compose.uikit.fixtures.samples.select.Select_MultipleTextFieldLike -->

Пример с `SelectTextField` и единичным выбором:

```kotlin
val selectList = listOf(
    "Иван Иванов",
    "Пётр Петров",
    "Сергей Сергеев",
)
val state = remember { SelectState(initialState = true) }
val checkedStateManager = rememberSelectSingleDataStateManager(selectList, selectList[0])

Select(
    state = state,
    trigger = {
        SelectTextField(
            modifier = Modifier.width(260.dp),
            value = checkedStateManager.selectedItems.firstOrNull().orEmpty(),
            placeholderText = "Сотрудник",
            iconOpened = com.sdds.icons.R.drawable.ic_chevron_up_24,
            iconClosed = com.sdds.icons.R.drawable.ic_chevron_down_24,
            startContent = {
                Icon(
                    painterResource(R.drawable.ic_search_24),
                    "",
                )
            },
        )
    },
    listContent = {
        items(selectList.size) {
            SelectItem(
                modifier = Modifier.fillMaxWidth(),
                checked = checkedStateManager.isSelected(selectList[it]),
                onClick = { checkedStateManager.onItemPressed(selectList[it]) },
            ) {
                Cell(
                    title = AnnotatedString(selectList[it]),
                    disclosureIconRes = null,
                )
            }
        }
    },
)
```

<!-- @screenshot: com.sdds.compose.uikit.fixtures.samples.select.Select_SingleTextFieldLike -->

### SelectButton

Пример с `SelectButton` и единичным выбором:

```kotlin
val selectList = listOf(
    "Иван Иванов",
    "Пётр Петров",
    "Сергей Сергеев",
)
val state = remember { SelectState(initialState = true) }
val checkedStateManager = rememberSelectSingleDataStateManager(selectList, selectList[0])

Select(
    state = state,
    trigger = {
        SelectButton(
            modifier = Modifier.width(260.dp),
            label = checkedStateManager.selectedItems.firstOrNull() ?: "Value",
            iconOpened = resourceImageSource(com.sdds.icons.R.drawable.ic_chevron_up_24),
            iconClosed = resourceImageSource(com.sdds.icons.R.drawable.ic_chevron_down_24),
        )
    },
    listContent = {
        items(selectList.size) {
            SelectItem(
                modifier = Modifier.fillMaxWidth(),
                checked = checkedStateManager.isSelected(selectList[it]),
                onClick = { checkedStateManager.onItemPressed(selectList[it]) },
            ) {
                Cell(
                    title = AnnotatedString(selectList[it]),
                    disclosureIconRes = null,
                )
            }
        }
    },
)
```

<!-- @screenshot: com.sdds.compose.uikit.fixtures.samples.select.Select_SingleButtonLike -->

Пример с `SelectButton` и множественным выбором:

```kotlin
val selectList = listOf(
    "Иван Иванов",
    "Пётр Петров",
    "Сергей Сергеев",
)
val state = remember { SelectState(initialState = true) }
val checkedStateManager = rememberSelectMultipleDataStateManager(
    selectList,
    { true },
)

Select(
    state = state,
    trigger = {
        SelectButton(
            modifier = Modifier.width(260.dp),
            label = checkedStateManager.selectedItems
                .joinToString(", ")
                .ifEmpty { "Value" },
            iconOpened = resourceImageSource(com.sdds.icons.R.drawable.ic_chevron_up_24),
            iconClosed = resourceImageSource(com.sdds.icons.R.drawable.ic_chevron_down_24),
        )
    },
    listContent = {
        items(selectList.size) {
            SelectItem(
                modifier = Modifier.fillMaxWidth(),
                checked = checkedStateManager.isSelected(selectList[it]),
                onClick = { checkedStateManager.onItemPressed(selectList[it]) },
            ) {
                Cell(
                    title = AnnotatedString(selectList[it]),
                    disclosureIconRes = null,
                )
            }
        }
    },
)
```

<!-- @screenshot: com.sdds.compose.uikit.fixtures.samples.select.Select_MultipleButtonLike -->

### SelectItem

Элемент списка `Select`. Может быть выбранным и ожидает в качестве контента [Cell](CellUsage.md).

```kotlin
SelectItem(
    modifier = Modifier.fillMaxWidth(),
    checked = checkedStateManager.isSelected(SelectList[it]),
    onClick = {
        checkedStateManager.onItemPressed(SelectList[it])
    },
) {
    Cell(
        title = AnnotatedString(SelectList[it]),
        disclosureIconRes = null,
    )
}
```

## Работа с компонентом

### Stateful-стиль и Motion SelectItem

`checked` публикуется как `InteractiveState.Selected` в семантическом источнике строки.
Стиль может сочетать Selected с Pressed, Hovered и Focused. Строки независимы по умолчанию.
Новые перегрузки обеих форм `SelectItem` принимают `motion: Motion<SelectItemMotionStyle>`;
старые вызовы сохраняются и используют прежний `interactionSource` и `LocalSelectItemMotionStyle`.

```kotlin
var checked by remember { mutableStateOf(false) }
val selected = setOf(InteractiveState.Selected)
val itemMotion = rememberSelectItemMotion(
    style = SelectItemMotionStyle.builder()
        .backgroundColor(transition { segment {} changesWith { finite(tween(200)) } })
        .style(),
)
SelectItem(
    motion = itemMotion,
    checked = checked,
    onClick = { checked = !checked },
    modifier = Modifier.fillMaxWidth(),
    style = SelectItemStyle.builder()
        .colors { backgroundColor(Color.Transparent.asStatefulBrush(selected to Color.LightGray)) }
        .dimensions { height(48.dp.asStatefulValue(selected to 56.dp)) }
        .style(),
    titleContent = { Text("Встроенная Cell разделяет контекст строки") },
)
```

Встроенные Cell (форма с `titleContent`) и CheckBox разделяют контекст строки, сохраняя
собственные MotionStyle, checked/enabled и собственные состояния. Выбор изменяется одним
`onClick` строки. Для Cell внутри произвольного `content` контекст передаётся явно:

```kotlin
var checked by remember { mutableStateOf(false) }
val itemMotion = rememberSelectItemMotion()
SelectItem(
    motion = itemMotion,
    checked = checked,
    onClick = { checked = !checked },
    content = {
        Cell(
            motion = rememberCellMotion(motionContext = itemMotion.context),
            titleContent = { Text("Общий контекст передан явно") },
        )
    },
)
```

| Владелец | Новое значение | Старый getter |
| --- | --- | --- |
| SelectItemStyle | `shapes: StatefulValue<Shape>` | `shape` |
| SelectItemColors | `backgroundBrush`, `iconBrush`: `StatefulValue<Brush>` | `backgroundColor`, `iconColor` |
| SelectItemDimensions | `controlSizeValues`, `controlMarginValues`, `paddingStartValues`, `paddingEndValues`, `paddingTopValues`, `paddingBottomValues`, `heightValues`: `StatefulValue<Dp>` | те же имена без `Values` |

Builder-методы сохраняют прежние имена и принимают как статические значения, так и
`StatefulValue`. Цвета дополнительно принимают `Brush`. Старые getters помечены Deprecated:
форма и размеры возвращают default; цветовые getters возвращают
`Color.Transparent.asInteractive()`, как в Cell/Chip. Default, selected и комбинированные
состояния старых цветовых builder-вызовов сохраняются в новом Brush API, включая градиенты.

Произвольная `Shape` поддерживается; форма и все размеры переключаются без интерполяции через
`getValueAsState(motion.context)`, как размеры BaseTextField. Фон и indication
используют одну разрешённую форму. MotionStyle содержит два перехода Brush,
по умолчанию `noMotion()`. Неконечные Dp переключаются без анимации и без замены на ноль.
`height` сохраняет смысл минимальной высоты, а место контрольной иконки резервируется
даже при её отсутствии. `disableAlpha`, вложенные стили и ImageSource-контракт не меняются.

Обычные вызовы и сгенерированные стили совместимы. Собственные реализации интерфейсов
SelectItemStyle/Colors/Dimensions и их builder-ов нужно дополнить новыми членами.

### SelectState

Для работы с компонентом необходимо создать экземпляр `SelectState` и передать его в `Select`. 
Он служит для управления состоянием компонента открыт / закрыт. 
```kotlin
val state = remember { SelectState(initialState = true) }
Select(
    state = state
)
```
Список открывается и закрывается автоматически при активации / деактивации триггера. 
При необходимости состоянием можно управлять вручную:
```kotlin
state.open() // открыть список
state.close // закрыть список
state.toggle // переключить текущее состояние
```

### SelectDataStateManager

Для управления состоянием элементов `выбран` / `не выбран` лучше использовать ViewModel, но если она не используется, 
то существует интерфейс `SelectDataStateManager<T>` и две реализации для множественного и одиночного выбора.
Реализации доступны с помощью функций `rememberSelectMultipleDataStateManager()` и `rememberSelectSingleDataStateManager()`

### EmptyState

Чтобы показать пустое состояние, необходимо передать контент пустого состояния в `emptyContent` и установить `showEmptyState`. 
В скоупе dropdown существует преднастроенный компонент `EmptyState()`. 
Рекомендуется использовать его в качестве контента для `emptyState`.

### Footer / header
Чтобы показывать индикатор загрузки или произвольный контент в нижней части списка, необходимо передать контент в `footer`.

Чтобы показывать произвольный контент в верхней части списка, необходимо передать контент в `header`.

## Стиль Select

В большинстве случаев можно использовать готовые сгенерированные стили, а при необходимости создать собственный стиль через соответствующий builder. Подробнее о том, как работают `Style`, `StyleBuilder` и stateful-параметры стиля, см. в разделе [Стилизация компонентов](../theme/Styles.md).

### Параметры стиля `SelectSingleNormal`

| Параметр | Тип | Возможные значения |
| --- | --- | --- |
| `size` | `SelectSingleNormalSize` | `Xl`, `L`, `M`, `S`, `Xs` |

Пример выбора готового стиля:
```kotlin
val style = SelectStyles.SingleNormal.style(
    size = SelectSingleNormalSize.Xl
)

// или через dot notation
val style = SelectSingleNormal.Xl.style()
```


### Параметры стиля `SelectSingleTight`

| Параметр | Тип | Возможные значения |
| --- | --- | --- |
| `size` | `SelectSingleTightSize` | `Xl`, `L`, `M`, `S`, `Xs` |

Пример выбора готового стиля:
```kotlin
val style = SelectStyles.SingleTight.style(
    size = SelectSingleTightSize.Xl
)

// или через dot notation
val style = SelectSingleTight.Xl.style()
```


### Параметры стиля `SelectMultipleNormal`

| Параметр | Тип | Возможные значения |
| --- | --- | --- |
| `size` | `SelectMultipleNormalSize` | `Xl`, `L`, `M`, `S`, `Xs` |

Пример выбора готового стиля:
```kotlin
val style = SelectStyles.MultipleNormal.style(
    size = SelectMultipleNormalSize.Xl
)

// или через dot notation
val style = SelectMultipleNormal.Xl.style()
```


### Параметры стиля `SelectMultipleTight`

| Параметр | Тип | Возможные значения |
| --- | --- | --- |
| `size` | `SelectMultipleTightSize` | `Xl`, `L`, `M`, `S`, `Xs` |

Пример выбора готового стиля:
```kotlin
val style = SelectStyles.MultipleTight.style(
    size = SelectMultipleTightSize.Xl
)

// или через dot notation
val style = SelectMultipleTight.Xl.style()
```


### Создание стиля с помощью builder()

```kotlin
SelectStyle.builder()
    .textFieldStyle(
        placeholder(
            TextFieldStyle.builder().style(),
            "/** Стиль компонента */",
        ),
    )
    .buttonStyle(
        placeholder(
            ButtonStyle.basicButtonBuilder().style(),
            "/** Стиль компонента */",
        ),
    )
    .dropdownStyle(
        placeholder(
            DropdownMenuStyle.builder().style(),
            "/** Стиль компонента */",
        ),
    )
    .selectItemStyle(
        placeholder(
            SelectItemStyle.builder().style(),
            "/** Стиль компонента */",
        ),
    )
    .style()
```

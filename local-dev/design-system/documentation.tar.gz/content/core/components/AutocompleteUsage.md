---
title: Autocomplete
---

`Autocomplete` — Поле ввода с возможностью подстановки значения из предварительно заполненного выпадающего списка по мере ввода данных.
Состоит из текстового поля и раскрывающегося списка.

## Пример использования

```kotlin
var text by remember { mutableStateOf(TextFieldValue()) }
var showDropdown by remember { mutableStateOf(false) }
val filteredList = AutocompleteSuggestions.filterSuggestions(text.text)
val showEmptyState = filteredList.isEmpty()
Autocomplete(
    showDropdown = showDropdown,
    onDismissRequest = { showDropdown = false },
    field = {
        TextField(
            modifier = Modifier.width(240.dp),
            value = text,
            placeholderText = "Сотрудник",
            captionText = "Введите имя",
            onValueChange = {
                text = it
                showDropdown = true
            },
            focusSelectorSettings = FocusSelectorSettings.None,
        )
    },
    showEmptyState = showEmptyState,
    emptyState = {
        EmptyState(
            iconRes = com.sdds.icons.R.drawable.ic_plasma_36,
            description = "Empty State",
            buttonLabel = "Action",
        )
    },
    footer = { Loading() },
    listContent = {
        items(filteredList.size) { index ->
            ListItem(
                modifier = Modifier
                    .fillMaxWidth()
                    .clickable(
                        indication = null,
                        interactionSource = remember { MutableInteractionSource() },
                    ) {
                        text = TextFieldValue(
                            text = filteredList[index],
                            selection = TextRange(filteredList[index].length),
                        )
                        showDropdown = false
                    },
                text = filteredList[index],
            )
        }
    },
)
```

<!-- @screenshot: com.sdds.compose.uikit.fixtures.samples.autocomplete.Autocomplete_Simple -->

Чтобы показать раскрывающийся список необходимо установить `showDropdown = true` и передать данные для раскрывающегося списка в `listContent`.

Чтобы показать пустое состояние, необходимо передать контент пустого состояния в `emptyState` и установить `showEmptyState`.
В скоупе dropdown существует преднастроенный компонент `EmptyState()`. 
Рекомендуется использовать его в качестве контента для `emptyState`.

Чтобы показывать индикатор загрузки или произвольный контент в нижней части списка, необходимо передать контент в `footer`.

## StatefulValue и Motion

`AutocompleteStyle` содержит вложенные `textFieldStyle` и `dropdownStyle`. StatefulValue задаются внутри этих стилей:
например, фон TextField может зависеть от фокуса. Собственных цветов, размеров или формы у стиля Autocomplete нет.

Для передачи контекста меню используйте перегрузку с обязательным `dropdownMotion: Motion<DropdownMenuMotionStyle>`.
Существующие вызовы остаются совместимыми и создают Motion меню через `rememberDropdownMenuMotion()` с
`LocalDropdownMenuMotionStyle`. Motion поля передаётся непосредственно в TextField внутри слота `field`.
Поле, меню и строки используют независимые контексты по умолчанию; при необходимости источники можно связать явно.

```kotlin
var value by remember { mutableStateOf("") }
var showDropdown by remember { mutableStateOf(false) }
val suggestions = listOf("Москва", "Мурманск", "Самара").filter { it.contains(value, ignoreCase = true) }
val fieldMotion = rememberTextFieldMotion(
    style = TextFieldMotionStyle.builder().backgroundColor(
        transition { segment {} changesWith { finite(tween(200)) } },
    ).style(),
)
val dropdownMotion = rememberDropdownMenuMotion()
Autocomplete(
    dropdownMotion = dropdownMotion,
    style = AutocompleteStyle.builder().textFieldStyle(
        TextFieldStyle.builder().colors {
            backgroundColor(
                Color.LightGray.asStatefulBrush(setOf(InteractiveState.Focused) to Color.White),
            )
        }.style(),
    ).style(),
    showDropdown = showDropdown,
    onDismissRequest = { showDropdown = false },
    field = {
        TextField(
            value = value,
            onValueChange = {
                value = it
                showDropdown = true
            },
            modifier = Modifier.width(260.dp),
            placeholderText = "Город",
            focusSelectorSettings = FocusSelectorSettings.None,
            motion = fieldMotion,
        )
    },
    listContent = {
        items(suggestions.size) { index ->
            ListItem(
                text = suggestions[index],
                modifier = Modifier.clickable {
                    value = suggestions[index]
                    showDropdown = false
                },
            )
        }
    },
)
```

В примере stateful-фон поля меняется при фокусе через существующий `TextFieldMotionStyle`.
Фильтрацией подсказок, выбором и флагом `showDropdown` управляет вызывающий код.
`onDismissRequest` сообщает о запросе закрытия; обновление флага остаётся у потребителя.

В текущем API контекст меню уже используется для stateful-обводки (`strokeColor`). Доступные переходы свойств
определяются реализацией DropdownMenu; передача Motion сама по себе не добавляет анимации его фона, размеров или формы.
`noMotion` отключает настроенные переходы свойств и сохраняет существующие `fadeIn`/`fadeOut` меню и `TextFieldAnimation`.

## Стиль Autocomplete

В большинстве случаев можно использовать готовые сгенерированные стили, а при необходимости создать собственный стиль через соответствующий builder. Подробнее о том, как работают `Style`, `StyleBuilder` и stateful-параметры стиля, см. в разделе [Стилизация компонентов](../theme/Styles.md).

### Параметры стиля `AutocompleteTight`

| Параметр | Тип | Возможные значения |
| --- | --- | --- |
| `size` | `AutocompleteTightSize` | `Xl`, `L`, `M`, `S`, `Xs` |

Пример выбора готового стиля:
```kotlin
val style = AutocompleteStyles.Tight.style(
    size = AutocompleteTightSize.Xl
)

// или через dot notation
val style = AutocompleteTight.Xl.style()
```


### Параметры стиля `AutocompleteNormal`

| Параметр | Тип | Возможные значения |
| --- | --- | --- |
| `size` | `AutocompleteNormalSize` | `Xl`, `L`, `M`, `S`, `Xs` |

Пример выбора готового стиля:
```kotlin
val style = AutocompleteStyles.Normal.style(
    size = AutocompleteNormalSize.Xl
)

// или через dot notation
val style = AutocompleteNormal.Xl.style()
```


### Создание стиля с помощью builder()

```kotlin
AutocompleteStyle.builder()
    .textFieldStyle(/** Стиль компонента */)
    .dropdownStyle(/** Стиль компонента */)
    .style()
```

---
title: File
---
Компонент для отображения загруженных файлов.

В качестве `progress` ожидает [CircularProgressBar](CircularProgressBarUsage.md) для варианта с внутренним расположением прогресса 
и [ProgressBar](ProgressBarUsage.md) для варианта с нижним расположением прогресса (см. [FileProgressPlacement](#fileactionplacement)). Либо произвольный контент.

В качестве `action` ожидает [IconButton](BasicButtonUsage.md) либо произвольный контент.

В качестве `image` ожидает иконку / изображение / произвольный контент.

### Пример со встроенным круглым прогрессом
```kotlin
File(
    label = "image.png",
    description = "226 КБ",
    isLoading = true,
    image = {
        Icon(
            painterResource(com.sdds.icons.R.drawable.ic_file_check_fill_36),
            contentDescription = "",
        )
    },
    progress = {
        CircularProgressBar(
            progress = 0.4f,
            valueContent = {
                Icon(
                    modifier = Modifier.size(12.dp),
                    painter = painterResource(id = com.sdds.icons.R.drawable.ic_close_16),
                    contentDescription = "",
                )
            },
        )
    },
    action = {
        IconButton(
            iconRes = com.sdds.icons.R.drawable.ic_close_36,
            onClick = {},
        )
    },
)
```

<!-- @screenshot: com.sdds.compose.uikit.fixtures.samples.file.FileCircular_Simple -->

### Пример с внешним линейным прогрессом снизу
```kotlin
File(
    label = "image.png",
    description = "226 КБ",
    isLoading = true,
    image = {
        Icon(
            painterResource(com.sdds.icons.R.drawable.ic_file_check_fill_36),
            contentDescription = "",
        )
    },
    progress = {
        ProgressBar(progress = 0.4f)
    },
    action = {
        IconButton(
            iconRes = com.sdds.icons.R.drawable.ic_close_36,
            onClick = {},
        )
    },
)
```

<!-- @screenshot: com.sdds.compose.uikit.fixtures.samples.file.FileLinear_Simple -->

## Стиль File

В большинстве случаев можно использовать готовые сгенерированные стили, а при необходимости создать собственный стиль через соответствующий builder. Подробнее о том, как работают `Style`, `StyleBuilder` и stateful-параметры стиля, см. в разделе [Стилизация компонентов](../theme/Styles.md).

### Параметры стиля `FileCircularProgress`

| Параметр | Тип | Возможные значения |
| --- | --- | --- |
| `size` | `FileCircularProgressSize` | `Xs`, `S`, `M`, `L` |
| `view` | `FileCircularProgressView` | `Default`, `Negative` |

Пример выбора готового стиля:
```kotlin
val style = FileStyles.CircularProgress.style(
    size = FileCircularProgressSize.Xs,
    view = FileCircularProgressView.Default
)

// или через dot notation
val style = FileCircularProgress.Xs.Default.style()
```


### Параметры стиля `FileLinearProgress`

| Параметр | Тип | Возможные значения |
| --- | --- | --- |
| `size` | `FileLinearProgressSize` | `Xs`, `S`, `M`, `L` |
| `view` | `FileLinearProgressView` | `Default`, `Negative` |

Пример выбора готового стиля:
```kotlin
val style = FileStyles.LinearProgress.style(
    size = FileLinearProgressSize.Xs,
    view = FileLinearProgressView.Default
)

// или через dot notation
val style = FileLinearProgress.Xs.Default.style()
```


### Параметры стиля `AiInputFileCircularProgress`

| Параметр | Тип | Возможные значения |
| --- | --- | --- |
| `size` | `AiInputFileCircularProgressSize` | `Xs`, `S`, `M`, `L` |
| `view` | `AiInputFileCircularProgressView` | `Default`, `Negative` |

Пример выбора готового стиля:
```kotlin
val style = FileStyles.AiInputFileCircularProgress.style(
    size = AiInputFileCircularProgressSize.Xs,
    view = AiInputFileCircularProgressView.Default
)

// или через dot notation
val style = AiInputFileCircularProgress.Xs.Default.style()
```


### Создание стиля с помощью builder()

```kotlin
FileStyle.builder()
    .colors {
        iconColor(Color.Cyan)
        descriptionColor(Color.Gray)
        labelColor(Color.Black)
    }
    .dimensions {
        descriptionPadding(2.dp)
        startContentPadding(12.dp)
        endContentPadding(12.dp)
        bottomContentPadding(12.dp)
    }
    .labelStyle(/** Токен типографики */)
    .descriptionStyle(/** Токен типографики */)
    .actionButtonStyle(/** Стиль компонента */)
    .circularProgressBarStyle(
        /** Стиль компонента */,
    )
    .style()
```

## FileActionPlacement

Расположение `action` и встроенного `progress`. Возможные значения: Start, End.

## FileProgressPlacement

Расположение `progress`. Возможные значения: Inner (прогресс встроен слева или справа от `label` и `description`), Outer (прогресс расположен снизу).
---
title: ToolBar
---

Вспомогательная панель с набором инструментов для работы на основном экране. Позволяет размещать  
набор элементов (секций) горизонтально или вертикально с разделителями [Divider](./DividerUsage.md).
Отображение разделителей для секций настраивается с помощью параметра hasDivider.

### Простой пример использования ToolBar

```kotlin
ToolBar(
    hasDivider = true,
    orientation = ToolBarOrientation.Horizontal,
) {
    section {
        IconButton(R.drawable.ic_plasma_24) { }
    }
    section {
        IconButton(R.drawable.ic_salute_outline_24) { }
    }
    section {
        Button("Label", {})
    }
}
```

<!-- @screenshot: com.sdds.compose.uikit.fixtures.samples.toolbar.ToolBar_Simple -->

Контент ToolBar задается через ToolBarScope. Scope предоставляет функцию для добавления 
`fun section(content: @Composable () -> Unit)`. Каждый вызов `section {some composable content}`  
добавляет одну секцию в ToolBar, если количество секций больше 1, автоматически добавляются разделители (Divider).  
Порядок отображения секций полностью соответствует порядку вызовов `section {some composable content}`.  
Если требуется оставить пустое место, нужно задать необходимое количество пустых секций `section {}`. При  
этом пустая секция занимает свое место в ToolBar, участвует в расстановке Divider. Расположение секций задается  
параметром orientation, ожидает значение ToolBarOrientation. Horizontal - секции располагаются в Row,  
Vertical - секции располагаются в Column.

## Стиль ToolBar

В большинстве случаев можно использовать готовые сгенерированные стили, а при необходимости создать собственный стиль через соответствующий builder. Подробнее о том, как работают `Style`, `StyleBuilder` и stateful-параметры стиля, см. в разделе [Стилизация компонентов](../theme/Styles.md).

### Параметры стиля `ToolBarHorizontal`

| Параметр | Тип | Возможные значения |
| --- | --- | --- |
| `size` | `ToolBarHorizontalSize` | `L`, `M`, `S`, `Xs` |
| `hasShadow` | `Boolean` | `true`, `false` |

Пример выбора готового стиля:
```kotlin
val style = ToolBarStyles.Horizontal.style(
    size = ToolBarHorizontalSize.L,
    hasShadow = false
)

// или через dot notation
val style = ToolBarHorizontal.L.style()
```


### Параметры стиля `ToolBarVertical`

| Параметр | Тип | Возможные значения |
| --- | --- | --- |
| `size` | `ToolBarVerticalSize` | `L`, `M`, `S`, `Xs` |
| `hasShadow` | `Boolean` | `true`, `false` |

Пример выбора готового стиля:
```kotlin
val style = ToolBarStyles.Vertical.style(
    size = ToolBarVerticalSize.L,
    hasShadow = false
)

// или через dot notation
val style = ToolBarVertical.L.style()
```


### Создание стиля с помощью builder()

```kotlin
ToolBarStyle.builder()
    .shadow(/** Токен тени */)
    .shape(/** Токен формы(скругления) */)
    .dividerStyle(/** Стиль разделителя */)
    .orientation(ToolBarOrientation.Horizontal)
    .dimensions {
        dividerMargin(4.dp)
        sectionPadding(4.dp)
        paddingStart(8.dp)
        paddingEnd(8.dp)
        paddingTop(8.dp)
        paddingBottom(8.dp)
    }
    .colors {
        backgroundColor(SolidColor(Color.White))
    }
    .style()
```

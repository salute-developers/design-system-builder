---
title: Chip
---

Компонент Chip может содержать текст, который указывается через label.
label можно использовать вместе с startContent и endContent, с их помощью можно размещать иконку слева или справа от текста.

```kotlin
Chip(
    label = "label",
    isSelected = true,
    startContent = {
        Icon(
            painter = painterResource(id = com.sdds.icons.R.drawable.ic_accessibility_24),
            contentDescription = "",
        )
    },
    endContent = {
        Icon(
            painter = painterResource(id = com.sdds.icons.R.drawable.ic_close_24),
            contentDescription = "",
        )
    },
)
```

<!-- @screenshot: com.sdds.compose.uikit.fixtures.samples.chip.Chip_Simple -->

## Стиль Chip

В большинстве случаев можно использовать готовые сгенерированные стили, а при необходимости создать собственный стиль через соответствующий builder. Подробнее о том, как работают `Style`, `StyleBuilder` и stateful-параметры стиля, см. в разделе [Стилизация компонентов](../theme/Styles.md).

### Параметры стиля

| Параметр | Тип | Возможные значения |
| --- | --- | --- |
| `size` | `ChipDefaultSize` | `L`, `M`, `S`, `Xs` |
| `shape` | `ChipDefaultShape` | `Default`, `Pilled` |
| `view` | `ChipDefaultView` | `Default`, `Accent`, `Negative`, `Positive`, `Secondary`, `Warning` |

Пример выбора готового стиля:
```kotlin
val style = ChipStyles.Default.style(
    size = ChipDefaultSize.L,
    shape = ChipDefaultShape.Default,
    view = ChipDefaultView.Default
)

// или через dot notation
val style = Chip.L.Default.style()
```


### Параметры стиля `EmbeddedChip`

| Параметр | Тип | Возможные значения |
| --- | --- | --- |
| `size` | `EmbeddedChipSize` | `Xl`, `L`, `M`, `S`, `Xs` |
| `view` | `EmbeddedChipView` | `Default`, `Accent`, `Negative`, `Positive`, `Secondary`, `Warning` |

Пример выбора готового стиля:
```kotlin
val style = ChipStyles.EmbeddedChip.style(
    size = EmbeddedChipSize.Xl,
    view = EmbeddedChipView.Default
)

// или через dot notation
val style = EmbeddedChip.Xl.Default.style()
```


### Создание стиля с помощью builder()

```kotlin
ChipStyle.builder()
    .colors {
        backgroundColor(
            /** Токен цвета */.asInteractive(
                setOf(InteractiveState.Pressed)
                    to /** Цвет в состоянии pressed */,
                setOf(InteractiveState.Hovered)
                    to /** Цвет в состоянии hovered */,
            ),
        )
            .contentStartColor(/** Токен цвета */)
            .contentEndColor(/** Токен цвета */)
            .labelColor(/** Токен цвета */)
    }
    .shape(/** Токен формы (скругления) */)
    .labelStyle(/** Токен стиля текста */)
    .dimensions {
        height(48.0.dp)
        paddingStart(16.0.dp)
        paddingEnd(16.0.dp)
        contentStartPadding(8.0.dp)
        contentEndPadding(8.0.dp)
        contentStartSize(24.0.dp)
        contentEndSize(24.0.dp)
    }
    .style()
```

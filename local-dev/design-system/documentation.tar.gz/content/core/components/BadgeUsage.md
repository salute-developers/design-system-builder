---
title: Badge
---

```kotlin
Badge(
    label = "Label",
    startContent = {
        Icon(
            painter = painterResource(id = R.drawable.ic_plasma_16),
            contentDescription = "",
        )
    },
)
```

<!-- @screenshot: com.sdds.compose.uikit.fixtures.samples.badge.Badge_Simple -->

## Стиль Badge

В большинстве случаев можно использовать готовые сгенерированные стили, а при необходимости создать собственный стиль через соответствующий builder. Подробнее о том, как работают `Style`, `StyleBuilder` и stateful-параметры стиля, см. в разделе [Стилизация компонентов](../theme/Styles.md).

### Параметры стиля `BadgeClear`

| Параметр | Тип | Возможные значения |
| --- | --- | --- |
| `size` | `BadgeClearSize` | `L`, `M`, `S`, `Xs` |
| `shape` | `BadgeClearShape` | `Default`, `Pilled` |
| `view` | `BadgeClearView` | `Default`, `Accent`, `Negative`, `Positive`, `Warning`, `Dark`, `Light` |

Пример выбора готового стиля:
```kotlin
val style = BadgeStyles.Clear.style(
    size = BadgeClearSize.L,
    shape = BadgeClearShape.Default,
    view = BadgeClearView.Default
)

// или через dot notation
val style = BadgeClear.L.Default.style()
```


### Параметры стиля `BadgeSolid`

| Параметр | Тип | Возможные значения |
| --- | --- | --- |
| `size` | `BadgeSolidSize` | `L`, `M`, `S`, `Xs` |
| `shape` | `BadgeSolidShape` | `Default`, `Pilled` |
| `view` | `BadgeSolidView` | `Default`, `Accent`, `Negative`, `Positive`, `Warning`, `Dark`, `Light` |

Пример выбора готового стиля:
```kotlin
val style = BadgeStyles.Solid.style(
    size = BadgeSolidSize.L,
    shape = BadgeSolidShape.Default,
    view = BadgeSolidView.Default
)

// или через dot notation
val style = BadgeSolid.L.Default.style()
```


### Параметры стиля `BadgeTransparent`

| Параметр | Тип | Возможные значения |
| --- | --- | --- |
| `size` | `BadgeTransparentSize` | `L`, `M`, `S`, `Xs` |
| `shape` | `BadgeTransparentShape` | `Default`, `Pilled` |
| `view` | `BadgeTransparentView` | `Default`, `Accent`, `Negative`, `Positive`, `Warning`, `Dark`, `Light` |

Пример выбора готового стиля:
```kotlin
val style = BadgeStyles.Transparent.style(
    size = BadgeTransparentSize.L,
    shape = BadgeTransparentShape.Default,
    view = BadgeTransparentView.Default
)

// или через dot notation
val style = BadgeTransparent.L.Default.style()
```


### Создание стиля с помощью builder()

```kotlin
BadgeStyle.badgeBuilder()
    .shape(CircleShape)
    .colors {
        backgroundColor(
            /** Токен цвета */.asInteractive(),
        )
        labelColor(
            /** Токен цвета */.asInteractive(),
        )
        startContentColor(
            /** Токен цевета */.asInteractive(),
        )
        endContentColor(
            /** Токен цвета */.asInteractive(),
        )
    }
    .labelStyle(/** Токен типографики */)
    .dimensions {
        height(28.0.dp)
        startContentSize(16.0.dp)
        endContentSize(16.0.dp)
        startContentMargin(4.0.dp)
        endContentMargin(4.0.dp)
        startPadding(11.0.dp)
        endPadding(11.0.dp)
    }
    .style()
```

## Иконка Badge

В левой или/и правой части badge можно отобразить иконку. Если нужен Badge с иконкой без текста, можно использовать либо startContent либо endContent, но лучше использовать компонент IconBadge.

```kotlin
Badge(
    label = "",
    startContent = {
        Icon(
            painter = painterResource(id = R.drawable.ic_plasma_16),
            contentDescription = "",
        )
    },
)
```

<!-- @screenshot: com.sdds.compose.uikit.fixtures.samples.badge.Badge_WithoutLabel -->

## IconBadge

То же, что и Badge, но предназначен для отображения только иконки, поэтому не имеет параметра "label".

```kotlin
IconBadge(
    content = {
        Icon(
            painter = painterResource(id = R.drawable.ic_plasma_16),
            contentDescription = "",
        )
    },
)
```

<!-- @screenshot: com.sdds.compose.uikit.fixtures.samples.badge.IconBadge_Simple -->

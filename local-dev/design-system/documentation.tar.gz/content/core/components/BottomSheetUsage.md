---
title: BottomSheet
---

Модальное, диалоговое окно в формате bottom sheet. Используется для отображения дополнительного контента
поверх основного интерфейса, не переключая экран. Обычно применяется для показа выбора, подтверждений и
других взаимодействий с пользователем. Компонент перекрывает весь экран полупрозрачным фоном и блокирует
взаимодействие с остальной частью UI до закрытия. Условно поделен на 3 части - header, body, footer.
Каждая часть может содержать любые composable элементы.

```kotlin
val sheetState = rememberModalBottomSheetState(
    initialValue = BottomSheetValue.Hidden,
)
val scope = rememberCoroutineScope()
Button(
    label = "показать BottomSheet",
    onClick = {
        scope.launch {
            sheetState.show()
        }
    },
)
ModalBottomSheet(
    sheetState = sheetState,
    handlePlacement = BottomSheetHandlePlacement.Inner,
    fitContent = false,
    header = {
        Column {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween,
            ) {
                Text(
                    color = /** Токен цвета */,
                    text = "Заголовок",
                )
                IconButton(
                    iconRes = R.drawable.ic_close_24,
                ) {
                    scope.launch { sheetState.hide() }
                }
            }
            Spacer(modifier = Modifier.padding(6.dp))
            Divider()
            Spacer(modifier = Modifier.padding(6.dp))
        }
    },
    body = {
        var value by remember { mutableStateOf(TextFieldValue("")) }
        TextField(
            modifier = Modifier.fillMaxWidth(),
            value = value,
            labelText = "Лейбл",
            placeholderText = "Введите текст",
            onValueChange = { value = it },
            focusSelectorSettings = FocusSelectorSettings.None,
        )
    },
    footer = {
        Button(
            modifier = Modifier.fillMaxWidth(),
            label = "Сохранить",
            spacing = ButtonSpacing.Packed,
            onClick = {},
        )
    },
)
```

<!-- @screenshot: com.sdds.compose.uikit.fixtures.samples.bottomsheet.ModalBottomSheet_Simple -->

## Стиль ModalBottomSheet

В большинстве случаев можно использовать готовые сгенерированные стили, а при необходимости создать собственный стиль через соответствующий builder. Подробнее о том, как работают `Style`, `StyleBuilder` и stateful-параметры стиля, см. в разделе [Стилизация компонентов](../theme/Styles.md).

Пример выбора готового стиля:
```kotlin
val style = BottomSheetStyles.style()

// или через dot notation
val style = ModalBottomSheet.Default.style()
```


### Создание стиля с помощью builder()

```kotlin
ModalBottomSheetStyle.builder()
    .shape(/** Токен формы (скругления) */)
    .handleShape(CircleShape)
    .dimensions {
        paddingStart(16.0.dp)
        paddingEnd(16.0.dp)
        paddingTop(16.0.dp)
        paddingBottom(16.0.dp)
        handleHeight(4.0.dp)
        handleWidth(48.0.dp)
        handleOffset(6.0.dp)
    }
    .colors {
        backgroundColor(
            /** Токен цвета */.asInteractive(),
        )
        handleColor(
            /** Токен цвета */.asInteractive(),
        )
    }
    .handlePlacement(BottomSheetHandlePlacement.Auto)
    .style()
```

## ModalBottomSheet HandlePlacement (Ручка)

Размещения handle относительно границы ModalBottomSheet можно задать с помощью парметра handlePlacement, ожидаемое значение - enum BottomSheetHandlePlacement.
В режиме Auto (по дефолту) изначально handle находится снаружи, но по мере выдвижения ModalBottomSheet - смещается во внутрь.

```kotlin
val sheetState = rememberModalBottomSheetState(
    initialValue = BottomSheetValue.Hidden,
)
ModalBottomSheet(
    sheetState = sheetState,
    handlePlacement = BottomSheetHandlePlacement.Inner,
    fitContent = false,
    body = { Text("Text") },
)
```

## Ограничение высоты ModalBottomSheet по контенту

С помощью параметра fitContent возможно ограничить высоту bottomSheet в развернутом виде, но только в том случае, если высота контента меньше высоты экрана.

```kotlin
val sheetState = rememberModalBottomSheetState(
    initialValue = BottomSheetValue.Hidden,
)
ModalBottomSheet(
    sheetState = sheetState,
    fitContent = true,
    body = { Text("Заголовок") },
)
```

## Обработка Window Insets

Для корректной работы с системными отступами (status bar, navigation bar, IME) рекомендуется
явно управлять модификаторами insets снаружи и внутри `ModalBottomSheet`.

Общий принцип:

- `statusBarsPadding()` добавляется к самому `ModalBottomSheet` через параметр `modifier`,
  чтобы компонент открывался до границы status bar и корректно учитывал верхний системный отступ.
- `navigationBarsPadding()` применяется внутри контента (например, к `Column`), чтобы
  содержимое не перекрывалось navigation bar, при этом сам `ModalBottomSheet` продолжал
  рисоваться под системной панелью.
- `imePadding()` также применяется внутри контента, чтобы элементы (например, `TextField`)
  корректно поднимались при появлении клавиатуры.


Таким образом:
- внешний модификатор отвечает за корректное позиционирование всего bottom sheet
  относительно status bar;
- внутренние модификаторы управляют безопасными отступами контента относительно
  navigation bar и клавиатуры.

:::warning
⚠️ Расположение модификаторов (снаружи или внутри `ModalBottomSheet`) является рекомендацией. 
В зависимости от архитектуры экрана и требований к дизайну разработчик может самостоятельно
определить, на каком уровне обрабатывать системные insets.
::: 

```kotlin
val sheetState = rememberModalBottomSheetState(
    initialValue = BottomSheetValue.Hidden,
)
val scrollState = rememberScrollState()
ModalBottomSheet(
    // Обрабатываем отступы statusBar снаружи, чтобы ModalBottomSheet открывался до границ statusBar
    modifier = Modifier.statusBarsPadding(),
    sheetState = sheetState,
    onDismiss = { /* Колбэк закрытия ModalBottomSheet */ },
    fitContent = true,
) {
    Column(
        modifier = Modifier
            // Отступы navigationBar обрабатываем внутри, чтобы ModalBottomSheet рисовался под navigationBar
            .navigationBarsPadding()
            // Аналогично поступаем с отступами IME
            .imePadding()
            .verticalScroll(scrollState),
    ) {
        Text("Заголовок ModalBottomSheet")

        TextField(
            modifier = Modifier
                .heightIn(min = 50.dp, max = 100.dp)
                .fillMaxWidth(),
            value = "",
            placeholderText = "Введите значение",
            onValueChange = {},
            focusSelectorSettings = FocusSelectorSettings.None,
        )
    }
}
```

<!-- @screenshot: com.sdds.compose.uikit.fixtures.samples.bottomsheet.ModalBottomSheet_Insets -->


## HalfExpandedSettings

Настройки поведения ModalBottomSheet для состояния HalfExpanded.
- `HalfExpanded.Skip` - отключает BottomSheetValue.HalfExpanded, в этом случае BottomSheet имеет два  
возможных состояния: BottomSheetValue.Hidden - полностью скрыт, BottomSheetValue.Expanded - полностью открыт.

```kotlin
val sheetState = rememberModalBottomSheetState(
    initialValue = BottomSheetValue.Hidden,
    halfExpandedSettings = HalfExpandedSettings.Skip,
)
val scope = rememberCoroutineScope()
Button(
    label = "показать BottomSheet",
    onClick = {
        scope.launch {
            sheetState.show()
        }
    },
)
ModalBottomSheet(
    sheetState = sheetState,
    handlePlacement = BottomSheetHandlePlacement.Auto,
    fitContent = false,
    header = { Text("Header") },
    footer = { Text("Footer") },
) {
    Text("Text")
}
```

- `HalfExpanded.Fraction(val expandFraction: Float)` - определяет позицию HalfExpanded как долю
expandFraction (процентное соотношение) от высоты экрана, на которое будет открыт BottomSheet в состоянии  
HalfExpanded. Значение ограничивается диапазоном 0f..1f.  

```kotlin
val sheetState = rememberModalBottomSheetState(
    initialValue = BottomSheetValue.Hidden,
    halfExpandedSettings = HalfExpandedSettings.Fraction(0.3f),
)
val scope = rememberCoroutineScope()
Button(
    label = "показать BottomSheet",
    onClick = {
        scope.launch {
            sheetState.show()
        }
    },
)
ModalBottomSheet(
    sheetState = sheetState,
    handlePlacement = BottomSheetHandlePlacement.Auto,
    fitContent = false,
    header = { Text("Header") },
    footer = { Text("Footer") },
) {
    Text("Text")
}
```

- `HalfExpanded.Height(val height: Dp)` - определяет позицию HalfExpanded через фиксированную высоту
height (видимую часть BottomSheet). Значение преобразуется в пиксели с использованием текущего Density и  
ограничивается доступной высотой экрана.

```kotlin
val sheetState = rememberModalBottomSheetState(
    initialValue = BottomSheetValue.Hidden,
    halfExpandedSettings = HalfExpandedSettings.Height(500.dp),
)
val scope = rememberCoroutineScope()
Button(
    label = "показать BottomSheet",
    onClick = {
        scope.launch {
            sheetState.show()
        }
    },
)
ModalBottomSheet(
    sheetState = sheetState,
    handlePlacement = BottomSheetHandlePlacement.Auto,
    fitContent = false,
    header = { Text("Header") },
    footer = { Text("Footer") },
) {
    Text("Text")
}
```

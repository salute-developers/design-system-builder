---
title: Indicator
---

Компонент Indicator как правило используется в составе других, более сложных компонентов (обычно для отображения статуса),
например в Avatar, TextField и др.

```kotlin
Indicator()
```

<!-- @screenshot: com.sdds.compose.uikit.fixtures.samples.indicator.Indicator_Simple -->

## Стиль Indicator

В большинстве случаев можно использовать готовые сгенерированные стили, а при необходимости создать собственный стиль через соответствующий builder. Подробнее о том, как работают `Style`, `StyleBuilder` и stateful-параметры стиля, см. в разделе [Стилизация компонентов](../theme/Styles.md).

### Параметры стиля `AvatarIndicator`

| Параметр | Тип | Возможные значения |
| --- | --- | --- |
| `size` | `AvatarIndicatorSize` | `L`, `M`, `S` |

Пример выбора готового стиля:
```kotlin
val style = IndicatorStyles.AvatarIndicator.style(
    size = AvatarIndicatorSize.L
)

// или через dot notation
val style = AvatarIndicator.L.style()
```


### Параметры стиля

| Параметр | Тип | Возможные значения |
| --- | --- | --- |
| `size` | `IndicatorDefaultSize` | `L`, `M`, `S` |
| `view` | `IndicatorDefaultView` | `Default`, `Accent`, `Inactive`, `Positive`, `Warning`, `Negative`, `Dark`, `Black`, `White` |

Пример выбора готового стиля:
```kotlin
val style = IndicatorStyles.Default.style(
    size = IndicatorDefaultSize.L,
    view = IndicatorDefaultView.Default
)

// или через dot notation
val style = Indicator.L.Default.style()
```


### Создание стиля с помощью builder()

```kotlin
IndicatorStyle.builder(this)
    .color {
        backgroundColor(
            /** Токен цвета */.asInteractive(),
        )
    }
    .dimensions {
        height(12.0.dp)
        width(12.0.dp)
    }
    .style()
```

## Indicator как extension к Modifier

Отличительной особоенностью такого использования является то, что появляется возможность отрисовки Indicator
как внутри границ декорируемого компонента, так и снаружи. Для того чтоб отобразить Indicator снаружи composable
нужно установить параметры horizontalMode и/или verticalMode как IndicatorMode.Outer

```kotlin
Avatar(
    modifier = Modifier
        .indicator(
            alignment = Alignment.TopEnd,
            horizontalPadding = 2.dp,
            verticalPadding = 2.dp,
            horizontalMode = IndicatorMode.Inner,
            verticalMode = IndicatorMode.Inner,
        ),
    status = AvatarStatus.None,
    actionEnabled = false,
    placeholder = AvatarPlaceholder.Name("Michael Scott"),
)
```

<!-- @screenshot: com.sdds.compose.uikit.fixtures.samples.indicator.AvatarIndicator_Simple -->

---
title: Toast
---

Временное, неблокируемое уведомление, которое появляется на короткое время, чтобы предоставить пользователю обратную связь.

Для корректной работы компонента необходимо обернуть контент в OverlayHost либо вручную провайдить менеджер уведомлений в [LocalOverlayManager](#overlaymanager).

```kotlin
Toast(
    text = "Текст уведомления",
    contentStart = {
        Icon(
            painter = painterResource(com.sdds.icons.R.drawable.ic_shazam_16),
            contentDescription = null,
        )
    },
    contentEnd = {
        Icon(
            painter = painterResource(com.sdds.icons.R.drawable.ic_close_16),
            contentDescription = null,
        )
    },
)

val overlayManager = LocalOverlayManager.current
LaunchedEffect(Unit) {
    repeat(5) {
        overlayManager.showToast(
            position = OverlayPosition.BottomCenter,
        ) {
            composableCodeSnippet {
                Toast(
                    text = "Текст уведомления",
                    contentStart = {
                        Icon(
                            painter = painterResource(com.sdds.icons.R.drawable.ic_shazam_16),
                            contentDescription = null,
                        )
                    },
                    contentEnd = {
                        Icon(
                            painter = painterResource(com.sdds.icons.R.drawable.ic_close_16),
                            contentDescription = null,
                        )
                    },
                )
            }
        }
    }
}
```

<!-- @screenshot: com.sdds.compose.uikit.fixtures.samples.toast.Toast_Simple -->

## Многострочный текст в Toast
```kotlin
val overlayManager = LocalOverlayManager.current

LaunchedEffect(Unit) {
    repeat(5) {
        overlayManager.showToast(
            position = OverlayPosition.BottomCenter,
        ) {
            Toast(
                contentStart = {
                    Icon(
                        painter = painterResource(com.sdds.icons.R.drawable.ic_shazam_16),
                        contentDescription = null,
                    )
                },
            ) {
                Text("First line\nSecond Line")
            }
        }
    }
}
```

<!-- @screenshot: com.sdds.compose.uikit.fixtures.samples.toast.Toast_TextMultiline -->

## Стиль Toast

В большинстве случаев можно использовать готовые сгенерированные стили, а при необходимости создать собственный стиль через соответствующий builder. Подробнее о том, как работают `Style`, `StyleBuilder` и stateful-параметры стиля, см. в разделе [Стилизация компонентов](../theme/Styles.md).

### Параметры стиля

| Параметр | Тип | Возможные значения |
| --- | --- | --- |
| `shape` | `ToastShape` | `Rounded`, `Pilled` |
| `view` | `ToastView` | `Default`, `Positive`, `Negative` |

Пример выбора готового стиля:
```kotlin
val style = ToastStyles.style(
    shape = ToastShape.Rounded,
    view = ToastView.Default
)

// или через dot notation
val style = Toast.Rounded.Default.style()
```


### Создание стиля с помощью builder()

```kotlin
ToastStyle.builder()
    .shape(/** Токен формы(скругления) */)
    .textStyle(/** Токен типографики */)
    .dimensions {
        contentStartSize(16.0.dp)
        contentStartPadding(4.0.dp)
        contentEndSize(16.0.dp)
        contentEndPadding(4.0.dp)
        paddingStart(8.dp)
        paddingEnd(8.dp)
        paddingTop(8.dp)
        paddingBottom(8.dp)
    }
    .colors {
        backgroundColor(SolidColor(Color.Black))
        textColor(Color.LightGray)
        contentStartColor(Color.LightGray)
        contentEndColor(Color.LightGray)
    }
    .style()
```

## OverlayManager

Менеджер уведомлений.

Можно использовать OverlayHost, который провайдит преднастроенный менеджер OverlayManager в контент.
Также менеджер можно создать с помощью функции overlayManager() и вручную провайдить созданный экземпляр в LocalOverlayManager.

```kotlin
OverlayHost {
    ...
    val overlayManager = LocalOverlayManager.current
    overlayManager.showToast(
        position = OverlayPosition.BottomEnd,
    ) {...}
}
```

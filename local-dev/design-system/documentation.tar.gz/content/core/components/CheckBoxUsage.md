---
title: CheckBox
---

Компонент Checkbox может содержать лейбл и описание.

```kotlin
CheckBox(
    state = ToggleableState.On,
    enabled = true,
    label = "Label",
    description = "Description",
    onClick = {},
)
```

<!-- @screenshot: com.sdds.compose.uikit.fixtures.samples.checkbox.CheckBox_Simple -->

## Состояния CheckBox

Значение `CheckBox` задаётся через `CheckBoxValue` — тип с четырьмя равноправными значениями: `Off`, `On`, `Indeterminate` и `Error`. Перегрузки `CheckBox(value: CheckBoxValue, ...)` — основной способ задать состояние, включая `Error`.

Для обратной совместимости остаются перегрузки на `checked: Boolean` и на `androidx.compose.ui.state.ToggleableState` — но `ToggleableState` не содержит `Error` (это закрытый enum AndroidX), поэтому состояние `Error` доступно только через перегрузки с `CheckBoxValue`.

### Error

`Error` сигнализирует, что значение чекбокса невалидно (например, по результату валидации формы). Это состояние можно задать только программно — сам компонент никогда не переводит себя в `Error` в результате клика по нему; переход в `Error` и обратно должен управляться вызывающим кодом.

```kotlin
CheckBox(
    value = CheckBoxValue.Error,
    enabled = true,
    label = "Label",
    description = "Description",
)
```

## Стиль CheckBox

В большинстве случаев можно использовать готовые сгенерированные стили, а при необходимости создать собственный стиль через соответствующий builder. Подробнее о том, как работают `Style`, `StyleBuilder` и stateful-параметры стиля, см. в разделе [Стилизация компонентов](../theme/Styles.md).

### Параметры стиля

| Параметр | Тип | Возможные значения |
| --- | --- | --- |
| `size` | `CheckBoxSize` | `L`, `M`, `S` |
| `view` | `CheckBoxView` | `Default`, `Negative` |

Пример выбора готового стиля:
```kotlin
val style = CheckBoxStyles.style(
    size = CheckBoxSize.L,
    view = CheckBoxView.Default
)

// или через dot notation
val style = CheckBox.L.Default.style()
```


### Создание стиля с помощью builder()

```kotlin
CheckBoxStyle.builder()
    .colorValues {
        labelColor(/** Токен цвета */.asInteractive())
        descriptionColor(/** Токен цвета */.asInteractive())
        toggleColor(
            /** Токен цвета */.asInteractive(
                setOf(CheckBoxStates.Checked)
                    to /** Цвет в состоянии Checked */,
                setOf(CheckBoxStates.Indeterminate)
                    to /** Цвет в состоянии Indeterminate */,
                setOf(CheckBoxStates.Error)
                    to /** Цвет в состоянии Error */,
            ),
        )
        toggleIconColor(/** Токен цвета */.asInteractive())
        toggleBorderColor(
            /** Токен цвета */.asInteractive(
                setOf(InteractiveState.Focused, CheckBoxStates.Checked)
                    to /** Цвет в состоянии Checked */,
            ),
        )
    }
    .shape(/** Токен формы (скругления) */)
    .labelStyle(/** Токен типографики */)
    .descriptionStyle(/** Токен типографики */)
    .dimensionValues {
        toggleWidth(24.0.dp)
        toggleHeight(24.0.dp)
        toggleIconHeight(
            0.0.dp.asStatefulValue(
                setOf(CheckBoxStates.Checked) to 6.0.dp,
                setOf(CheckBoxStates.Indeterminate) to
                    2.0.dp,
            ),
        )
    }
    .style()
```

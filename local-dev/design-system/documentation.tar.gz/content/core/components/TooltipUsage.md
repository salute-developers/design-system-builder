---
title: Tooltip
---

Простое всплывающее окно с текстом. Раскрывает контекстную информацию об элементе при наведении.

### Простой пример использования кнопки вызова Tooltip

```kotlin
val showTooltip = remember { mutableStateOf(false) }
val triggerInfo = remember { mutableStateOf(TriggerInfo()) }
Button(
    modifier = Modifier
        .popoverTrigger(triggerInfo),
    label = "show",
    onClick = { showTooltip.value = true },
)
Tooltip(
    show = showTooltip.value,
    triggerInfo = { triggerInfo.value },
    placement = PopoverPlacement.Top,
    placementMode = PopoverPlacementMode.Loose,
    triggerCentered = false,
    alignment = PopoverAlignment.Start,
    onDismissRequest = {
        showTooltip.value = false
    },
    duration = 3000,
    text = AnnotatedString("Текст подсказки"),
)
```

<!-- @screenshot: com.sdds.compose.uikit.fixtures.samples.tooltip.Tooltip_Simple -->

> Важно понимать, что контент Tooltip рендерится в отдельном окне поверх основного окна. 
> Однако вызов Composable-функции Tooltip сам по себе формирует LayoutNode с нулевыми размерами, который размещается в основной верстке.
> Поэтому если вызов происходит в контейнерах с отступами между дочерними элементами, это может привести к нежелательным эффектам в ui (добавление ненужного отступа).
> Чтобы избежать такого эффекта, нужно размещать вызов Tooltip вне скоупа таких контейнеров, либо оборачивать в Box функцию триггера и Tooltip.

### Пример использования кнопки вызова Tooltip в Column

```kotlin
Column(
    verticalArrangement = Arrangement.spacedBy(8.dp),
) {
    Text(text = "Text")
    Box {
        val showTooltip = remember { mutableStateOf(false) }
        val triggerInfo = remember { mutableStateOf(TriggerInfo()) }
        Button(
            modifier = Modifier
                .popoverTrigger(triggerInfo),
            label = "show",
            onClick = { showTooltip.value = true },
        )
        Tooltip(
            show = showTooltip.value,
            triggerInfo = { triggerInfo.value },
            placement = PopoverPlacement.Top,
            placementMode = PopoverPlacementMode.Loose,
            triggerCentered = false,
            alignment = PopoverAlignment.Start,
            onDismissRequest = {
                showTooltip.value = false
            },
            duration = 3000,
            text = AnnotatedString("Tooltip Text"),
        )
    }
}
```

## Стиль Tooltip

В большинстве случаев можно использовать готовые сгенерированные стили, а при необходимости создать собственный стиль через соответствующий builder. Подробнее о том, как работают `Style`, `StyleBuilder` и stateful-параметры стиля, см. в разделе [Стилизация компонентов](../theme/Styles.md).

### Параметры стиля

| Параметр | Тип | Возможные значения |
| --- | --- | --- |
| `size` | `TooltipSize` | `M`, `S` |

Пример выбора готового стиля:
```kotlin
val style = TooltipStyles.style(
    size = TooltipSize.M
)

// или через dot notation
val style = Tooltip.M.style()
```


### Создание стиля с помощью builder()

```kotlin
TooltipStyle.builder()
    .shadow(/** Токен тени */)
    .shape(/** Токен формы(скругления) */)
    .dimensions {
        offset(8.0.dp)
        tailWidth(20.0.dp)
        tailHeight(8.0.dp)
        tailPadding(20.0.dp)
        contentStartSize(16.dp)
        contentStartPadding(4.dp)
        paddingStart(8.dp)
        paddingEnd(8.dp)
        paddingTop(8.dp)
        paddingBottom(8.dp)
    }
    .colors {
        backgroundColor(SolidColor(Color.Gray))
        textColor(SolidColor(Color.Black))
        contentStartColor(Color.Black)
    }
    .style()
```

## TriggerInfo

см. [TriggerInfo](PopoverUsage.md#triggerinfo)

## PopoverPlacement

см. [PopoverPlacement](PopoverUsage.md#popoverplacement)

## PopoverAlignment

см. [PopoverAlignment](PopoverUsage.md#popoveralignment)

## PopoverPlacementMode

см. [PopoverPlacementMode](PopoverUsage.md#popoverplacementmode)

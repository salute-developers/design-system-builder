---
title: CollapsingNavigationBar
---
Верхняя панель интерфейса, служащая для навигации и отображения ключевых действий. 
Умеет сворачиваться и разворачиваться в запвисимости от состояния скролла на экране.

В качестве заголовка, описания, контента и экшенов может принимать произвольный контент.

```kotlin
val scrollBehavior =
    CollapsingNavigationBarDefaults.exitUntilCollapsedScrollBehavior(
        rememberCollapsingNavigationBarState(),
    )
Column(
    modifier = Modifier.nestedScroll(scrollBehavior.nestedScrollConnection),
) {
    CollapsingNavigationBar(
        scrollBehavior = scrollBehavior,
        collapsedTitle = { Text("Title") },
        expandedTitle = { Text("Title") },
        collapsedDescription = { Text("Description") },
        expandedDescription = { Text("Description") },
        content = { Text("Content") },
        actionStart = {
            Icon(
                painter = painterResource(com.sdds.icons.R.drawable.ic_search_24),
                contentDescription = "",
            )
        },
        actionEnd = {
            Icon(
                painter = painterResource(com.sdds.icons.R.drawable.ic_menu_24),
                contentDescription = "",
            )
        },
        onBackPressed = {
            println("Back button was pressed")
        },
    )
    LazyColumn {
        items(100) {
            Text(modifier = Modifier.padding(32.dp), text = "Label text $it")
        }
    }
}
```

<!-- @screenshot: com.sdds.compose.uikit.fixtures.samples.collapsingnavigationbar.CollapsingNavigationBar_Simple -->

## Использование с коротким списком

По умолчанию `exitUntilCollapsedScrollBehavior` обрабатывает события вложенного скролла всегда. Поэтому навигационная панель может схлопываться при жесте над списком, даже если все его элементы помещаются во вьюпорте.

Чтобы панель реагировала на скролл только тогда, когда список действительно можно прокрутить, передайте в `canScroll` состояние `LazyColumn`:

```kotlin
val listState = rememberLazyListState()
val scrollBehavior =
    CollapsingNavigationBarDefaults.exitUntilCollapsedScrollBehavior(
        state = rememberCollapsingNavigationBarState(),
        canScroll = {
            listState.canScrollForward || listState.canScrollBackward
        },
    )

Column(
    modifier = Modifier.nestedScroll(scrollBehavior.nestedScrollConnection),
) {
    CollapsingNavigationBar(
        scrollBehavior = scrollBehavior,
        collapsedTitle = { Text("Title") },
        expandedTitle = { Text("Title") },
    )
    LazyColumn(
        state = listState,
    ) {
        items(3) {
            Text(modifier = Modifier.padding(32.dp), text = "Label text $it")
        }
    }
}
```

При такой настройке жест над коротким списком не схлопывает панель. При этом панель по-прежнему можно схлопывать и раскрывать жестом непосредственно на ней — это ожидаемое поведение `CollapsingNavigationBar`.

## Стиль CollapsingNavigationBar

В большинстве случаев можно использовать готовые сгенерированные стили, а при необходимости создать собственный стиль через соответствующий builder. Подробнее о том, как работают `Style`, `StyleBuilder` и stateful-параметры стиля, см. в разделе [Стилизация компонентов](../theme/Styles.md).

:::warning
Компонент не входит в текущую дизайн-систему.
:::

### Создание стиля с помощью builder()

```kotlin
CollapsingNavigationBarStyle.builder()
    .shadow(/** Токен тени */)
    .bottomShape(/** Токен формы(скругления) */)
    .titleStyle(/** Токен типографки */.asStatefulValue())
    .descriptionStyle(/** Токен типографки */.asStatefulValue())
    .backIcon(resourceImageSource(R.drawable.ic_disclosure_left_outline_24))
    .colors {
        backIconColor(/** Токен цвета */.asStatefulValue())
        titleColor(/** Токен цвета */.asStatefulValue())
        descriptionColor(/** Токен цвета */.asStatefulValue())
        actionStartColor(/** Токен цвета */.asStatefulValue())
        actionEndColor(/** Токен цвета */.asStatefulValue())
        backgroundColor(/** Токен цвета */.asStatefulValue())
    }
    .dimensions {
        paddingStart(20.0.dp)
        paddingEnd(20.0.dp)
        paddingTop(20.0.dp)
        paddingBottom(20.0.dp)
        backIconMargin(4.0.dp)
        textBlockTopMargin(16.0.dp)
        horizontalSpacing(16.0.dp)
        descriptionPadding(
            12.dp.asStatefulValue(
                setOf(CollapsingNavigationBarStates.Collapsed) to 4.dp,
            ),
        )
    }
    .style()
```

## NavigationBarTextAlign

Выравнивание текста. 
Возможные значения:

- Start (Текст расположен слева, оба экшена справа), 
- Center (Текст расположен в центре, левый экшен слева, правый экшен справа), 
- End (Текст расположен справа, оба экшена слева)

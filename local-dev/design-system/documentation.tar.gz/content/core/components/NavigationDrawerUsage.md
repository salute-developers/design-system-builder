---
title: NavigationDrawer
---

NavigationDrawer - боковая панель навигации с двумя состояниями: `Expanded` и `Collapsed`.
В развёрнутом состоянии отображает иконки, текстовый контент, end-контент и indicator. В схлопнутом состоянии
остаётся видимым интерактивным rail и скрывает текстовые и end-слоты.

В качестве элементов навигации используется `NavigationDrawerItem`. В `icon`, `titleContent`, `endContent`,
`indicator`, `header` и `footer` можно передавать произвольный composable-контент.

## NavigationDrawer в развёрнутом состоянии

```kotlin
val state = rememberNavigationDrawerState(NavigationDrawerValue.Expanded)
NavigationDrawer(
    state = state,
    header = {
        NavigationDrawerItem(
            modifier = Modifier.fillMaxWidth(),
            selected = false,
            onClick = { },
            icon = {
                Icon(
                    source = resourceImageSource(R.drawable.ic_menu_24),
                    contentDescription = "Menu",
                )
            },
            titleContent = { Text("Menu") },
        )
    },
    footer = {
        NavigationDrawerItem(
            modifier = Modifier.fillMaxWidth(),
            selected = false,
            icon = {
                Avatar(
                    placeholder = AvatarPlaceholder.Name("Michael Scot"),
                ) {
                    AsyncImage(
                        modifier = Modifier.matchParentSize(),
                        contentScale = ContentScale.Crop,
                        model = "https://cdn.costumewall.com/wp-content/uploads/2018/09/michael-scott.jpg",
                        contentDescription = "AsyncAvatar",
                    )
                }
            },
            titleContent = { Text("User") },
        )
    },
) {
    NavigationDrawerItem(
        selected = true,
        icon = { Icon(painterResource(R.drawable.ic_mail_outline_24), "") },
        titleContent = { Text("Inbox") },
        indicator = { Counter(count = "5") },
        onClick = {},
    )
    NavigationDrawerItem(
        icon = { Icon(painterResource(R.drawable.ic_settings_outline_24), "") },
        titleContent = { Text("Settings") },
        onClick = {},
    )
}
```

<!-- @screenshot: com.sdds.compose.uikit.fixtures.samples.navigationdrawer.NavigationDrawer_Expanded -->

## NavigationDrawer в схлопнутом состоянии

```kotlin
val state = rememberNavigationDrawerState(NavigationDrawerValue.Collapsed)
...
```

<!-- @screenshot: com.sdds.compose.uikit.fixtures.samples.navigationdrawer.NavigationDrawer_Collapsed -->

## Раскрытие при фокусе

Если передать `expandOnFocus = true`, drawer будет раскрываться при получении фокуса внутри subtree
и схлопываться при потере фокуса.

## NavigationDrawer с ленивым списком

Если в меню много элементов, используйте перегрузку `NavigationDrawer` с `lazyContent: LazyListScope.() -> Unit`.
Внутри она использует `LazyColumn`, поэтому элементы будут создаваться лениво по мере прокрутки.

```kotlin
val selectedIndex = remember { mutableIntStateOf(0) }
val state = rememberNavigationDrawerState(NavigationDrawerValue.Expanded)

NavigationDrawer(
    state = state,
    lazyContent = {
        items(count = 50) { index ->
            NavigationDrawerItem(
                selected = selectedIndex.intValue == index,
                icon = { Icon(painterResource(R.drawable.ic_mail_outline_24), "") },
                titleContent = { Text("Item $index") },
                onClick = { selectedIndex.intValue = index },
            )
        }
    },
)
```

## Состояние NavigationDrawer

Для управления состоянием используется `NavigationDrawerState`, который можно создать через
`rememberNavigationDrawerState()`.

Основные возможности состояния:

- `currentValue` - текущее зафиксированное состояние.
- `targetValue` - целевое состояние.
- `progress` - прогресс раскрытия от `0f` (`Collapsed`) до `1f` (`Expanded`).
- `expand()` - раскрывает drawer.
- `collapse()` - схлопывает drawer.
- `snapTo(value)` - мгновенно устанавливает состояние без визуального перехода.

## NavigationDrawerItem

`NavigationDrawerItem` поддерживает выбранное и отключённое состояние, обработчик клика и слоты контента.
В схлопнутом состоянии отображается start-зона с `icon`, а `titleContent`, `endContent` и end-indicator
скрываются. Indicator дополнительно может отображаться поверх start-зоны в схлопнутом состоянии.

## Стиль NavigationDrawer

В большинстве случаев можно использовать готовые сгенерированные стили, а при необходимости создать
собственный стиль через соответствующий builder. Подробнее о том, как работают `Style`, `StyleBuilder`
и stateful-параметры стиля, см. в разделе [Стилизация компонентов](../theme/Styles.md).

:::warning
Компонент не входит в текущую дизайн-систему.
:::

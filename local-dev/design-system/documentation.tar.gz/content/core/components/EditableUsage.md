---
title: Editable
---
Редактируемое текстовое поле. Может иметь иконку справа.

### Простой пример
```kotlin
var text by remember { mutableStateOf(TextFieldValue("Value")) }
Editable(
    value = text,
    onValueChange = { text = it },
)
```

### Пример с иконкой и абсолютным расположением
```kotlin
var text by remember { mutableStateOf(TextFieldValue("Value")) }
val focusRequester = remember { FocusRequester() }
Editable(
    modifier = Modifier
        .focusRequester(focusRequester),
    value = text,
    onValueChange = { text = it },
    icon = {
        Icon(
            modifier = Modifier
                .clickable(
                    indication = null,
                    interactionSource = remember { MutableInteractionSource() },
                ) {
                    focusRequester.requestFocus()
                    text = text.copy(selection = TextRange(text.text.length))
                },
            painter = painterResource(R.drawable.ic_edit_fill_36),
            contentDescription = null,
        )
    },
    iconPlacement = EditableIconPlacement.Absolute,
    textAlign = TextAlign.Center,
)
```

### Пример с иконкой и относительным расположением
```kotlin
var text by remember { mutableStateOf(TextFieldValue("Value")) }
val focusRequester = remember { FocusRequester() }
Editable(
    modifier = Modifier
        .focusRequester(focusRequester),
    value = text,
    onValueChange = { text = it },
    icon = {
        Icon(
            modifier = Modifier
                .clickable(
                    indication = null,
                    interactionSource = remember { MutableInteractionSource() },
                ) {
                    focusRequester.requestFocus()
                    text = text.copy(selection = TextRange(text.text.length))
                },
            painter = painterResource(R.drawable.ic_edit_fill_36),
            contentDescription = null,
        )
    },
    iconPlacement = EditableIconPlacement.Relative,
    textAlign = TextAlign.Center,
)
```

<!-- @screenshot: com.sdds.compose.uikit.fixtures.samples.editable_Editable_RelativeIcon -->

## Стиль Editable

В большинстве случаев можно использовать готовые сгенерированные стили, а при необходимости создать собственный стиль через соответствующий builder. Подробнее о том, как работают `Style`, `StyleBuilder` и stateful-параметры стиля, см. в разделе [Стилизация компонентов](../theme/Styles.md).

### Параметры стиля

| Параметр | Тип | Возможные значения |
| --- | --- | --- |
| `size` | `EditableDefaultSize` | `H1`, `H2`, `H3`, `H4`, `H5`, `BodyL`, `BodyM`, `BodyS`, `BodyXs`, `BodyXxs` |

Пример выбора готового стиля:
```kotlin
val style = EditableStyles.Default.style(
    size = EditableDefaultSize.H1
)

// или через dot notation
val style = Editable.H1.style()
```


### Параметры стиля `AiUserMessageEditable`

| Параметр | Тип | Возможные значения |
| --- | --- | --- |
| `size` | `AiUserMessageEditableSize` | `Xl`, `L`, `M`, `S`, `Xs` |

Пример выбора готового стиля:
```kotlin
val style = EditableStyles.AiUserMessageEditable.style(
    size = AiUserMessageEditableSize.M
)

// или через dot notation
val style = AiUserMessageEditable.M.style()
```


### Создание стиля с помощью builder()

```kotlin
EditableStyle.builder()
    .colors {
        iconColor(/** Токен цвета */)
        textColor(/** Токен цвета */)
        cursorColor(/** Токен цвета */)
    }
    .dimensions {
        iconMargin(2.dp)
        iconSize(16.dp)
    }
    .textStyle(/** Токен типографики */)
    .style()
```

## EditableIconPlacement

Режим расположения иконки в компоненте. 
Возможные значения: `Absolute` (иконка не учитывается в лэйауте компонента), `Relative` (иконка включена в лэйаут компонента).


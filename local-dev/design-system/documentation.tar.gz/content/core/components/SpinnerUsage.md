---
title: Spinner
---

Индикатор бесконечной загрузки.

```kotlin
Spinner(
    modifier = Modifier,
    interactionSource = remember { MutableInteractionSource() },
)
```

<!-- @screenshot: com.sdds.compose.uikit.fixtures.samples.spinner.Spinner_Simple -->

## Стиль Spinner

В большинстве случаев можно использовать готовые сгенерированные стили, а при необходимости создать собственный стиль через соответствующий builder. Подробнее о том, как работают `Style`, `StyleBuilder` и stateful-параметры стиля, см. в разделе [Стилизация компонентов](../theme/Styles.md).

### Параметры стиля

| Параметр | Тип | Возможные значения |
| --- | --- | --- |
| `size` | `SpinnerSize` | `Xxl`, `Xl`, `L`, `M`, `S`, `Xs`, `Xxs`, `Scalable` |
| `view` | `SpinnerView` | `Default`, `Secondary`, `Accent`, `Positive`, `Negative`, `Warning`, `Info` |

Пример выбора готового стиля:
```kotlin
val style = SpinnerStyles.style(
    size = SpinnerSize.Xxl,
    view = SpinnerView.Default
)

// или через dot notation
val style = Spinner.Xxl.Default.style()
```


### Создание стиля с помощью builder()

```kotlin
SpinnerStyle.builder()
    .angle(360f)
    .strokeCap(SpinnerStrokeCap.Round)
    .dimensions {
        size(16.0.dp)
        strokeWidth(2.dp)
        padding(1.dp)
    }
    .colors {
        backgroundColor(Color.LightGray)
        startColor(Color.LightGray)
        endColor(Color.Black)
    }
    .style()
```

## SpinnerStrokeCap

Вид концов спиннера. Возможные значения: Round, Square

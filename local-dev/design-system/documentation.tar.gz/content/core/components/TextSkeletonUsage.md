---
title: TextSkeleton
---
Компонент представляет из себя контейнер (Column),
в котором может отображаться указанное количество строк-заглушек с анимированным мерцанием,  
представленных компонентом [RectSkeleton](RectSkeletonUsage.md), поверх которых возможно наложение текста.  
Высота строк и оступы между строками высчитываются на основе переданного стиля текста.  
Ширина строк настраивается провайдером SkeletonLineWidthProvider и может быть двух видов -  
на всю ширину контейнера или с учетом псевдо отклонения от ширины (имитируется неравномерность, как при написании текста).

Для заглушек произвольной формы используй [RectSkeleton](RectSkeletonUsage.md)

Поддерживает два типа анимации: перемещающийся градиент и фон, плавно изменюящий альфу.

### Простой пример использования
```kotlin
TextSkeleton(
    textStyle = /** Токен стиля текста */,
)
```

<!-- @screenshot: com.sdds.compose.uikit.fixtures.samples.textskeleton.TextSkeleton_Simple -->

### Пример использования с кастомизацией
```kotlin
TextSkeleton(
    textStyle = /** Токен стиля текста */,
    lineCount = 5,
    lineWidthProvider = SkeletonLineWidthProvider.RandomDeviation(),
    brush = /** Токен градиента */,
    duration = 1000,
    shape = /** Токен формы(скругления) */,
)
```

<!-- @screenshot: com.sdds.compose.uikit.fixtures.samples.textskeleton.TextSkeleton_Custom -->

> Параметр `brush` влияет на тип анимации. Если в brush установлен градиент, то скелетон будет выглядеть как перемещающийся в пространстве градиент.
> Если в brush передан SolidColor(), будет анимация мерцания - изменение альфы исходного цвета.

## Стиль TextSkeleton

В большинстве случаев можно использовать готовые сгенерированные стили, а при необходимости создать собственный стиль через соответствующий builder. Подробнее о том, как работают `Style`, `StyleBuilder` и stateful-параметры стиля, см. в разделе [Стилизация компонентов](../theme/Styles.md).

### Параметры стиля

| Параметр | Тип | Возможные значения |
| --- | --- | --- |
| `view` | `TextSkeletonView` | `Default`, `Lighter` |

Пример выбора готового стиля:
```kotlin
val style = TextSkeletonStyles.style(
    view = TextSkeletonView.Default
)

// или через dot notation
val style = TextSkeleton.Default.style()
```


### Создание стиля с помощью builder()

```kotlin
TextSkeletonStyle.builder()
    .gradient(Color.Cyan)
    .shape(CircleShape)
    .duration(700)
    .style()
```
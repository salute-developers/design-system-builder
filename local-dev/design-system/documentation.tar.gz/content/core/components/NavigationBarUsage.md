---
title: NavigationBar
---
Верхняя панель интерфейса, служащая для навигации и отображения ключевых действий.

В качестве текста, контента и экшенов может принимать произвольный контент.

### Простой пример NavigationBar с встроенным текстом и экшеном в конце

```kotlin
NavigationBar(
    textPlacement = NavigationBarTextPlacement.Inline,
    textContent = { Text("Text") },
    actionStart = {
        Icon(
            modifier = Modifier.clickable { /* действие */ },
            painter = painterResource(com.sdds.icons.R.drawable.ic_search_24),
            contentDescription = "",
        )
    },
    actionEnd = {
        Icon(
            modifier = Modifier.clickable { /* действие */ },
            painter = painterResource(com.sdds.icons.R.drawable.ic_menu_24),
            contentDescription = "",
        )
    },
)
```

<!-- @screenshot: com.sdds.compose.uikit.fixtures.samples.navigationbar.NavigationBar_Simple -->

### Пример NavigationBar с встроенными title и description

```kotlin
NavigationBar(
    textPlacement = NavigationBarTextPlacement.Inline,
    titleContent = { Text("Title") },
    descriptionContent = { Text("Description") },
    actionStart = {
        Icon(
            modifier = Modifier.clickable { /* действие */ },
            painter = painterResource(com.sdds.icons.R.drawable.ic_search_24),
            contentDescription = "",
        )
    },
    actionEnd = {
        Icon(
            modifier = Modifier.clickable { /* действие */ },
            painter = painterResource(com.sdds.icons.R.drawable.ic_menu_24),
            contentDescription = "",
        )
    },
)
```

### Пример NavigationBar с встроенным текстом и контентом снизу

```kotlin
NavigationBar(
    textPlacement = NavigationBarTextPlacement.Inline,
    contentPlacement = NavigationBarContentPlacement.Bottom,
    textAlign = NavigationBarTextAlign.Start,
    textContent = { Text("Text") },
    content = { Text("Content") },
    actionEnd = {
        Icon(
            modifier = Modifier.clickable { /* действие */ },
            painter = painterResource(com.sdds.icons.R.drawable.ic_menu_24),
            contentDescription = "",
        )
    },
)
```

### Пример NavigationBar с текстом и контентом снизу, двумя экшенами справа

```kotlin
NavigationBar(
    textPlacement = NavigationBarTextPlacement.Bottom,
    contentPlacement = NavigationBarContentPlacement.Bottom,
    textAlign = NavigationBarTextAlign.Center,
    titleContent = { Text("Text") },
    actionEnd = {
        Icon(
            modifier = Modifier.clickable { /* действие */ },
            painter = painterResource(com.sdds.icons.R.drawable.ic_search_24),
            contentDescription = "",
        )
        Icon(
            modifier = Modifier.clickable { /* действие */ },
            painter = painterResource(com.sdds.icons.R.drawable.ic_menu_24),
            contentDescription = "",
        )
    },
)
```

### Пример NavigationBar c абсолютным центрированием встроенного текста

```kotlin
NavigationBar(
    centerAlignmentStrategy = NavBarCenterAlignmentStrategy.Absolute,
    textPlacement = NavigationBarTextPlacement.Inline,
    titleContent = { Text("Title") },
    descriptionContent = { Text("Description") },
    actionEnd = {
        Icon(
            modifier = Modifier.clickable { /* действие */ },
            painter = painterResource(com.sdds.icons.R.drawable.ic_search_24),
            contentDescription = "",
        )
        Icon(
            modifier = Modifier.clickable { /* действие */ },
            painter = painterResource(com.sdds.icons.R.drawable.ic_menu_24),
            contentDescription = "",
        )
    },
)
```

### Пример NavigationBar c относительным центрированием встроенного текста

```kotlin
NavigationBar(
    centerAlignmentStrategy = NavBarCenterAlignmentStrategy.Relative,
    textPlacement = NavigationBarTextPlacement.Inline,
    titleContent = { Text("Title") },
    descriptionContent = { Text("Description") },
    actionEnd = {
        Icon(
            modifier = Modifier.clickable { /* действие */ },
            painter = painterResource(com.sdds.icons.R.drawable.ic_search_24),
            contentDescription = "",
        )
        Icon(
            modifier = Modifier.clickable { /* действие */ },
            painter = painterResource(com.sdds.icons.R.drawable.ic_menu_24),
            contentDescription = "",
        )
    },
)
```

## Стиль NavigationBar

В большинстве случаев можно использовать готовые сгенерированные стили, а при необходимости создать собственный стиль через соответствующий builder. Подробнее о том, как работают `Style`, `StyleBuilder` и stateful-параметры стиля, см. в разделе [Стилизация компонентов](../theme/Styles.md).

### Параметры стиля `NavigationBarMainPage`

| Параметр | Тип | Возможные значения |
| --- | --- | --- |
| `hasBackground` | `Boolean` | `true`, `false` |
| `hasShadow` | `Boolean` | `true`, `false` |
| `rounded` | `Boolean` | `true`, `false` |

Пример выбора готового стиля:
```kotlin
val style = NavigationBarStyles.MainPage.style(
    hasBackground = false,
    hasShadow = false,
    rounded = false
)

// или через dot notation
val style = NavigationBarMainPage.NoBackground.style()
```


### Параметры стиля `NavigationBarInternalPage`

| Параметр | Тип | Возможные значения |
| --- | --- | --- |
| `hasBackground` | `Boolean` | `true`, `false` |
| `hasShadow` | `Boolean` | `true`, `false` |
| `rounded` | `Boolean` | `true`, `false` |

Пример выбора готового стиля:
```kotlin
val style = NavigationBarStyles.InternalPage.style(
    hasBackground = false,
    hasShadow = false,
    rounded = false
)

// или через dot notation
val style = NavigationBarInternalPage.NoBackground.style()
```


### Создание стиля с помощью builder()

```kotlin
NavigationBarStyle.builder()
    .shadow(/** Токен тени */)
    .bottomShape(/** Токен формы(скругления) */)
    .textStyle(/** Токен типографки */)
    .backIcon(resourceImageSource(com.sdds.icons.R.drawable.ic_disclosure_left_outline_24))
    .colors {
        backIconColor(/** Токен цвета */.asInteractive())
        textColor(/** Токен цвета */.asInteractive())
        actionStartColor(/** Токен цвета */.asInteractive())
        actionEndColor(/** Токен цвета */.asInteractive())
        backgroundColor(/** Токен цвета */.asInteractive())
    }
    .dimensions {
        paddingStart(20.0.dp)
        paddingEnd(20.0.dp)
        paddingTop(20.0.dp)
        paddingBottom(20.0.dp)
        backIconMargin(4.0.dp)
        textBlockTopMargin(16.0.dp)
        horizontalSpacing(16.0.dp)
    }
    .style()
```

## NavigationBarTextPlacement

Расположение текста. Возможные значения: Inline (встроен в основной блок), Bottom (снизу от основного блока)

## NavigationBarContentPlacement

Расположение контента. Возможные значения: Inline (встроен в основной блок), Bottom (снизу от основного блока)

## NavigationBarTextAlign

Выравнивание встроенного текста (при textPlacement == NavigationBarTextPlacement.Inline). 
Возможные значения:

- Start (Текст расположен слева, оба экшена справа), 
- Center (Текст расположен в центре, левый экшен слева, правый экшен справа), 
- End (Текст расположен справа, оба экшена слева)

## NavBarCenterAlignmentStrategy

Режим центрирования текстового блока. Работает только при `NavigationBarTextAlign.Center` и `NavigationBarTextPlacement.Inline` (см. [NavigationBarTextAlign](#NavigationBarTextAlign), [NavigationBarTextPlacement](#NavigationBarTextPlacement))

Возможные значения: 

- Relative (Текст центрируется в доступном пространстве между экшенами)
- Absolute (Текст центрируется по ширине компонента независимо от того, сколько пространства занимают экшены)
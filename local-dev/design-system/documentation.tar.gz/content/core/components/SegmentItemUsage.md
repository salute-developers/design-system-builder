---
title: SegmentItem
---

```kotlin
SegmentItem(
    isSelected = true,
    label = "Label",
    value = "Value",
    startIcon = painterResource(id = com.sdds.icons.R.drawable.ic_scribble_diagonal_24),
    counter = "55",
    enabled = true,
)
```

<!-- @screenshot: com.sdds.compose.uikit.fixtures.samples.segment.SegmentItem_Simple -->

## Стиль SegmentItem

В большинстве случаев можно использовать готовые сгенерированные стили, а при необходимости создать собственный стиль через соответствующий builder. Подробнее о том, как работают `Style`, `StyleBuilder` и stateful-параметры стиля, см. в разделе [Стилизация компонентов](../theme/Styles.md).

### Параметры стиля

| Параметр | Тип | Возможные значения |
| --- | --- | --- |
| `size` | `SegmentItemSize` | `Xl`, `L`, `M`, `S`, `Xs` |
| `shape` | `SegmentItemShape` | `Default`, `Pilled` |
| `view` | `SegmentItemView` | `Primary`, `Secondary`, `Accent` |

Пример выбора готового стиля:
```kotlin
val style = SegmentItemStyles.style(
    size = SegmentItemSize.Xl,
    shape = SegmentItemShape.Default,
    view = SegmentItemView.Primary
)

// или через dot notation
val style = SegmentItem.Xl.Primary.style()
```


### Создание стиля с помощью builder()

```kotlin
SegmentItemStyle.builder()
    .colors {
        labelColor(
            /** Цвет токена */.asInteractive(
                setOf(InteractiveState.Hovered)
                    to /** Цвет в состоянии hovered */,
            ),
        )
        valueColor(
            /** Токен типографики */.asInteractive(
                setOf(InteractiveState.Hovered)
                    to /** Цвет в состоянии hovered */,
            ),
        )
        backgroundColor(
            /** Токен типографики */.asInteractive(
                setOf(InteractiveState.Hovered)
                    to /** Цвет в состоянии hovered */,
            ),
        )
        startContentColor(
            /** Цвет токена */.asInteractive(
                setOf(InteractiveState.Hovered)
                    to /** Цвет в состоянии hovered */,
            ),
        )
        endContentColor(
            /** Цвет токена */.asInteractive(
                setOf(InteractiveState.Hovered)
                    to /** Цвет в состоянии hovered */,
            ),
        )
    }
    .shape(/** Токе формы(скругления) */.adjustBy(all = 0.0.dp))
    .labelStyle(/** Токен типографики */)
    .valueStyle(/** Токен типографики */)
    .dimensions {
        minWidth(110.0.dp)
        minHeight(64.0.dp)
        paddingStart(28.0.dp)
        paddingEnd(28.0.dp)
        startContentSize(24.0.dp)
        endContentSize(24.0.dp)
        valueMargin(6.0.dp)
    }
    .counterStyle(/** Стиль компонента */)
    .style()
```

## Состояния и Motion API

У всех трёх форм `SegmentItem` есть перегрузка с `motion: Motion<SegmentItemMotionStyle>`.
`rememberSegmentItemMotion()` использует переданный стиль переходов или `LocalSegmentItemMotionStyle`.
Через `SegmentItemMotionStyle` настраиваются переходы фона, текста, иконок, типографики и всех размеров/отступов.
По умолчанию используется `noMotion()`, поэтому добавление Motion само по себе не запускает анимации.

```kotlin
var selected by remember { mutableStateOf(false) }
val selectedState = setOf(InteractiveState.Selected)
val counterStyle = CounterStyle.builder()
    .colors { backgroundBrush(Color.LightGray.asStatefulBrush(selectedState to Color.Green)) }
    .style()
val style = SegmentItemStyle.builder()
    .colors { backgroundColor(Color.LightGray.asStatefulBrush(selectedState to Color.Cyan)) }
    .labelStyle(TextStyle(fontSize = 14.sp))
    .dimensions {
        minHeight(40.dp.asStatefulValue(selectedState to 48.dp))
        valueMargin(4.dp.asStatefulValue(selectedState to 12.dp))
    }
    .counterStyle(counterStyle)
    .style()
val motion = rememberSegmentItemMotion(
    style = SegmentItemMotionStyle.builder()
        .backgroundColor(transition { segment {} changesWith { finite(tween(200)) } })
        .minHeight(transition { segment {} changesWith { finite(tween(200)) } })
        .valueMargin(transition { segment {} changesWith { finite(tween(200)) } })
        .style(),
)
SegmentItem(
    motion = motion,
    style = style,
    label = "Сообщения",
    value = "Новые",
    counter = "7",
    isSelected = selected,
    modifier = Modifier.clickable(
        interactionSource = motion.context.interactionSource,
        indication = null,
    ) { selected = !selected },
)
```

`isSelected` обновляет семантическое состояние элемента. Для pressed, hovered и focused передавайте
`motion.context.interactionSource` в модификатор взаимодействия, например `clickable`.
Встроенный Counter использует тот же контекст состояний и собственные CounterStyle/CounterMotionStyle.
У произвольного содержимого слотов общий контекст задаётся явно.
При наличии `endIcon` счётчик не отображается; null или пустой counter не создаёт слот счётчика.

### Переход со старых свойств

Старые перегрузки компонента и builder-вызовы с Color, InteractiveColor, Dp, TextStyle и формой продолжают работать.
Новые свойства для чтения: `shapes`, `labelStyles`, `valueStyles`, цвета с суффиксом `Brush`
и размеры с суффиксом `Values`, например `dimensions.endContentSizeValues`.
Размер конечной иконки определяется `endContentSize`, независимо от размера начальной иконки;
отступ `valueMargin` учитывает также selected из семантического источника.

Старые deprecated-свойства формы, размеров и типографики возвращают default-значения.
Legacy InteractiveColor сохраняет однотонные состояния; для градиентов его fallback — Color.Transparent.
Отрисовка через новые Brush-свойства поддерживает градиенты.
Форма переключается без плавной интерполяции, `disabledAlpha` остаётся обычным Float.
Собственные реализации style/builder-интерфейсов необходимо дополнить новыми контрактами.

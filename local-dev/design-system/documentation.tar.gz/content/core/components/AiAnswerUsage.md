---
title: AiAnswer
---

Компонент AiAnswer используется для отображения ответа ассистента в ИИ-сценариях.
Он поддерживает три семантических состояния: `Default`, `Loading` и `Error`.

AiAnswer не разбирает разметку, форматированный текст, потоковые фрагменты и ссылки на источники, а также не владеет моделями ответа, действий или подсказок.
Нужная отрисовка передаётся в `content`, действия - в `actionsStart` и `actionsEnd`, подсказки - в `suggestions`.

## Обычное состояние

```kotlin
AiAnswer(
    title = { Text("Ответ ассистента") },
    content = {
        Text("SDDS Compose позволяет собрать ответ из обычных composable-слотов.")
    },
    actionsStart = {
        button { IconButton(iconRes = R.drawable.ic_copy_outline_24, onClick = {}) }
        button { IconButton(iconRes = R.drawable.ic_like_outline_24, onClick = {}) }
        button { IconButton(iconRes = R.drawable.ic_dislike_outline_24, onClick = {}) }
    },
    actionsEnd = {
        button { Button(label = "Повторить", onClick = {}) }
    },
    suggestions = {
        Chip(label = "Подробнее", onClick = {})
        Chip(label = "Кратко", onClick = {})
    },
)
```

<!-- @screenshot: com.sdds.compose.uikit.fixtures.samples.answer.AiAnswer_Default -->

## Загрузка

Слот загрузки может полностью заменить стандартную отрисовку или вызвать вспомогательную функцию `AiAnswerLoading`.

```kotlin
AiAnswer(
    state = AiAnswerState.Loading,
    loading = {
        AiAnswerLoading(text = { Text("Ищем подходящий ответ") })
    },
)
```

## Ошибка

Слот ошибки может полностью заменить стандартную отрисовку или вызвать вспомогательную функцию `AiAnswerError`.

```kotlin
AiAnswer(
    state = AiAnswerState.Error,
    error = {
        AiAnswerError(
            title = { Text("Ответ недоступен") },
            text = { Text("Попробуйте изменить запрос.") },
        )
    },
)
```

## Стиль AiAnswer

В большинстве случаев можно использовать готовые сгенерированные стили, а при необходимости создать собственный стиль через метод `builder()`. Подробнее о том, как работают `Style`, `StyleBuilder` и параметры стиля с состояниями, см. в разделе [Стилизация компонентов](../theme/Styles.md).

### Параметры стиля

| Параметр | Тип | Возможные значения |
| --- | --- | --- |
| `size` | `AiAnswerSize` | `Xl`, `L`, `M`, `S`, `Xs` |

Пример выбора готового стиля:
```kotlin
val style = AiAnswerStyles.style(
    size = AiAnswerSize.M
)

// или через dot notation
val style = AiAnswer.M.style()
```


### Создание стиля с помощью builder()

```kotlin
AiAnswerStyle.builder()
    .colors {
        background(Color.Transparent)
        titleColor(Color.Black)
        contentColor(Color.DarkGray)
        loadingTextColor(Color.DarkGray)
    }
    .titleStyle(/** Токен типографики */)
    .contentStyle(/** Токен типографики */)
    .loadingTextStyle(/** Токен типографики */)
    .dimensions {
        paddingStart(0.dp)
        paddingEnd(0.dp)
        paddingTop(0.dp)
        paddingBottom(0.dp)
        contentGap(8.dp)
        actionsGap(12.dp)
        suggestionsGap(12.dp)
        loadingGap(8.dp)
    }
    .noteStyle(/** Стиль Note */)
    .loadingSpinnerStyle(/** Стиль Spinner */)
    .actionsStartButtonGroupStyle(/** Стиль ButtonGroup */)
    .actionsEndButtonGroupStyle(/** Стиль ButtonGroup */)
    .suggestionsChipGroupStyle(/** Стиль ChipGroup */)
    .style()
```

## Слоты

- `title` и `content` - обычные необязательные composable-слоты.
- `actionsStart` и `actionsEnd` - слоты с областью видимости `ButtonGroupScope`, каждый отрисовывается в отдельном ButtonGroup.
- `suggestions` - слот с областью видимости `FlowRowScope`, отрисовывается внутри ChipGroup.
- `loading` и `error` - слоты с областью видимости и доступом к текущим `AiAnswerState`, `AiAnswerStyle` и `Motion<AiAnswerMotionStyle>`.

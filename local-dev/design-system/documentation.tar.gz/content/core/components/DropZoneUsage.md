---
title: DropZone
---

DropZone - Интерактивная область, предназначенная для перетаскивания и загрузки файлов.

Представляет собой контейнер, в котором, в качестве подсказок, возможно разместить заголовок, описание 
и контент (контент может быть любым @composable). Если в качестве контента провайдится иконка, она будет  
автоматически стилизована.

## Простой пример использования DropZone

```kotlin
DropZone(
    state = DropZoneState.Idle,
    iconPlacement = DropZoneIconPlacement.Top,
    title = {
        Text(text = "title")
    },
    description = {
        Text(text = "description")
    },
    icon = {
        Icon(
            source = resourceImageSource(R.drawable.ic_salute_outline_24),
            contentDescription = null,
        )
    },
)
```

## Состояние DropZone

Для управления состоянием используется DropZoneState. Это семантические состояния для изменения внешнего вида  
компонента в процессе взаимодействия с ним. Компонент стилизуется автоматически при передаче актуального состояния

## Пример использования DropZone с изменением состояния при перетаскивании контента

```kotlin
var dragOver by remember { mutableStateOf(false) }
var state by remember { mutableStateOf(DropZoneState.Idle) }
Column(
    verticalArrangement = Arrangement.spacedBy(32.dp),
    horizontalAlignment = Alignment.CenterHorizontally,
) {
    Box(
        modifier = Modifier.dragAndDropTarget(
            shouldStartDragAndDrop = { true },
            target = remember {
                object : DragAndDropTarget {
                    override fun onEntered(event: DragAndDropEvent) {
                        dragOver = true
                    }

                    override fun onExited(event: DragAndDropEvent) {
                        dragOver = false
                    }

                    override fun onEnded(event: DragAndDropEvent) {
                        dragOver = false
                    }

                    override fun onDrop(event: DragAndDropEvent): Boolean {
                        dragOver = false
                        return true
                    }
                }
            },
        ),
    ) {
        val motion = rememberDropZoneMotion()
        DropZone(
            modifier = Modifier
                .focusable(state != DropZoneState.Disabled, motion.context.interactionSource),
            state = if (dragOver) DropZoneState.DraggingOver else state,
            motion = motion,
            iconPlacement = DropZoneIconPlacement.Top,
            title = {
                Text(text = "title")
            },
            description = {
                Text(text = "description")
            },
            icon = {
                Icon(
                    painter = painterResource(R.drawable.ic_salute_outline_24),
                    contentDescription = null,
                )
            },
        )
    }

    File(
        modifier = Modifier.dragAndDropSource(transferData = {
            DragAndDropTransferData(
                clipData = ClipData.newPlainText("demo", "demo"),
            )
        }),
        labelContent = {
            Text(
                text = "Draggable file",
            )
        },
        descriptionContent = {},
        image = {
            Icon(
                painter = painterResource(R.drawable.ic_file_check_fill_36),
                contentDescription = null,
            )
        },
    )
}
```

## Расположение контента (иконки) в DropZone

Расположение контента задается при помощи DropZoneIconPlacement, возможны три сценария  
- контент расположен над заголовком
- контент расположен вначале, на одном уровне с заголовком
- контент не отображается

## Обводка DropZone

Для визуального эффекта в DropZone используется обводка по границе компонента. При взаимодействии и  
передачи в DropZone актуального DropZoneState, обводка стилизуется автоматически. Изменение внешнего вида  
бордера возможно при мощи DropZoneBorderType
- в виде прерывистой линии (пунктирной)
- в виде сплошной линии
- не отображать

## OnClick() 

В DropZone предусмотрен параметр `onClick: (() -> Unit)? = null`, с помощью которого, на стороне пользователя  
возможна настройка поведения при клике по компоненту. Например это может быть полезным в сценарии, при котором  
кликая по области DropZone открывается файловый менеджер для выбора файла.

## Стиль DropZone

В большинстве случаев можно использовать готовые сгенерированные стили, а при необходимости создать
собственный стиль через соответствующий builder. Подробнее о том, как работают `Style`, `StyleBuilder`
и stateful-параметры стиля, см. в разделе [Стилизация компонентов](../theme/Styles.md).

Пример выбора готового стиля:
```kotlin
val style = DropZoneStyles.style()

// или через dot notation
val style = DropZone.Default.style()
```


### Создание стиля с помощью builder()

```kotlin
DropZoneStyle.builder()
    .shape(/** Токен формы (скругления) */)
    .overlayStyle(/** Стиль overlay */)
    .iconPlacement(DropZoneIconPlacement.Top)
    .borderType(DropZoneBorderType.Dashes)
    .colors {
        background(/** Токен цвета */)
        iconColor(/** Токен цвета */)
        titleColor(/** Токен цвета */)
        descriptionColor(/** Токен цвета */)
        borderColor(/** Токен цвета */)
    }
    .dimensions {
        paddingStart(24.0.dp)
        paddingEnd(24.0.dp)
        paddingTop(24.0.dp)
        paddingBottom(24.0.dp)
        iconSize(24.0.dp)
        borderThickness(1.0.dp)
        borderDashWidth(6.0.dp)
        borderDashGap(8.0.dp)
        iconPadding(8.0.dp)
        gap(12.0.dp)
    }
    .disableAlpha(0.4f)
    .titleStyle(/** Токен типографики */)
    .descriptionStyle(/** Токен типографики */)
    .style()
```
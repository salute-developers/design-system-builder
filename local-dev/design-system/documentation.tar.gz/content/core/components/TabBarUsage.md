---
title: TabBar
---

Компонент для навигации между разделами интерфейса
В качестве контента принимает либо [TabBarItem](#tabbaritem) либо произвольный контент. 
TabBarItem в качестве extra ожидает [Counter](CounterUsage.md), [Badge](BadgeUsage.md), [Indicator](IndicatorUsage.md) либо произвольный контент.

По умолчанию элементы добавляются с weight = 1 и равномерно занимают доступную ширину TabBar.
Если необходимо добавить элемент произвольной ширины, необходимо при использовании функции tabItem() установить параметр weight = null.

### Простой пример TabBar

```kotlin
var selectedIndex by remember { mutableStateOf(0) }

TabBar {
    repeat(3) { index ->
        tabItem {
            val isSelected = index == selectedIndex
            TabBarItem(
                isSelected = isSelected,
                icon = {
                    AnimatedContent(
                        targetState = isSelected,
                        transitionSpec = {
                            fadeIn(tween(200))
                                .togetherWith(fadeOut(tween(200)))
                        },
                    ) {
                        val iconSource = resourceImageSource(
                            if (it) {
                                getIconSelected(index)
                            } else {
                                getIcon(index)
                            },
                        )
                        Icon(source = iconSource, contentDescription = "")
                    }
                },
                labelContent = { Text(getTitle(index)) },
                onClick = {
                    selectedIndex = index
                },
            )
        }
    }
}
```

<!-- @screenshot: com.sdds.compose.uikit.fixtures.samples.tabbar.TabBar_Simple -->

### Пример TabBar с Counter

```kotlin
var selectedIndex by remember { mutableStateOf(0) }

TabBar {
    repeat(3) { index ->
        tabItem {
            val isSelected = index == selectedIndex
            TabBarItem(
                isSelected = isSelected,
                icon = { TabIcon(index, isSelected) },
                labelContent = { Text(getTitle(index)) },
                extra = if (index == 2) {
                    { Counter(count = "3") }
                } else {
                    null
                },
                onClick = {
                    selectedIndex = index
                },
            )
        }
    }
}
```

### Пример TabBar с кастомным центральным элементом с фиксированной шириной

```kotlin
var selectedIndex by remember { mutableStateOf(0) }

TabBar {
    tabItem {
        val isSelected = selectedIndex == 0
        TabBarItem(
            isSelected = isSelected,
            icon = { TabIcon(0, isSelected) },
            labelContent = { Text(getTitle(0)) },
            onClick = { selectedIndex = 0 },
        )
    }
    tabItem(weight = null) {
        Icon(
            modifier = Modifier
                .size(36.dp)
                .clickable { selectedIndex = 1 },
            source = resourceImageSource(R.drawable.ic_sb_36),
            contentDescription = null,
        )
    }
    tabItem {
        val isSelected = selectedIndex == 2
        TabBarItem(
            isSelected = isSelected,
            icon = { TabIcon(2, isSelected) },
            labelContent = { Text(getTitle(2)) },
            onClick = { selectedIndex = 2 },
        )
    }
}
```

## Стиль TabBar

В большинстве случаев можно использовать готовые сгенерированные стили, а при необходимости создать собственный стиль через соответствующий builder. Подробнее о том, как работают `Style`, `StyleBuilder` и stateful-параметры стиля, см. в разделе [Стилизация компонентов](../theme/Styles.md).

### Параметры стиля `TabBarHasLabelClear`

| Параметр | Тип | Возможные значения |
| --- | --- | --- |
| `size` | `TabBarHasLabelClearSize` | `M`, `L` |
| `hasShadow` | `Boolean` | `true`, `false` |
| `rounded` | `Boolean` | `true`, `false` |
| `divider` | `Boolean` | `true`, `false` |
| `view` | `TabBarHasLabelClearView` | `Default`, `Secondary`, `Accent` |

Пример выбора готового стиля:
```kotlin
val style = TabBarStyles.HasLabelClear.style(
    size = TabBarHasLabelClearSize.M,
    hasShadow = false,
    rounded = false,
    divider = false,
    view = TabBarHasLabelClearView.Default
)

// или через dot notation
val style = TabBarHasLabelClear.M.Default.style()
```


### Параметры стиля `TabBarHasLabelSolid`

| Параметр | Тип | Возможные значения |
| --- | --- | --- |
| `size` | `TabBarHasLabelSolidSize` | `M`, `L` |
| `hasShadow` | `Boolean` | `true`, `false` |
| `rounded` | `Boolean` | `true`, `false` |
| `divider` | `Boolean` | `true`, `false` |
| `view` | `TabBarHasLabelSolidView` | `Default`, `Secondary`, `Accent` |

Пример выбора готового стиля:
```kotlin
val style = TabBarStyles.HasLabelSolid.style(
    size = TabBarHasLabelSolidSize.M,
    hasShadow = false,
    rounded = false,
    divider = false,
    view = TabBarHasLabelSolidView.Default
)

// или через dot notation
val style = TabBarHasLabelSolid.M.Default.style()
```


### Параметры стиля `TabBarIslandHasLabelClear`

| Параметр | Тип | Возможные значения |
| --- | --- | --- |
| `size` | `TabBarIslandHasLabelClearSize` | `M`, `L` |
| `hasShadow` | `Boolean` | `true`, `false` |
| `view` | `TabBarIslandHasLabelClearView` | `Default`, `Secondary`, `Accent` |

Пример выбора готового стиля:
```kotlin
val style = TabBarStyles.IslandHasLabelClear.style(
    size = TabBarIslandHasLabelClearSize.M,
    hasShadow = false,
    view = TabBarIslandHasLabelClearView.Default
)

// или через dot notation
val style = TabBarIslandHasLabelClear.M.Default.style()
```


### Параметры стиля `TabBarIslandHasLabelSolid`

| Параметр | Тип | Возможные значения |
| --- | --- | --- |
| `size` | `TabBarIslandHasLabelSolidSize` | `M`, `L` |
| `hasShadow` | `Boolean` | `true`, `false` |
| `view` | `TabBarIslandHasLabelSolidView` | `Default`, `Secondary`, `Accent` |

Пример выбора готового стиля:
```kotlin
val style = TabBarStyles.IslandHasLabelSolid.style(
    size = TabBarIslandHasLabelSolidSize.M,
    hasShadow = false,
    view = TabBarIslandHasLabelSolidView.Default
)

// или через dot notation
val style = TabBarIslandHasLabelSolid.M.Default.style()
```


### Параметры стиля `TabBarClear`

| Параметр | Тип | Возможные значения |
| --- | --- | --- |
| `size` | `TabBarClearSize` | `M`, `L` |
| `hasShadow` | `Boolean` | `true`, `false` |
| `rounded` | `Boolean` | `true`, `false` |
| `divider` | `Boolean` | `true`, `false` |
| `view` | `TabBarClearView` | `Default`, `Secondary`, `Accent` |

Пример выбора готового стиля:
```kotlin
val style = TabBarStyles.Clear.style(
    size = TabBarClearSize.M,
    hasShadow = false,
    rounded = false,
    divider = false,
    view = TabBarClearView.Default
)

// или через dot notation
val style = TabBarClear.M.Default.style()
```


### Параметры стиля `TabBarSolid`

| Параметр | Тип | Возможные значения |
| --- | --- | --- |
| `size` | `TabBarSolidSize` | `M`, `L` |
| `hasShadow` | `Boolean` | `true`, `false` |
| `rounded` | `Boolean` | `true`, `false` |
| `divider` | `Boolean` | `true`, `false` |
| `view` | `TabBarSolidView` | `Default`, `Secondary`, `Accent` |

Пример выбора готового стиля:
```kotlin
val style = TabBarStyles.Solid.style(
    size = TabBarSolidSize.M,
    hasShadow = false,
    rounded = false,
    divider = false,
    view = TabBarSolidView.Default
)

// или через dot notation
val style = TabBarSolid.M.Default.style()
```


### Параметры стиля `TabBarIslandClear`

| Параметр | Тип | Возможные значения |
| --- | --- | --- |
| `size` | `TabBarIslandClearSize` | `M`, `L` |
| `hasShadow` | `Boolean` | `true`, `false` |
| `view` | `TabBarIslandClearView` | `Default`, `Secondary`, `Accent` |

Пример выбора готового стиля:
```kotlin
val style = TabBarStyles.IslandClear.style(
    size = TabBarIslandClearSize.M,
    hasShadow = false,
    view = TabBarIslandClearView.Default
)

// или через dot notation
val style = TabBarIslandClear.M.Default.style()
```


### Параметры стиля `TabBarIslandSolid`

| Параметр | Тип | Возможные значения |
| --- | --- | --- |
| `size` | `TabBarIslandSolidSize` | `M`, `L` |
| `hasShadow` | `Boolean` | `true`, `false` |
| `view` | `TabBarIslandSolidView` | `Default`, `Secondary`, `Accent` |

Пример выбора готового стиля:
```kotlin
val style = TabBarStyles.IslandSolid.style(
    size = TabBarIslandSolidSize.M,
    hasShadow = false,
    view = TabBarIslandSolidView.Default
)

// или через dot notation
val style = TabBarIslandSolid.M.Default.style()
```


### Создание стиля с помощью builder()

```kotlin
TabBarStyle.builder()
    .tabBarItemStyle(
        placeholder(
            TabBarItemStyle.builder().style(),
            "/** Стиль компонента */",
        ),
    )
    .topShape(CircleShape)
    .shadow(/** Токен тени */)
    .colors {
        backgroundColor(/** Цвет фона */)
    }
    .dimensions {
        paddingStart(8.dp)
        paddingEnd(8.dp)
        contentPaddingStart(2.0.dp)
        contentPaddingEnd(2.0.dp)
        contentPaddingTop(2.0.dp)
        contentPaddingBottom(2.0.dp)
        itemSpacing(2.0.dp)
    }
    .style()
```

## TabBarItem

Элемент панели навигации `TabBar`. При использовании внутри `TabBar` компонент стилизуется автоматически. Если нужен отдельный стиль для элемента, используйте `TabBarItemStyle.builder()`. Общие принципы работы `Style` и `StyleBuilder` описаны в разделе [Стилизация компонентов](../theme/Styles.md).

### Создание стиля с помощью builder()

```kotlin
TabBarItemStyle.builder()
    .shape(/** Токе формы(скругления) */)
    .labelStyle(/** Токен типографики */)
    .labelPlacement(TabBarLabelPlacement.Bottom)
    .colors {
        backgroundColor(
            /** Токен цвета */.asInteractive(
                setOf(InteractiveState.Selected)
                    to /** Цвет в состоянии selected */,
            ),
        )
        labelColor(
            /** Токен цвета */.asInteractive(
                setOf(InteractiveState.Selected)
                    to /** Цвет в состоянии selected */,
            ),
        )
        iconColor(
            /** Токен цвета */.asInteractive(
                setOf(InteractiveState.Selected)
                    to /** Цвет в состоянии selected */,
            ),
        )
    }
    .dimensions {
        paddingTop(10.dp)
        paddingBottom(10.dp)
        iconSize(32.dp)
        minHeight(48.dp)
        labelPadding(2.dp)
    }
    .counterStyle(/** Стиль компонента */)
    .badgeStyle(/** Стиль компонента */)
    .indicatorStyle(
        placeholder(
            IndicatorStyle.builder().style(),
            "/** Стиль компонента */",
        ),
    )
    .style()
```

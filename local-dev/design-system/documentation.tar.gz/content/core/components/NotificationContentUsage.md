---
title: NotificationContent
---
Компонент, предназначенный для использования в [Notification](NotificationUsage.md) в качестве контента.

В качестве кнопок ожидает [Button](BasicButtonUsage.md). Кнопки добавляются с помощью функции button() из NotificationContentButtonsScope.

```kotlin
NotificationContent(
    modifier = Modifier.fillMaxWidth(),
    title = "Title",
    text = "Notification Text",
    buttons = {
        button { Button(label = "Ok", onClick = {}) }
        button { Button(label = "Cancel", onClick = {}) }
    },
)
```

<!-- @screenshot: com.sdds.compose.uikit.fixtures.samples.notificationcontent.NotificationContent_Simple -->

## Стиль NotificationContent

В большинстве случаев можно использовать готовые сгенерированные стили, а при необходимости создать собственный стиль через соответствующий builder. Подробнее о том, как работают `Style`, `StyleBuilder` и stateful-параметры стиля, см. в разделе [Стилизация компонентов](../theme/Styles.md).

### Параметры стиля

| Параметр | Тип | Возможные значения |
| --- | --- | --- |
| `buttonLayout` | `NotificationContentButtonLayout` | `Stretch`, `Normal` |
| `iconPlacement` | `NotificationContentIconPlacement` | `Top`, `Start` |
| `view` | `NotificationContentView` | `Default`, `Positive`, `Negative`, `Warning`, `Info` |

Пример выбора готового стиля:
```kotlin
val style = NotificationContentStyles.style(
    buttonLayout = NotificationContentButtonLayout.Stretch,
    iconPlacement = NotificationContentIconPlacement.Top,
    view = NotificationContentView.Default
)

// или через dot notation
val style = NotificationContent.ButtonStretch.Default.style()
```


### Создание стиля с помощью builder()

```kotlin
NotificationContentStyle.builder()
    .buttonLayout(NotificationContentButtonLayout.Stretch)
    .buttonGroupStyle(/** Стиль компонента */)
    .icon(resourceImageSource(com.sdds.icons.R.drawable.ic_info_circle_outline_24))
    .titleStyle(/** Токен типографики */)
    .textStyle(/** Токен типографики */)
    .dimensions {
        iconSize(24.0.dp)
        textPadding(4.0.dp)
        contentStartPadding(4.0.dp)
        contentTopPadding(2.0.dp)
        textBoxBottomPadding(6.0.dp)
        buttonGroupTopPadding(6.0.dp)
    }
    .style()
```

## NotificationContentButtonLayout

Режим размещения кнопок. Возможные значения: Stretch (Кнопки занимают всю ширину компонента), Normal (Кнопки имеют ширину по своему контенту)

## NotificationContentIconPlacement

Расположение иконки. Возможные значения: Start, Top, None
---
title: List
---

Компонент List используется для отображения информации списком.
В качестве контента принимает либо [ListItem](#listitem) либо произвольный контент.

```kotlin
com.sdds.compose.uikit.List {
    items(5) {
        val interactionSource = remember { MutableInteractionSource() }
        val isFocused = interactionSource.collectIsFocusedAsState()
        ListItem(
            modifier = Modifier
                .focusable(interactionSource = interactionSource)
                .focusSelector(
                    settings = LocalFocusSelectorSettings.current,
                ) { isFocused.value },
            text = "List item title",
            label = "List item label",
            disclosureEnabled = true,
            interactionSource = interactionSource,
        )
    }
}
```

<!-- @screenshot: com.sdds.compose.uikit.fixtures.samples.list.List_Simple -->

## Стиль List

В большинстве случаев можно использовать готовые сгенерированные стили, а при необходимости создать собственный стиль через соответствующий builder. Подробнее о том, как работают `Style`, `StyleBuilder` и stateful-параметры стиля, см. в разделе [Стилизация компонентов](../theme/Styles.md).

### Параметры стиля `ListNormal`

| Параметр | Тип | Возможные значения |
| --- | --- | --- |
| `size` | `ListNormalSize` | `Xl`, `L`, `M`, `S`, `Xs` |

Пример выбора готового стиля:
```kotlin
val style = ListStyles.Normal.style(
    size = ListNormalSize.Xl
)

// или через dot notation
val style = ListNormal.Xl.style()
```


### Параметры стиля `ListTight`

| Параметр | Тип | Возможные значения |
| --- | --- | --- |
| `size` | `ListTightSize` | `Xl`, `L`, `M`, `S`, `Xs` |

Пример выбора готового стиля:
```kotlin
val style = ListStyles.Tight.style(
    size = ListTightSize.Xl
)

// или через dot notation
val style = ListTight.Xl.style()
```


### Параметры стиля `DropdownMenuListNormal`

| Параметр | Тип | Возможные значения |
| --- | --- | --- |
| `size` | `DropdownMenuListNormalSize` | `Xl`, `L`, `M`, `S`, `Xs` |

Пример выбора готового стиля:
```kotlin
val style = ListStyles.DropdownMenuListNormal.style(
    size = DropdownMenuListNormalSize.Xl
)

// или через dot notation
val style = DropdownMenuListNormal.Xl.style()
```


### Параметры стиля `DropdownMenuListTight`

| Параметр | Тип | Возможные значения |
| --- | --- | --- |
| `size` | `DropdownMenuListTightSize` | `Xl`, `L`, `M`, `S`, `Xs` |

Пример выбора готового стиля:
```kotlin
val style = ListStyles.DropdownMenuListTight.style(
    size = DropdownMenuListTightSize.Xl
)

// или через dot notation
val style = DropdownMenuListTight.Xl.style()
```


### Создание стиля с помощью builder()

```kotlin
ListStyle.builder()
    .listItemStyle(
        /** Стиль компонента */,
    )
    .style()
```

## ListItem

Элемент списка [List](#list). При использовании внутри `List` компонент стилизуется автоматически. Если нужен отдельный стиль для элемента, используйте `ListItemStyle.builder()`. Общие принципы работы `Style` и `StyleBuilder` описаны в разделе [Стилизация компонентов](../theme/Styles.md).

### Создание стиля с помощью builder()

```kotlin
ListItemStyle.builder()
    .shape(/** Токен формы (скругления) */)
    .titleStyle(/** Токен типографики */)
    .disclosureIcon(resourceImageSource(com.sdds.icons.R.drawable.ic_disclosure_right_outline_24))
    .colors {
        titleColor(Color.Black)
        disclosureIconColor(Color.Gray)
        backgroundColor(Color.Transparent)
    }
    .dimensions {
        contentPaddingEnd(4.dp)
        height(32.dp)
        paddingStart(8.dp)
        paddingEnd(8.dp)
        paddingTop(8.dp)
        paddingBottom(8.dp)
    }
    .style()
```

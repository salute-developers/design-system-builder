---
title: Switch
---

Компонент Switch может содержать лейбл и описание.

```kotlin
Switch(
    active = true,
    label = "Label",
    description = "Description",
    enabled = true,
)
```

<!-- @screenshot: com.sdds.compose.uikit.fixtures.samples.switcher.Switch_Simple -->

## Стиль Switch

В большинстве случаев можно использовать готовые сгенерированные стили, а при необходимости создать собственный стиль через соответствующий builder. Подробнее о том, как работают `Style`, `StyleBuilder` и stateful-параметры стиля, см. в разделе [Стилизация компонентов](../theme/Styles.md).

### Параметры стиля

| Параметр | Тип | Возможные значения |
| --- | --- | --- |
| `size` | `SwitchSize` | `L`, `M`, `S` |
| `toggleSize` | `SwitchToggleSize` | `L`, `S` |

Пример выбора готового стиля:
```kotlin
val style = SwitchStyles.style(
    size = SwitchSize.L,
    toggleSize = SwitchToggleSize.L
)

// или через dot notation
val style = Switch.L.style()
```


### Создание стиля с помощью builder()

```kotlin
SwitchStyle.builder()
    .toggleTrackShape(CircleShape)
    .toggleThumbShape(CircleShape)
    .colorValues {
        labelColor(/** Токен цвета */.asInteractive())
        descriptionColor(/** Токен цвета */.asInteractive())
        toggleTrackColor(
            /** Токен цвета */.asInteractive(
                setOf(SwitchStates.Checked)
                    to /** Цвет в состоянии checked */,
            ),
        )
        toggleTrackBorderColor(/** Токен цвета */.asInteractive())
        toggleThumbColor(/** Токен цвета */.asInteractive())
    }
    .labelStyle(/** Токен типографики */)
    .descriptionStyle(/** Токен типографики */)
    .dimensionValues {
        toggleTrackWidth(44.0.dp)
        toggleTrackHeight(28.0.dp)
        toggleThumbWidth(24.0.dp)
        toggleThumbHeight(24.0.dp)
        textPadding(12.0.dp)
        descriptionPadding(4.0.dp)
    }
    .style()
```

## Label и Description

По умолчанию текст в label и description - многострочный, это можно изменить с помощью параметров
labelMaxLines и descriptionMaxLines соответственно, установив нужное значение.

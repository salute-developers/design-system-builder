---
title: TextField
---

```kotlin
var value by remember { mutableStateOf(TextFieldValue("")) }
TextField(
    value = value,
    captionText = "Надпись",
    labelText = "Заголовок",
    placeholderText = "Введите текст",
    onValueChange = { value = it },
    startContent = {
        Icon(
            painter = painterResource(id = com.sdds.icons.R.drawable.ic_shazam_24),
            contentDescription = "",
            tint = Color.Black,
        )
    },
    chipsContent = { repeat(3) { Chip(label = "Чип") } },
    focusSelectorSettings = FocusSelectorSettings.None,
)
```

<!-- @screenshot: com.sdds.compose.uikit.fixtures.samples.textfield.TextField_Simple -->

## Стиль TextField

В большинстве случаев можно использовать готовые сгенерированные стили, а при необходимости создать собственный стиль через соответствующий builder. Подробнее о том, как работают `Style`, `StyleBuilder` и stateful-параметры стиля, см. в разделе [Стилизация компонентов](../theme/Styles.md).

### Параметры стиля

| Параметр | Тип | Возможные значения |
| --- | --- | --- |
| `size` | `TextFieldDefaultSize` | `Xs`, `S`, `M`, `L`, `Xl` |
| `requiredPlacement` | `TextFieldDefaultRequiredPlacement` | `None`, `Start`, `End` |
| `labelPlacement` | `TextFieldDefaultLabelPlacement` | `None`, `Outer`, `Inner` |
| `view` | `TextFieldDefaultView` | `Default`, `Success`, `Warning`, `Error` |

Пример выбора готового стиля:
```kotlin
val style = TextFieldStyles.Default.style(
    size = TextFieldDefaultSize.Xs,
    requiredPlacement = TextFieldDefaultRequiredPlacement.None,
    labelPlacement = TextFieldDefaultLabelPlacement.None,
    view = TextFieldDefaultView.Default
)

// или через dot notation
val style = TextField.Xs.Default.style()
```


### Параметры стиля `TextFieldClear`

| Параметр | Тип | Возможные значения |
| --- | --- | --- |
| `size` | `TextFieldClearSize` | `Xs`, `S`, `M`, `L`, `Xl` |
| `requiredPlacement` | `TextFieldClearRequiredPlacement` | `None`, `Start`, `End` |
| `labelPlacement` | `TextFieldClearLabelPlacement` | `None`, `Outer`, `Inner` |
| `view` | `TextFieldClearView` | `Default`, `Success`, `Warning`, `Error` |

Пример выбора готового стиля:
```kotlin
val style = TextFieldStyles.Clear.style(
    size = TextFieldClearSize.Xs,
    requiredPlacement = TextFieldClearRequiredPlacement.None,
    labelPlacement = TextFieldClearLabelPlacement.None,
    view = TextFieldClearView.Default
)

// или через dot notation
val style = TextFieldClear.Xs.Default.style()
```


### Создание стиля с помощью builder()

```kotlin
TextFieldStyle.builder()
    .colors {
        captionColor(
            /** Токен цвета */.asInteractive(
                setOf(InteractiveState.Activated)
                    to /** Токен цвета в состоянии activated */,
            ),
        )
        backgroundColor(
            /** Токен цвета */.asInteractive(
                setOf(InteractiveState.Activated)
                    to /** Токен цвета в состоянии activated */,
            ),
        )
        optionalColor(/** Токен цвета */.asInteractive())
        valueColor(/** Токен цвета */.asInteractive())
        placeholderColor(
            /** Токен цвета */.asInteractive(
                setOf(InteractiveState.Activated)
                    to /** Токен цвета в состоянии activated */,
            ),
        )
        indicatorColor(/** Токен цвета */.asInteractive())
        startContentColor(/** Токен цвета */.asInteractive())
        endContentColor(
            /** Токен цвета */.asInteractive(
                setOf(InteractiveState.Pressed)
                    to /** Токен цвета в состоянии pressed */,
                setOf(InteractiveState.Hovered)
                    to /** Токен цвета в состоянии hovered */,
            ),
        )
        endContentColorReadOnly(
            /** Токен цвета */.multiplyAlpha(0.4f)
                .asInteractive(),
        )
        captionColorReadOnly(
            /** Токен цвета */.asInteractive(),
        )
        counterColor(/** Токен цвета */.asInteractive())
        backgroundColorReadOnly(
            /** Токен цвета */.multiplyAlpha(0.4f)
                .asInteractive(),
        )
        cursorColor(/** Токен цвета */.asInteractive())
        prefixColor(/** Токен цвета */.asInteractive())
        suffixColor(/** Токен цвета */.asInteractive())
    }
    .singleLine(true)
    .shape(
        /** Токен формы(скругления) */
            .adjustBy(all = 0.0.dp),
    )
    .dimensions {
        optionalPadding(4.0.dp)
        helperTextPadding(4.0.dp)
        chipsPadding(6.0.dp)
        boxPaddingStart(8.0.dp)
        boxPaddingEnd(8.0.dp)
        boxPaddingTop(8.0.dp)
        boxPaddingBottom(8.0.dp)
        boxMinHeight(32.0.dp)
        alignmentLineHeight(32.0.dp)
        startContentPadding(4.0.dp)
        endContentPadding(4.0.dp)
        startContentSize(16.0.dp)
        endContentSize(16.0.dp)
    }
    .captionStyle(/** Токен типографики */)
    .counterStyle(/** Токен типографики */)
    .captionPlacement(TextFieldHelperTextPlacement.Outer)
    .counterPlacement(TextFieldHelperTextPlacement.Outer)
    .valueStyle(/** Токен типографики */)
    .prefixStyle(/** Токен типографики */)
    .suffixStyle(/** Токен типографики */)
    .placeholderStyle(/** Токен типографики */)
    .chipGroupStyle(/** Стиль компонента */)
    .labelPlacement(TextFieldLabelPlacement.None)
    .style()
```

## TextField readOnly

При включении этого параметра компоннет сатновится доступным только для чтения,
изменение текстовых полей невозможно.

## TextField value

Параметр value в Textfield ожидает значение типа TextFieldValue, с помощью которого
возможно контролировать позицию курсора при вводе текста, а так же выделять диапазон
символов. Если текст для value не задан, будет отображен текст, который задан в placeholder,
в качестве hint.

## TextField иконки в поле ввода

С помощью пармаетров startContent и endContent можно установить иконку в начале
и/или в конце поля ввода.

## Расположение Label

Задается стилем компонента, а именно функцией билдера стиля - labelPlacement(),
в качестве параметра ожидается значение enum TextFieldLabelPlacement

```kotlin
TextFieldStyle.builder()
.labelPlacement(TextFieldLabelPlacement.Outer)
style()
```

## Расположение Indicator (RequireStart, RequireEnd)

Задается стилем компонента, а именно функцией билдера стиля - .indicatorAlignmentMode()
в качестве параметра ожидается значение enum TextFieldIndicatorAlignmentMode

```kotlin
TextFieldStyle.builder()
.indicatorAlignmentMode(TextFieldIndicatorAlignmentMode.Inside)
style()
```

## Тип текстового поля (обязательное или опциональное)

Задается стилем компонента, а именно функцией билдера стиля - .fieldType()
в качестве параметра ожидается значение enum TextFieldType

```kotlin
TextFieldStyle.builder()
.fieldType(TextFieldType.RequiredStart)
style()
```

## Расположение Caption

Задается стилем компонента, а именно функцией билдера стиля - .captionPlacement()
в качестве параметра ожидается значение enum TextFieldHelperTextPlacement

```kotlin
TextFieldStyle.builder()
.captionPlacement(TextFieldHelperTextPlacement.Outer)
style()
```

---
title: FormItem
---

Компонент-оболочка с набором вариаций и элементами управления формой.

### Простой пример элемента формы

```kotlin
FormItem(
    content = { Text("Form Item Content") },
    title = { Text("Title") },
    titleCaption = { Text("TitleCaption") },
    caption = { Text("Caption") },
    counter = { Text("Counter") },
)
```

<!-- @screenshot: com.sdds.compose.uikit.fixtures.samples.formitem_FormItem_Simple -->

### Пример с hint и Tooltip

```kotlin
val hintTriggerInfo = remember { mutableStateOf(TriggerInfo()) }
var showTooltip by remember { mutableStateOf(false) }
FormItem(
    content = { Text("Form Item Content") },
    title = { Text("Title") },
    titleCaption = { Text("TitleCaption") },
    caption = { Text("Caption") },
    counter = { Text("Counter") },
    hasHint = true,
    onHintPressed = { showTooltip = true },
    hintTriggerInfo = hintTriggerInfo,
)

Tooltip(
    show = showTooltip,
    onDismissRequest = { showTooltip = false },
    triggerInfo = { hintTriggerInfo.value },
    text = AnnotatedString("Tooltip text"),
    alignment = PopoverAlignment.Center,
)
```

<!-- @screenshot: com.sdds.compose.uikit.fixtures.samples.formitem_FormItem_WithHint -->

## Стиль FormItem

В большинстве случаев можно использовать готовые сгенерированные стили, а при необходимости создать собственный стиль через соответствующий builder. Подробнее о том, как работают `Style`, `StyleBuilder` и stateful-параметры стиля, см. в разделе [Стилизация компонентов](../theme/Styles.md).

### Параметры стиля

| Параметр | Тип | Возможные значения |
| --- | --- | --- |
| `size` | `FormItemSize` | `Xs`, `S`, `M`, `L` |
| `requiredPlacement` | `FormItemRequiredPlacement` | `None`, `Start`, `End` |
| `titlePlacement` | `FormItemTitlePlacement` | `None`, `Top`, `Start` |
| `view` | `FormItemView` | `Default`, `Positive`, `Negative`, `Warning` |

Пример выбора готового стиля:
```kotlin
val style = FormItemStyles.style(
    size = FormItemSize.Xs,
    requiredPlacement = FormItemRequiredPlacement.None,
    titlePlacement = FormItemTitlePlacement.None,
    view = FormItemView.Default
)

// или через dot notation
val style = FormItem.Xs.Default.style()
```


### Создание стиля с помощью builder()

```kotlin
FormItemStyle.builder()
    .hintIcon(resourceImageSource(com.sdds.icons.R.drawable.ic_info_circle_outline_16))
    .captionStyle(/** Токен типографики */)
    .titleCaptionStyle(/** Токен типографики */)
    .counterStyle(/** Токен типографики */)
    .titleStyle(/** Токен типографики */)
    .optionalStyle(/** Токен типографики */)
    .titlePlacement(FormTitlePlacement.Top)
    .topTextAlignment(FormTextAlignment.Edge)
    .bottomTextAlignment(FormTextAlignment.Edge)
    .indicatorAlignment(FormIndicatorAlignment.TopStart)
    .indicatorAlignmentMode(IndicatorMode.Inner)
    .formItemType(FormType.Required)
    .colors {
        hintColor(/** Токен цвета */.asInteractive())
        optionalColor(/** Токен цвета */.asInteractive())
        titleCaptionColor(/** Токен цвета */.asInteractive())
        titleColor(/** Токен цвета */.asInteractive())
        counterColor(/** Токен цвета */.asInteractive())
        captionColor(/** Токен цвета */.asInteractive())
    }
    .dimensions {
        titleBlockWidth(140.0.dp)
        indicatorOffsetX(4.0.dp)
        indicatorOffsetX(0.0.dp)
        titleBlockSpacing(4.0.dp)
        titleBlockPadding(8.0.dp)
        titleCaptionPadding(4.0.dp)
        captionPadding(5.0.dp)
        counterPadding(5.0.dp)
        hintHeight(14.0.dp)
        hintWidth(16.0.dp)
    }
    .style()
```

## FormVertical

Компонент предназначенный для вертикальной группировки нескольких FormItem

### Пример с вертикальной группировкой элементов

```kotlin
FormVertical {
    repeat(3) {
        FormItem(
            content = { Text("Form Item Content $it") },
            title = { Text("Title $it") },
            titleCaption = { Text("TitleCaption $it") },
            caption = { Text("Caption $it") },
            counter = { Text("Counter $it") },
        )
    }
}
```

## FormHorizontal

### Пример с горизонтальной группировкой элементов

```kotlin
FormHorizontal {
    repeat(3) {
        FormItem(
            content = { Text("Form Item Content $it") },
            title = { Text("Title $it") },
            titleCaption = { Text("TitleCaption $it") },
            caption = { Text("Caption $it") },
            counter = { Text("Counter $it") },
        )
    }
}
```

## FormTitlePlacement

Расположение Title в элементе формы FormItem. Возможные значения: `Start`, `Top`, `None`.

## FormTextAlignment

Режим выранивания вспомогательного текста FormItem (title, titleCaption, caption, counter).
Возможные значения: `Center` (тексты центрированы по горизонтали относительно формы,
расположены друг под другом), `Edge` (тексты расположены в начале и в конце компонента).

## FormIndicatorAlignment

Выравнивание индикатора формы.
Возможные значения: `TopStart`, `TopCenter`, `TopEnd`, `CenterStart`, `Center`, `CenterEnd`,
`BottomStart`, `BottomCenter`, `BottomEnd`.

## FormType

Тип элемента формы.
Возможные значения: `Required` (показывается индикатор), `Optional` (показывается optional-текст).

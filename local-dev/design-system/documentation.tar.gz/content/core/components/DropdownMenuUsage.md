---
title: DropdownMenu
---

Раскрывающееся меню — отображает список пунктов поверх контента. 

В качестве контента ожидает List c элементами ListItem (стилизуются автоматически при использовании предопределенных стилей) либо произвольный контент.


```kotlin
val showDropdownMenu = remember { mutableStateOf(false) }
val triggerInfo = remember { mutableStateOf(TriggerInfo()) }
Button(
    modifier = Modifier.popoverTrigger(triggerInfo),
    label = "Show dropdown menu",
    onClick = { showDropdownMenu.value = true },
)
DropdownMenu(
    opened = showDropdownMenu.value,
    onDismissRequest = {
        showDropdownMenu.value = false
    },
    triggerInfo = triggerInfo.value,
    placement = PopoverPlacement.Bottom,
    placementMode = PopoverPlacementMode.Loose,
    alignment = PopoverAlignment.Center,
) {
    List(
        modifier = Modifier
            .width(200.dp)
            .height(300.dp),
    ) {
        item {
            ListItem(
                text = "Item title 2",
                disclosureEnabled = true,
            )
        }
        item {
            Divider()
        }
        item {
            ListItem(
                text = "Item title 2",
                disclosureEnabled = true,
            )
        }
    }
}
```

<!-- @screenshot: com.sdds.compose.uikit.fixtures.samples.dropdownmenu.DropdownMenu_Simple -->

## Модальный DropdownMenu

`DropdownMenu` поддерживает модальный режим отображения. В таком режиме вся область экрана "блокируется" и затемняется. 
Если trigger должен остаться незатемнённым, форму выреза можно передать через `Modifier.popoverTrigger(triggerInfo, shape = ...)`.

```kotlin
val showDropdownMenu = remember { mutableStateOf(false) }
val triggerInfo = remember { mutableStateOf(TriggerInfo()) }
Button(
    style = buttonStyle,
    modifier = Modifier.popoverTrigger(
        triggerInfo = triggerInfo,
        shape = buttonStyle.shape,
        cutoutPaddings = PaddingValues(3.dp),
    ),
    label = "Show dropdown menu",
    onClick = { showDropdownMenu.value = true },
)
ModalDropdownMenu(
    opened = showDropdownMenu.value,
    onDismissRequest = {
        showDropdownMenu.value = false
    },
    triggerInfo = triggerInfo.value,
    placement = PopoverPlacement.Bottom,
    placementMode = PopoverPlacementMode.Loose,
    alignment = PopoverAlignment.Center,
) {
    List(
        modifier = Modifier
            .width(200.dp)
            .height(300.dp),
    ) {
        item {
            ListItem(
                text = "Item title 2",
                disclosureEnabled = true,
            )
        }
        item {
            Divider()
        }
        item {
            ListItem(
                text = "Item title 2",
                disclosureEnabled = true,
            )
        }
    }
}
```

## Стиль DropdownMenu

В большинстве случаев можно использовать готовые сгенерированные стили, а при необходимости создать собственный стиль через соответствующий builder. Подробнее о том, как работают `Style`, `StyleBuilder` и stateful-параметры стиля, см. в разделе [Стилизация компонентов](../theme/Styles.md).

### Параметры стиля `DropdownMenuTight`

| Параметр | Тип | Возможные значения |
| --- | --- | --- |
| `size` | `DropdownMenuTightSize` | `Xl`, `L`, `M`, `S`, `Xs` |

Пример выбора готового стиля:
```kotlin
val style = DropdownMenuStyles.Tight.style(
    size = DropdownMenuTightSize.Xl
)

// или через dot notation
val style = DropdownMenuTight.Xl.style()
```


### Параметры стиля `DropdownMenuNormal`

| Параметр | Тип | Возможные значения |
| --- | --- | --- |
| `size` | `DropdownMenuNormalSize` | `Xl`, `L`, `M`, `S`, `Xs` |

Пример выбора готового стиля:
```kotlin
val style = DropdownMenuStyles.Normal.style(
    size = DropdownMenuNormalSize.Xl
)

// или через dot notation
val style = DropdownMenuNormal.Xl.style()
```


### Создание стиля с помощью builder()

```kotlin
DropdownMenuStyle.builder()
    .shadow(/** Токен тени */)
    .shape(/** Токен формы (скругления) */)
    .listStyle(/** Стиль компонента */)
    .dividerStyle(/** Стиль разделителя */)
    .overlayStyle(/** Стиль overlay */)
    .dimensions {
        width(200.dp)
        strokeWidth(1.dp)
        offset(8.0.dp)
    }
    .colors {
        backgroundColor(SolidColor(Color.LightGray))
        strokeColor(SolidColor(Color.Black))
    }
    .style()
```

## TriggerInfo

см. [TriggerInfo](PopoverUsage.md#triggerinfo)

## PopoverPlacement

см. [PopoverPlacement](PopoverUsage.md#popoverplacement)

## PopoverAlignment

см. [PopoverAlignment](PopoverUsage.md#popoveralignment)

## PopoverPlacementMode

см. [PopoverPlacementMode](PopoverUsage.md#popoverplacementmode)

## PopoverPositionStrategy

см. [PopoverPositionStrategy](PopoverUsage.md#popoverpositionstrategy)

`PopoverPositionStrategy.KeepInitial` удобно использовать, если содержимое DropdownMenu меняется после открытия,
например при переходе с короткого списка на длинный, но позиция меню должна остаться исходной.

```kotlin
DropdownMenu(
    opened = opened,
    triggerInfo = triggerInfo.value,
    positionStrategy = PopoverPositionStrategy.KeepInitial,
)
```

## SafeAreaPadding

см. [SafeAreaPadding](PopoverUsage.md#safeareapadding)

`safeAreaPadding` задает дополнительные отступы от краев доступной области экрана, внутри которой располагается DropdownMenu.

```kotlin
DropdownMenu(
    opened = opened,
    triggerInfo = triggerInfo.value,
    safeAreaPadding = PaddingValues(16.dp),
)
```

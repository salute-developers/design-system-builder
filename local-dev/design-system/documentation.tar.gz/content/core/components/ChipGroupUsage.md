---
title: ChipGroup
---

ChipGroup контейнер для Chip.

```kotlin
val items: List<String> = List(3) { "label" }
ChipGroup {
    items.forEach {
        var isSelected by remember { mutableStateOf(false) }
        Chip(
            isSelected = isSelected,
            onSelectedChange = { value -> isSelected = value },
            label = it,
            endContent = {
                Icon(
                    painter = painterResource(id = R.drawable.ic_close_24),
                    contentDescription = null,
                )
            },
            enabled = true,
        )
    }
}
```

<!-- @screenshot: com.sdds.compose.uikit.fixtures.samples.chip.group.ChipGroup_Simple -->

## Стиль ChipGroup

В большинстве случаев можно использовать готовые сгенерированные стили, а при необходимости создать собственный стиль через соответствующий builder. Подробнее о том, как работают `Style`, `StyleBuilder` и stateful-параметры стиля, см. в разделе [Стилизация компонентов](../theme/Styles.md).

### Параметры стиля `ChipGroupDense`

| Параметр | Тип | Возможные значения |
| --- | --- | --- |
| `size` | `ChipGroupDenseSize` | `L`, `M`, `S`, `Xs` |
| `shape` | `ChipGroupDenseShape` | `Default`, `Pilled` |
| `view` | `ChipGroupDenseView` | `Default`, `Accent`, `Negative`, `Positive`, `Secondary`, `Warning` |

Пример выбора готового стиля:
```kotlin
val style = ChipGroupStyles.Dense.style(
    size = ChipGroupDenseSize.L,
    shape = ChipGroupDenseShape.Default,
    view = ChipGroupDenseView.Default
)

// или через dot notation
val style = ChipGroupDense.L.Default.style()
```


### Параметры стиля `ChipGroupWide`

| Параметр | Тип | Возможные значения |
| --- | --- | --- |
| `size` | `ChipGroupWideSize` | `L`, `M`, `S`, `Xs` |
| `shape` | `ChipGroupWideShape` | `Default`, `Pilled` |
| `view` | `ChipGroupWideView` | `Default`, `Accent`, `Negative`, `Positive`, `Secondary`, `Warning` |

Пример выбора готового стиля:
```kotlin
val style = ChipGroupStyles.Wide.style(
    size = ChipGroupWideSize.L,
    shape = ChipGroupWideShape.Default,
    view = ChipGroupWideView.Default
)

// или через dot notation
val style = ChipGroupWide.L.Default.style()
```


### Параметры стиля `EmbeddedChipGroupDense`

| Параметр | Тип | Возможные значения |
| --- | --- | --- |
| `size` | `EmbeddedChipGroupDenseSize` | `Xl`, `L`, `M`, `S`, `Xs` |
| `view` | `EmbeddedChipGroupDenseView` | `Default`, `Accent`, `Negative`, `Positive`, `Secondary`, `Warning` |

Пример выбора готового стиля:
```kotlin
val style = ChipGroupStyles.EmbeddedChipGroupDense.style(
    size = EmbeddedChipGroupDenseSize.Xl,
    view = EmbeddedChipGroupDenseView.Default
)

// или через dot notation
val style = EmbeddedChipGroupDense.Xl.Default.style()
```


### Параметры стиля `EmbeddedChipGroupWide`

| Параметр | Тип | Возможные значения |
| --- | --- | --- |
| `size` | `EmbeddedChipGroupWideSize` | `Xl`, `L`, `M`, `S`, `Xs` |
| `view` | `EmbeddedChipGroupWideView` | `Default`, `Accent`, `Negative`, `Positive`, `Secondary`, `Warning` |

Пример выбора готового стиля:
```kotlin
val style = ChipGroupStyles.EmbeddedChipGroupWide.style(
    size = EmbeddedChipGroupWideSize.Xl,
    view = EmbeddedChipGroupWideView.Default
)

// или через dot notation
val style = EmbeddedChipGroupWide.Xl.Default.style()
```


### Параметры стиля `AiAnswerChipGroup`

| Параметр | Тип | Возможные значения |
| --- | --- | --- |
| `size` | `AiAnswerChipGroupSize` | `L`, `M`, `S`, `Xs` |

Пример выбора готового стиля:
```kotlin
val style = ChipGroupStyles.AiAnswerChipGroup.style(
    size = AiAnswerChipGroupSize.L
)

// или через dot notation
val style = AiAnswerChipGroup.L.style()
```


### Создание стиля с помощью builder()

```kotlin
ChipGroupStyle.builder()
    .dimensions {
        gap(2.0.dp)
        lineSpacing(2.0.dp)
    }
    .chipStyle(/** Стиль компонента */)
    .style()
```

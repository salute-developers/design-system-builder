---
title: CircularProgressBar
---

```kotlin
CircularProgressBar(
    progress = 0.5f,
    trackEnabled = true,
)
```

<!-- @screenshot: com.sdds.compose.uikit.fixtures.samples.progress.CircularProgress_Simple -->

## Стиль CircularProgressBar

В большинстве случаев можно использовать готовые сгенерированные стили, а при необходимости создать собственный стиль через соответствующий builder. Подробнее о том, как работают `Style`, `StyleBuilder` и stateful-параметры стиля, см. в разделе [Стилизация компонентов](../theme/Styles.md).

### Параметры стиля

| Параметр | Тип | Возможные значения |
| --- | --- | --- |
| `size` | `CircularProgressBarSize` | `Xxl`, `Xl`, `L`, `M`, `S`, `Xs`, `Xxs` |
| `view` | `CircularProgressBarView` | `Default`, `Secondary`, `Accent`, `Gradient`, `Info`, `Negative`, `Positive`, `Warning` |

Пример выбора готового стиля:
```kotlin
val style = CircularProgressBarStyles.style(
    size = CircularProgressBarSize.Xxl,
    view = CircularProgressBarView.Default
)

// или через dot notation
val style = CircularProgressBar.Xxl.Default.style()
```


### Создание стиля с помощью builder()

```kotlin
CircularProgressBarStyle.builder()
    .colors {
        indicatorColor(
            SolidColor(/** Токен цвета */).asStatefulValue(),
        )
        trackColor(
            SolidColor(/** Токен цвета */).asStatefulValue(),
        )
        valueColor(
            SolidColor(/** Токен цвета */).asStatefulValue(),
        )
    }
    .valueStyle(/** Токен типографики */)
    .dimensions {
        width(128.0.dp)
        height(128.0.dp)
        trackThickness(4.0.dp)
        progressThickness(4.0.dp)
    }
    .style()
```

## CircularProgressBar value и valueSuffix

value - параметр для отображения прогресса (как правило в числовом формате)
valueSuffix - параметр для отображения единиц измерения прогресса

```kotlin
val progress = 0.5f
CircularProgressBar(
    progress = progress,
    style = LocalCircularProgressBarStyle.current,
    value = "${(progress * 100).roundToInt()}",
    valueSuffix = "%",
)
```

<!-- @screenshot: com.sdds.compose.uikit.fixtures.samples.progress.CircularProgressSuffix_Simple -->

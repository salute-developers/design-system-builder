---
title: ComboBox
---

`ComboBox` — компонент с возможностью ввода текста и выбора одного или нескольких вариантов в выпадающем списке.
В качестве триггера ожидает `ComboBoxTextField`. В качестве контента - список из `SelectItem`.

## Примеры использования

`ComboBox` нужно использовать с `ComboBoxTextField`.
Он представляет собой обертку над `TextField`, принимает его стиль и предоставляет часть его api,
а также содержит дополнительный функционал, необходимый для `ComboBox`.

### Единичный выбор

Пример с `ComboBoxTextField`, фильтрацией списка и единичным выбором:

```kotlin
val comboBoxList = comboBoxSampleList()
val state = remember { SelectState(initialState = true) }
val checkedStateManager = rememberSelectSingleDataStateManager(comboBoxList)
var value by remember { mutableStateOf("") }
val filteredList = remember(value, state.isOpened) {
    comboBoxList.filteredBy(value, state.isOpened)
}

ComboBox(
    state = state,
    trigger = {
        ComboBoxTextField(
            modifier = Modifier.width(260.dp),
            value = value,
            onValueChange = { value = it },
            placeholderText = if (value.isEmpty()) "Сотрудник" else null,
            captionText = "Введите или выберите имя",
            iconOpened = R.drawable.ic_chevron_up_24,
            iconClosed = R.drawable.ic_chevron_down_24,
            startContent = {
                Icon(
                    painterResource(R.drawable.ic_search_24),
                    "",
                )
            },
        )
    },
    showEmptyState = filteredList.isEmpty(),
    emptyState = {
        EmptyState(
            iconRes = R.drawable.ic_plasma_36,
            description = "Empty State",
        )
    },
    listContent = {
        items(filteredList.size) {
            val item = filteredList[it]
            SelectItem(
                modifier = Modifier.fillMaxWidth(),
                checked = checkedStateManager.isSelected(item),
                onClick = {
                    checkedStateManager.onItemPressed(item)
                    value = item
                    state.close()
                },
            ) {
                Cell(
                    title = AnnotatedString(item),
                    disclosureIconRes = null,
                )
            }
        }
    },
)
```

### Множественный выбор

Пример с `ComboBoxTextField`, фильтрацией списка, множественным выбором и отображением выбранных значений в `chipsContent`:

```kotlin
val comboBoxList = comboBoxSampleList()
val state = remember { SelectState(initialState = true) }
val checkedStateManager = rememberSelectMultipleDataStateManager(
    comboBoxList,
    { it == comboBoxList.first() },
)
var value by remember { mutableStateOf("") }
val filteredList = remember(value, state.isOpened) {
    comboBoxList.filteredBy(value, state.isOpened)
}

ComboBox(
    state = state,
    trigger = {
        ComboBoxTextField(
            modifier = Modifier.width(260.dp),
            value = value,
            onValueChange = { value = it },
            placeholderText = if (value.isEmpty()) "Сотрудник" else null,
            captionText = "Введите или выберите имя",
            iconOpened = R.drawable.ic_chevron_up_24,
            iconClosed = R.drawable.ic_chevron_down_24,
            chipsContent = comboBoxChipsContent(
                checkedStateManager.selectedItems,
                checkedStateManager::onItemPressed,
            ),
            startContent = {
                Icon(
                    painterResource(R.drawable.ic_search_24),
                    "",
                )
            },
        )
    },
    showEmptyState = filteredList.isEmpty(),
    emptyState = {
        EmptyState(
            iconRes = R.drawable.ic_plasma_36,
            description = "Empty State",
        )
    },
    listContent = {
        items(filteredList.size) {
            val item = filteredList[it]
            SelectItem(
                modifier = Modifier.fillMaxWidth(),
                checked = checkedStateManager.isSelected(item),
                onClick = {
                    checkedStateManager.onItemPressed(item)
                    value = ""
                },
            ) {
                Cell(
                    title = AnnotatedString(item),
                    disclosureIconRes = null,
                )
            }
        }
    },
)
```

<!-- @screenshot: com.sdds.compose.uikit.fixtures.samples.combobox.ComboBox_Multiple -->

### SelectItem

Элемент списка `ComboBox`. Может быть выбранным и ожидает в качестве контента [Cell](CellUsage.md).

```kotlin
SelectItem(
    modifier = Modifier.fillMaxWidth(),
    checked = checkedStateManager.isSelected(comboBoxList[it]),
    onClick = {
        checkedStateManager.onItemPressed(comboBoxList[it])
    },
) {
    Cell(
        title = AnnotatedString(comboBoxList[it]),
        disclosureIconRes = null,
    )
}
```

## Работа с компонентом

### SelectState

Для работы с компонентом необходимо создать экземпляр `SelectState` и передать его в `ComboBox`.
Он служит для управления состоянием компонента открыт / закрыт.

```kotlin
val state = remember { SelectState(initialState = true) }
ComboBox(
    state = state
)
```

Список открывается при активации текстового поля и при вводе текста.
При необходимости состоянием можно управлять вручную:

```kotlin
state.open() // открыть список
state.close() // закрыть список
state.toggle() // переключить текущее состояние
```

### SelectDataStateManager

Для управления состоянием элементов `выбран` / `не выбран` лучше использовать ViewModel, но если она не используется,
то существует интерфейс `SelectDataStateManager<T>` и две реализации для множественного и одиночного выбора.
Реализации доступны с помощью функций `rememberSelectMultipleDataStateManager()` и `rememberSelectSingleDataStateManager()`.

### Фильтрация списка

Если текстовое поле активно и значение пустое, обычно показывается весь список.
Если пользователь вводит текст, список можно отфильтровать по введенной строке.

```kotlin
val filteredList = if (state.isOpened && value.isEmpty()) {
    comboBoxList
} else {
    comboBoxList.filter { it.contains(value, ignoreCase = true) }
}
```

### Chips

Для множественного выбора выбранные элементы можно отображать внутри `ComboBoxTextField` через параметр `chipsContent`.
Чтобы удалить выбранный элемент, достаточно обработать клик по контенту чипа и обновить состояние выбора.

### EmptyState

Чтобы показать пустое состояние, необходимо передать контент пустого состояния в `emptyContent` и установить `showEmptyState`.
В скоупе dropdown существует преднастроенный компонент `EmptyState()`.
Рекомендуется использовать его в качестве контента для `emptyState`.

### Footer / header

Чтобы показывать индикатор загрузки или произвольный контент в нижней части списка, необходимо передать контент в `footer`.

Чтобы показывать произвольный контент в верхней части списка, необходимо передать контент в `header`.

## Стиль ComboBox

### Motion поля и меню

Обе формы `ComboBoxTextField` (`String` и `TextFieldValue`) принимают обязательный параметр
`motion: Motion<TextFieldMotionStyle>` в новых перегрузках. Поле и логика открытия используют
`motion.context.interactionSource`; отдельный `interactionSource` в этих перегрузках не передаётся.
Старые вызовы, включая Android drawable-адаптеры, сохраняются и создают Motion из прежнего
источника и `LocalTextFieldMotionStyle`. Замена источника или экземпляра `SelectState`
переподключает подписки и снимает прежнюю активацию. `TextFieldValue` сохраняет выделение и composition.

У `ComboBox` есть перегрузка с `dropdownMotion: Motion<DropdownMenuMotionStyle>`.
Она передаёт объект существующему меню. Поле, меню и строки имеют независимые контексты
по умолчанию; общий контекст задаётся явно. `ComboBoxStyle` по-прежнему содержит обычные
`textFieldStyle`, `dropdownStyle` и `selectItemStyle`.

```kotlin
val state = remember { SelectState() }
var value by remember { mutableStateOf("") }
val fieldMotion = rememberTextFieldMotion(
    style = TextFieldMotionStyle.builder().backgroundColor(
        transition { segment {} changesWith { finite(tween(200)) } },
    ).style(),
)
// Передаётся существующий Motion меню. Доступные переходы задаёт DropdownMenuMotionStyle.
val dropdownMotion = rememberDropdownMenuMotion()
ComboBox(
    dropdownMotion = dropdownMotion,
    state = state,
    trigger = {
        ComboBoxTextField(
            motion = fieldMotion,
            value = value,
            onValueChange = { value = it },
            modifier = Modifier.width(260.dp),
            style = TextFieldStyle.builder().colors {
                backgroundColor(
                    Color.LightGray.asStatefulBrush(
                        setOf(InteractiveState.Activated) to Color.White,
                    ),
                )
            }.style(),
        )
    },
    listContent = {
        item {
            SelectItem(
                checked = value == "Москва",
                onClick = {
                    value = "Москва"
                    state.close()
                },
                titleContent = { Text("Москва") },
            )
        }
    },
)
```

Незаданные Motion-переходы используют `noMotion()`. Это не отключает прежние
`TextFieldAnimation` и fade-переходы появления/исчезновения меню. Доступны только свойства,
которые поддерживают текущие `TextFieldMotionStyle` и `DropdownMenuMotionStyle`.
Переработка анимаций DropdownMenu/Popover в `feature/plasma-8013` выполняется отдельно;
данная миграция не расширяет их набор свойств.

Stateful-стиль и переходы строк описаны в разделе [SelectItem](SelectUsage.md#selectitem).

В большинстве случаев можно использовать готовые сгенерированные стили, а при необходимости создать собственный стиль через соответствующий builder. Подробнее о том, как работают `Style`, `StyleBuilder` и stateful-параметры стиля, см. в разделе [Стилизация компонентов](../theme/Styles.md).

### Параметры стиля `ComboBoxSingleNormal`

| Параметр | Тип | Возможные значения |
| --- | --- | --- |
| `size` | `ComboBoxSingleNormalSize` | `Xl`, `L`, `M`, `S`, `Xs` |

Пример выбора готового стиля:
```kotlin
val style = ComboBoxStyles.SingleNormal.style(
    size = ComboBoxSingleNormalSize.Xl
)

// или через dot notation
val style = ComboBoxSingleNormal.Xl.style()
```


### Параметры стиля `ComboBoxSingleTight`

| Параметр | Тип | Возможные значения |
| --- | --- | --- |
| `size` | `ComboBoxSingleTightSize` | `Xl`, `L`, `M`, `S`, `Xs` |

Пример выбора готового стиля:
```kotlin
val style = ComboBoxStyles.SingleTight.style(
    size = ComboBoxSingleTightSize.Xl
)

// или через dot notation
val style = ComboBoxSingleTight.Xl.style()
```


### Параметры стиля `ComboBoxMultipleNormal`

| Параметр | Тип | Возможные значения |
| --- | --- | --- |
| `size` | `ComboBoxMultipleNormalSize` | `Xl`, `L`, `M`, `S`, `Xs` |

Пример выбора готового стиля:
```kotlin
val style = ComboBoxStyles.MultipleNormal.style(
    size = ComboBoxMultipleNormalSize.Xl
)

// или через dot notation
val style = ComboBoxMultipleNormal.Xl.style()
```


### Параметры стиля `ComboBoxMultipleTight`

| Параметр | Тип | Возможные значения |
| --- | --- | --- |
| `size` | `ComboBoxMultipleTightSize` | `Xl`, `L`, `M`, `S`, `Xs` |

Пример выбора готового стиля:
```kotlin
val style = ComboBoxStyles.MultipleTight.style(
    size = ComboBoxMultipleTightSize.Xl
)

// или через dot notation
val style = ComboBoxMultipleTight.Xl.style()
```


### Создание стиля с помощью builder()

```kotlin
ComboBoxStyle.builder()
    .textFieldStyle(
        placeholder(
            TextFieldStyle.builder().style(),
            "/** Стиль компонента */",
        ),
    )
    .dropdownStyle(
        placeholder(
            DropdownMenuStyle.builder().style(),
            "/** Стиль компонента */",
        ),
    )
    .selectItemStyle(
        placeholder(
            SelectItemStyle.builder().style(),
            "/** Стиль компонента */",
        ),
    )
    .style()
```

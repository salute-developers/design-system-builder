---
title: AiUserMessage
---

Компонент AiUserMessage используется для отображения запроса пользователя в ИИ-сценариях.

В `isInEdit` отображает редактируемое поле в виде компонента [Editable](EditableUsage.md), 
при переходе в этот режим, Editable захватывает фокус и активизируется ввод текста.
В обычном режиме текст отображается посредстов мкомпонента [Text](TextUsage.md). С помощью `actions`  
и `editableActions` передайте контент для взаимодействия [ButtonGroup](ButtonGroupUsage.md) кнопки в 
группах стилизуются автоматически. Для отображения загружаемого пользователем контента используйте  
`uploadingContent` компоненты File и Image так же будут стилизованы автоматически.


## Простой пример использования

```kotlin
var text by remember { mutableStateOf("text") }
AiUserMessage(
    modifier = Modifier.fillMaxWidth(),
    value = text,
    onValueChange = { text = it },
)
```

## Пример использования с контентом для взаимодействия

```kotlin
var text by remember { mutableStateOf("text") }
AiUserMessage(
    modifier = Modifier.fillMaxWidth(),
    value = text,
    onValueChange = { text = it },
    actions = {
        button { IconButton(iconRes = R.drawable.ic_backward_outline_24, onClick = {}) }
        button { IconButton(iconRes = R.drawable.ic_copy_outline_24, onClick = {}) }
    },
)
```

## Пример использования с контентом для взаимодействия отображающимся в редактируемом режиме

```kotlin
var text by remember { mutableStateOf("text") }
AiUserMessage(
    modifier = Modifier.fillMaxWidth(),
    value = text,
    isInEdit = true,
    onValueChange = { text = it },
    editableActions = {
        button {
            Button(label = "Сохранить", onClick = {})
        }
        button {
            Button(label = "Отменить", onClick = {})
        }
    },
    actions = {
        button { IconButton(iconRes = R.drawable.ic_backward_outline_24, onClick = {}) }
        button { IconButton(iconRes = R.drawable.ic_copy_outline_24, onClick = {}) }
    },
)
```

## Полный пример использования 

```kotlin
var editMode by remember { mutableStateOf(false) }
var message by remember { mutableStateOf("Text") }
var draftMessage by remember { mutableStateOf("") }

AiUserMessage(
    modifier = Modifier.fillMaxWidth(),
    value = if (editMode) draftMessage else message,
    onValueChange = { draftMessage = it },
    isInEdit = editMode,
    uploadingContent =
    {
        repeat(5) {
            File(
                modifier = Modifier.width(200.dp),
                label = "some_file$it.pdf",
                isLoading = false,
                image = {
                    Icon(
                        painterResource(R.drawable.ic_file_check_fill_24),
                        contentDescription = "",
                    )
                },
                action = {
                    IconButton(
                        iconRes = R.drawable.ic_close_16,
                        onClick = {},
                    )
                },
                actionPlacement = FileActionPlacement.End,
            )
        }
    },
    editableActions =
    {
        button {
            Button(label = "Сохранить", onClick = {
                message = draftMessage
                editMode = false
            })
        }
        button {
            Button(label = "Отменить", onClick = {
                draftMessage = message
                editMode = false
            })
        }
    },
    actions =
    {
        button { IconButton(iconRes = R.drawable.ic_backward_outline_24, onClick = {}) }
        button { IconButton(iconRes = R.drawable.ic_copy_outline_24, onClick = {}) }
        button { IconButton(iconRes = R.drawable.ic_plasma_24, onClick = {}) }
        button {
            IconButton(iconRes = R.drawable.ic_edit_outline_24, onClick = {
                draftMessage = message
                editMode = true
            })
        }
    },
)
```


## Стиль AiUserMessage

В большинстве случаев можно использовать готовые сгенерированные стили, а при необходимости создать  
собственный стиль через метод `builder()`. Подробнее о том, как работают `Style`, `StyleBuilder`  
и параметры стиля с состояниями, см. в разделе [Стилизация компонентов](../theme/Styles.md).

### Параметры стиля

| Параметр | Тип | Возможные значения |
| --- | --- | --- |
| `size` | `AiUserMessageSize` | `Xl`, `L`, `M`, `S`, `Xs` |
| `contentType` | `AiUserMessageContentType` | `Image`, `File` |
| `contentView` | `AiUserMessageContentView` | `Default`, `Secondary` |
| `view` | `AiUserMessageView` | `Default`, `Secondary`, `Accent`, `Positive`, `Negative`, `Warning` |

Пример выбора готового стиля:
```kotlin
val style = AiUserMessageStyles.style(
    size = AiUserMessageSize.M,
    contentType = AiUserMessageContentType.Image,
    contentView = AiUserMessageContentView.Default,
    view = AiUserMessageView.Default
)

// или через dot notation
val style = AiUserMessage.M.Default.style()
```


### Создание стиля с помощью builder()

```kotlin
AiUserMessageStyle.builder()
    .uploadingShape(/** Токен формы (скругления) */)
    .messageShape(/** Токен формы (скругления) */)
    .textStyle(/** Токен типографики */)
    .editableStyle(
        placeholder(
            EditableStyle.builder().style(),
            "/** Стиль редактируемого поля */",
        ),
    )
    .actionsButtonGroupStyle(
        placeholder(
            ButtonGroupStyle.builder().style(),
            "/** Стиль группы кнопок, расположенных внизу */",
        ),
    )
    .editableActionsButtonGroupStyle(
        placeholder(
            ButtonGroupStyle.builder().style(),
            "/** Стиль группы кнопок, отображающихся в режиме редактирования */",
        ),
    )
    .uploadingImageStyle(
        placeholder(
            ImageStyle.builder().style(),
            "/** Стиль загружаемых изображений */",
        ),
    )
    .uploadingFileStyle(
        placeholder(
            FileStyle.builder().style(),
            "/** Стиль загружаемых файлов */",
        ),
    )
    .colors {
        textColor(/** Токен цвета */)
        uploadingBackground(/** Токен цвета */)
        messageBackground(/** Токен цвета */)
    }
    .dimensions {
        uploadingPaddingStart(0.0.dp)
        uploadingPaddingEnd(0.0.dp)
        uploadingPaddingTop(0.0.dp)
        uploadingPaddingBottom(0.0.dp)
        messagePaddingStart(18.0.dp)
        messagePaddingEnd(18.0.dp)
        messagePaddingTop(21.0.dp)
        messagePaddingBottom(21.0.dp)
        uploadingGroupGap(10.0.dp)
        uploadingFilesGap(0.0.dp)
        actionsGap(12.0.dp)
        editableActionsGap(16.0.dp)
    }
    .style()
```

## Слоты

- `value` - начальное значение отображаемого текста.
- `onValueChange` - поведение при изменении текстового значания.
- `isInEdit` - переводит компонент в режим редактирования.
- `actions` и `editableActions` - слоты с областью видимости `ButtonGroupScope`, каждый отрисовывается в отдельном ButtonGroup.
- `uploadingContent` - слот с областью видимости `ColumnScope`, отрисовывается внутри Column.

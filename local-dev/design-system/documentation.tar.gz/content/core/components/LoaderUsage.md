---
title: Loader
---

Компонент Loader используется для отображения статуса загрузки. Включает в себя компоненты [Spinner](SpinnerUsage.md),  
в качестве бесконечного прогресса, и [CircularProgressBar](CircularProgressBarUsage.md) - как конечный прогресс загрузки.  
Для настройки Loader используются те же параметры, что и для каждого из компонентов [Spinner] и [CircularProgressBar].  

Пример использования с помощью стиля самого Loader:

```kotlin
Loader(
    progress = 0.4f,
    trackEnabled = true,
    valueContent = {
        Icon(
            painter = painterResource(id = com.sdds.icons.R.drawable.ic_close_16),
            contentDescription = "",
        )
    },
    loaderType = LoaderType.Progress,
)
```

<!-- @screenshot: com.sdds.compose.uikit.fixtures.samples.loader.Loader_Simple -->

Пример использования через стили [Spinner] и [CircularProgressBar]:

```kotlin
Loader(
    progress = 0.4f,
    trackEnabled = true,
    valueContent = {
        Icon(
            painter = painterResource(id = com.sdds.icons.R.drawable.ic_close_16),
            contentDescription = "",
        )
    },
    loaderType = LoaderType.Spinner,
)
```

<!-- @screenshot: com.sdds.compose.uikit.fixtures.samples.loader.LoaderSpinner_Simple -->

## Стиль Loader

В большинстве случаев можно использовать готовые сгенерированные стили, а при необходимости создать собственный стиль через соответствующий builder. Подробнее о том, как работают `Style`, `StyleBuilder` и stateful-параметры стиля, см. в разделе [Стилизация компонентов](../theme/Styles.md).

Пример выбора готового стиля:
```kotlin
val style = LoaderStyles.style()

// или через dot notation
val style = Loader.Default.style()
```


### Создание стиля с помощью builder()

```kotlin
LoaderStyle.builder()
    .spinnerStyle(/** Стиль комопнента */)
    .circularProgressStyle(/** Стиль комопнента */)
    .style()
```

## LoaderType

Параметр, определяющй, какой компонент отображается в данный момент. Ожидаемое значение  
enum LoaderType,  для отображения [Spinner] - LoaderType.Spinner, для [CircularProgressBar] - LoaderType.Progress

## Примечание

При использовании Loader с конструктором, принимающим value и valueSuffix, используя готовую линейку  
сгенерированных стилей, обратите внимание, что в размерах меньше Xl, параметр valueEnabled у CircularProgressBar,  
выключен.
Так же, стоит отметить, что возможно задать разные стили и размеры компонентов [Spinner] и [CircularProgressBar]  
при этом, размер самого компонента Loader примет размеры большего из дочерних компонентов.

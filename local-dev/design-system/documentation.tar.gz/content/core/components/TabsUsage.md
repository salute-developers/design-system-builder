---
title: Tabs
---

Компонент для навигации между разделами интерфейса.
В качестве контента ожидает [TabItem](#tabitem) либо [IconTabItem](#icontabitem).

```kotlin
val pagerState = rememberPagerState { 5 }
val scope = rememberCoroutineScope()
Tabs(
    selectedTabIndexProvider = { pagerState.currentPage },
    selectedTabOffset = { pagerState.currentPageOffsetFraction },
) {
    repeat(pagerState.pageCount) { index ->
        tabItem {
            // Анимация TabItem при изменении состояния pagerState
            val tabMotion = rememberTabItemPagerMotion(index, pagerState)
            // Состояние выбора текущего таба
            val isTabSelected = rememberTabSelectedState(index, pagerState)
            TabItem(
                isSelected = isTabSelected.value,
                onClick = {
                    scope.launch {
                        pagerState.animateScrollToPage(
                            index,
                            pagerState.currentPageOffsetFraction,
                        )
                    }
                },
                content = { Text("Tab$index") },
                helperContent = { Text("Value") },
                counter = {
                    Counter(
                        count = "3",
                        // Делимся контекстом с Counter, чтобы он анимировлся синхронно с TabItem
                        motion = rememberCounterMotion(motionContext = tabMotion.context),
                    )
                },
                startContent = {
                    Icon(
                        source = resourceImageSource(R.drawable.ic_plasma_24),
                        contentDescription = "",
                    )
                },
                motion = tabMotion,
            )
        }
    }
}

HorizontalPager(
    state = pagerState,
    pageContent = {},
)
```

<!-- @screenshot: com.sdds.compose.uikit.fixtures.samples.tabs.Tabs_Simple -->

## TabsClip

Способ расположения табов. Возможные значения: 
- **None** - табы размещаются как есть. Непоместившиеся табы уйдут за границу контейнера.
- **ShowMore** - табы размещаются, пока есть место в контейнере. Если все табы не помещаются, отображается disclosure-кнопка, по нажатию которой открывается список с непоместившимися табами.
- **Scroll** - табы размещаются в скроллящемся контейнере

## TabsOrientation

Ориентация табов. Возможные значения:
- **Vertical** - табы размещаются вертикально
- **Horizontal** - табы размещаются горизонтально

## Стиль Tabs

В большинстве случаев можно использовать готовые сгенерированные стили, а при необходимости создать собственный стиль через соответствующий builder. Подробнее о том, как работают `Style`, `StyleBuilder` и stateful-параметры стиля, см. в разделе [Стилизация компонентов](../theme/Styles.md).

### Параметры стиля `TabsDefault`

| Параметр | Тип | Возможные значения |
| --- | --- | --- |
| `size` | `TabsDefaultSize` | `L`, `M`, `S`, `Xs` |
| `orientation` | `TabsDefaultOrientation` | `Default`, `Horizontal`, `Vertical` |

Пример выбора готового стиля:
```kotlin
val style = TabsStyles.Default.style(
    size = TabsDefaultSize.L,
    orientation = TabsDefaultOrientation.Default
)

// или через dot notation
val style = TabsDefault.L.style()
```


### Параметры стиля `IconTabs`

| Параметр | Тип | Возможные значения |
| --- | --- | --- |
| `size` | `IconTabsSize` | `L`, `M`, `S`, `Xs` |
| `orientation` | `IconTabsOrientation` | `Default`, `Horizontal`, `Vertical` |

Пример выбора готового стиля:
```kotlin
val style = TabsStyles.IconTabs.style(
    size = IconTabsSize.L,
    orientation = IconTabsOrientation.Default
)

// или через dot notation
val style = IconTabs.L.style()
```


### Параметры стиля `TabsHeader`

| Параметр | Тип | Возможные значения |
| --- | --- | --- |
| `size` | `TabsHeaderSize` | `H1`, `H2`, `H3`, `H4`, `H5` |

Пример выбора готового стиля:
```kotlin
val style = TabsStyles.Header.style(
    size = TabsHeaderSize.H1
)

// или через dot notation
val style = TabsHeader.H1.style()
```


### Создание стиля с помощью builder()

```kotlin
TabsStyle.builder()
    .colors {
        indicatorColor(/** Токен цвета */.asInteractive())
        overflowNextIconColor(/** Токен цвета */.asInteractive())
        overflowPrevIconColor(/** Токен цвета */.asInteractive())
        disclosureColor(
            /** Токен цвета */.asInteractive(
                setOf(InteractiveState.Hovered)
                    to /** Цвет в состоянии hovered */,
                setOf(InteractiveState.Pressed)
                    to /** Цвет в состоянии pressed */,
            ),
        )
    }
    .dimensions {
        indicatorThickness(2.0.dp)
        minSpacing(0.0.dp)
        minHeight(68.dp)
    }
    .orientation(TabsOrientation.Vertical)
    .dividerStyle(/** Стиль компонента */)
    .overflowNextIcon(resourceImageSource(R.drawable.ic_disclosure_right_outline_24))
    .overflowPrevIcon(resourceImageSource(R.drawable.ic_disclosure_left_outline_24))
    .dividerEnabled(true)
    .indicatorEnabled(true)
    .dropdownMenuStyle(/** Стиль компонента */)
    .disclosureTextStyle(/** Токен типографики */)
    .tabItemStyle(/** Стиль компонента */)
    .style()
```

## TabItem

Элемент `Tabs`. При использовании внутри `Tabs` компонент стилизуется автоматически. Если нужен отдельный стиль для элемента, используйте `TabItemStyle.builder()`. Общие принципы работы `Style` и `StyleBuilder` описаны в разделе [Стилизация компонентов](../theme/Styles.md).

### Создание стиля с помощью builder()

```kotlin
TabItemStyle.builder()
    .colors {
        labelColor(
            /** Токен цвета */.asStatefulValue(
                setOf(InteractiveState.Selected, InteractiveState.Pressed)
                    to /** Цвет в состоянии selected + pressed */,
                setOf(InteractiveState.Selected, InteractiveState.Hovered)
                    to /** Цвет в состоянии selected + hovered */,
                setOf(InteractiveState.Hovered)
                    to /** Цвет в состоянии hovered */,
                setOf(InteractiveState.Pressed)
                    to /** Цвет в состоянии pressed */,
                setOf(InteractiveState.Selected)
                    to /** Цвет в состоянии selected */,
            ),
        )
        valueColor(
            /** Токен цвета */.asStatefulValue(
                setOf(InteractiveState.Selected, InteractiveState.Pressed)
                    to /** Цвет в состоянии selected + pressed */,
                setOf(InteractiveState.Selected, InteractiveState.Hovered)
                    to /** Цвет в состоянии selected + hovered */,
                setOf(InteractiveState.Hovered)
                    to /** Цвет в состоянии hovered */,
                setOf(InteractiveState.Pressed)
                    to /** Цвет в состоянии pressed */,
                setOf(InteractiveState.Selected)
                    to /** Цвет в состоянии selected */,
            ),
        )
        startContentColor(
            /** Токен цвета */.asStatefulValue(
                setOf(InteractiveState.Selected, InteractiveState.Pressed)
                    to /** Цвет в состоянии selected + pressed */,
                setOf(InteractiveState.Selected, InteractiveState.Hovered)
                    to /** Цвет в состоянии selected + hovered */,
                setOf(InteractiveState.Hovered)
                    to /** Цвет в состоянии hovered */,
                setOf(InteractiveState.Pressed)
                    to /** Цвет в состоянии pressed */,
                setOf(InteractiveState.Selected)
                    to /** Цвет в состоянии selected */,
            ),
        )
        endContentColor(
            /** Токен цвета */.asStatefulValue(
                setOf(InteractiveState.Selected, InteractiveState.Pressed)
                    to /** Цвет в состоянии selected + pressed */,
                setOf(InteractiveState.Selected, InteractiveState.Hovered)
                    to /** Цвет в состоянии selected + hovered */,
                setOf(InteractiveState.Hovered)
                    to /** Цвет в состоянии hovered */,
                setOf(InteractiveState.Pressed)
                    to /** Цвет в состоянии pressed */,
                setOf(InteractiveState.Selected)
                    to /** Цвет в состоянии selected */,
            ),
        )
        actionColor(
            /** Токен цвета */.asStatefulValue(
                setOf(InteractiveState.Hovered)
                    to /** Цвет в состоянии hovered */,
                setOf(InteractiveState.Pressed)
                    to /** Цвет в состоянии pressed */,
            ),
        )
    }
    .disableAlpha(0.4f)
    .labelStyle(/** Токен типографики */)
    .valueStyle(/** Токен типографики */)
    .dimensions {
        paddingStart(0.0.dp)
        paddingEnd(0.0.dp)
        minHeight(56.0.dp)
        startContentSize(24.0.dp)
        endContentSize(24.0.dp)
        counterPadding(8.0.dp)
        valuePadding(8.0.dp)
        actionPadding(10.0.dp)
    }
    .counterStyle(/** Стиль компонента */)
    .actionIcon(resourceImageSource(R.drawable.ic_close_24))
    .style()
```

## IconTabItem

Элемент `Tabs`. При использовании внутри `Tabs` компонент стилизуется автоматически. Если нужен отдельный стиль для элемента, используйте `TabItemStyle.builder()`. Общие принципы работы `Style` и `StyleBuilder` описаны в разделе [Стилизация компонентов](../theme/Styles.md).

### Создание стиля с помощью builder()

```kotlin
TabItemStyle.builder()
    .colors {
        startContentColor(
            /** Токен цвета */.asStatefulValue(
                setOf(InteractiveState.Selected, InteractiveState.Pressed)
                    to /** Цвет в состоянии selected + pressed */,
                setOf(InteractiveState.Selected, InteractiveState.Hovered)
                    to /** Цвет в состоянии selected + hovered */,
                setOf(InteractiveState.Hovered)
                    to /** Цвет в состоянии hovered */,
                setOf(InteractiveState.Pressed)
                    to /** Цвет в состоянии pressed */,
                setOf(InteractiveState.Selected)
                    to /** Цвет в состоянии selected */,
            ),
        )
        endContentColor(
            /** Токен цвета */.asStatefulValue(
                setOf(InteractiveState.Selected, InteractiveState.Pressed)
                    to /** Цвет в состоянии selected + pressed */,
                setOf(InteractiveState.Selected, InteractiveState.Hovered)
                    to /** Цвет в состоянии selected + hovered */,
                setOf(InteractiveState.Hovered)
                    to /** Цвет в состоянии hovered */,
                setOf(InteractiveState.Pressed)
                    to /** Цвет в состоянии pressed */,
                setOf(InteractiveState.Selected)
                    to /** Цвет в состоянии selected */,
            ),
        )
        actionColor(
            /** Токен цвета */.asStatefulValue(
                setOf(InteractiveState.Hovered)
                    to /** Цвет в состоянии hovered */,
                setOf(InteractiveState.Pressed)
                    to /** Цвет в состоянии pressed */,
            ),
        )
    }
    .disableAlpha(0.4f)
    .dimensions {
        minHeight(56.0.dp)
        paddingStart(18.0.dp)
        paddingEnd(18.0.dp)
        startContentSize(24.0.dp)
        endContentSize(24.0.dp)
        actionPadding(10.0.dp)
        counterPadding(0.0.dp)
        counterOffsetX(8.0.dp)
        counterOffsetY(8.0.dp)
    }
    .counterStyle(/** Стиль компонента */)
    .actionIcon(resourceImageSource(R.drawable.ic_close_24))
    .style()
```

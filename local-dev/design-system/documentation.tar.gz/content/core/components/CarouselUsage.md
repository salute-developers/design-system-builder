---
title: Carousel
---

Компонент карусели с горизонтальной прокруткой, поддерживающий индикатор страниц, навигационные кнопки и различные варианты отображения.


## Примеры использования

Простой пример карусели с настройками по умолчанию:

```kotlin
val carouselState = rememberPagerState { carouselData.size }
Carousel(
    state = carouselState,
    pageSize = PageSize.Fixed(250.dp),
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .height(250.dp),
    ) {
        Text(carouselData[it])
    }
}
```

<!-- @screenshot: com.sdds.compose.uikit.fixtures.samples.carousel.Carousel_Simple -->

Пример карусели без кнопок перемотки:

```kotlin
val carouselState = rememberPagerState { carouselData.size }
Carousel(
    state = carouselState,
    hasControls = false,
    pageSize = PageSize.Fixed(250.dp),
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .height(250.dp),
    ) {
        Text(carouselData[it])
    }
}
```

Пример карусели без индикатора страниц:

```kotlin
val carouselState = rememberPagerState { carouselData.size }
Carousel(
    state = carouselState,
    hasIndicator = false,
    pageSize = PageSize.Fixed(250.dp),
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .height(250.dp),
    ) {
        Text(carouselData[it])
    }
}
```

Пример карусели с прилипанием страниц по центру:

```kotlin
val carouselState = rememberPagerState { carouselData.size }
Carousel(
    state = carouselState,
    snapPosition = SnapPosition.Center,
    pageSize = PageSize.Fixed(250.dp),
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .height(250.dp),
    ) {
        Text(carouselData[it])
    }
}
```

## Стиль Carousel

В большинстве случаев можно использовать готовые сгенерированные стили, а при необходимости создать собственный стиль через соответствующий builder. Подробнее о том, как работают `Style`, `StyleBuilder` и stateful-параметры стиля, см. в разделе [Стилизация компонентов](../theme/Styles.md).

### Параметры стиля

| Параметр | Тип | Возможные значения |
| --- | --- | --- |
| `buttonsPlacement` | `CarouselButtonsPlacement` | `Inner`, `Outer` |

Пример выбора готового стиля:
```kotlin
val style = CarouselStyles.style(
    buttonsPlacement = CarouselButtonsPlacement.Inner
)

// или через dot notation
val style = Carousel.ButtonsPlacementInner.style()
```


### Создание стиля с помощью builder()

```kotlin
CarouselStyle.builder()
    .dimensions {
        nextButtonPadding(8.0.dp)
        prevButtonPadding(8.0.dp)
        indicatorPadding(8.0.dp)
        gap(8.dp)
    }
    .prevButtonStyle(/** Стиль компонента IconButton */)
    .nextButtonStyle(/** Стиль компонента IconButton */)
    .indicatorStyle(
        /** Стиль компонента PaginationDots */,
    )
    .prevButtonIcon(resourceImageSource(R.drawable.ic_chevron_left_36))
    .nextButtonIcon(resourceImageSource(R.drawable.ic_chevron_right_36))
    .buttonsPlacement(CarouselButtonsPlacement.Inner)
    .style()
```

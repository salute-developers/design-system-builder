---
title: IconButton
---

```kotlin
IconButton(
    iconRes = com.sdds.icons.R.drawable.ic_alarm_done_fill_36,
    onClick = { },
    enabled = true,
    loading = false,
)
```

<!-- @screenshot: com.sdds.compose.uikit.fixtures.samples.button.IconButton_Simple -->

## Стиль IconButton

В большинстве случаев можно использовать готовые сгенерированные стили, а при необходимости создать собственный стиль через соответствующий builder. Подробнее о том, как работают `Style`, `StyleBuilder` и stateful-параметры стиля, см. в разделе [Стилизация компонентов](../theme/Styles.md).

### Параметры стиля

| Параметр | Тип | Возможные значения |
| --- | --- | --- |
| `size` | `IconButtonDefaultSize` | `Xl`, `L`, `M`, `S`, `Xs`, `Xxs` |
| `shape` | `IconButtonDefaultShape` | `Default`, `Pilled` |
| `view` | `IconButtonDefaultView` | `Default`, `Secondary`, `Accent`, `Positive`, `Negative`, `Warning`, `Clear`, `Dark`, `Black`, `White` |

Пример выбора готового стиля:
```kotlin
val style = IconButtonStyles.Default.style(
    size = IconButtonDefaultSize.Xl,
    shape = IconButtonDefaultShape.Default,
    view = IconButtonDefaultView.Default
)

// или через dot notation
val style = IconButton.Xl.Default.style()
```


### Параметры стиля `AiHeaderEmbeddedIconButton`

| Параметр | Тип | Возможные значения |
| --- | --- | --- |
| `size` | `AiHeaderEmbeddedIconButtonSize` | `Xl`, `L`, `M`, `S` |
| `view` | `AiHeaderEmbeddedIconButtonView` | `Default`, `Secondary`, `Accent`, `Positive`, `Negative`, `Warning`, `Clear`, `Info` |

Пример выбора готового стиля:
```kotlin
val style = IconButtonStyles.AiHeaderEmbeddedIconButton.style(
    size = AiHeaderEmbeddedIconButtonSize.M,
    view = AiHeaderEmbeddedIconButtonView.Default
)

// или через dot notation
val style = AiHeaderEmbeddedIconButton.M.Default.style()
```


### Параметры стиля `EmbeddedIconButton`

| Параметр | Тип | Возможные значения |
| --- | --- | --- |
| `size` | `EmbeddedIconButtonSize` | `L`, `M`, `S`, `Xs` |
| `view` | `EmbeddedIconButtonView` | `Default`, `Secondary`, `Accent`, `Positive`, `Negative`, `Warning`, `Clear`, `Info` |

Пример выбора готового стиля:
```kotlin
val style = IconButtonStyles.EmbeddedIconButton.style(
    size = EmbeddedIconButtonSize.M,
    view = EmbeddedIconButtonView.Default
)

// или через dot notation
val style = EmbeddedIconButton.M.Default.style()
```


### Создание стиля с помощью builder()

```kotlin
ButtonStyle.iconButtonBuilder()
    .shape(/** Токен формы (скругления) */)
    .colors {
        backgroundColor(
            Color.White.asInteractive(
                setOf(InteractiveState.Pressed)
                    to /** Цвет в состоянии pressed */,
                setOf(InteractiveState.Hovered)
                    to /** Цвет в состоянии hovered */,
            ),
        )
        spinnerColor(/** Токен цвета */)
        iconColor(/** Токен цвета */)
    }
    .dimensions {
        height(64.0.dp)
        paddingStart(28.0.dp)
        paddingEnd(28.0.dp)
        minWidth(106.0.dp)
        iconSize(24.0.dp)
        spinnerSize(24.0.dp)
        spinnerStrokeWidth(2.0.dp)
    }
    .style()
```

## IconButton Loading

Имеется возможность отобразить состояние загрузки (спиннер), вместо контента, с помощью параметра loading.

```kotlin
IconButton(
    iconRes = com.sdds.icons.R.drawable.ic_alarm_done_fill_36,
    onClick = { },
    enabled = true,
    loading = true,
)
```

<!-- @screenshot: com.sdds.compose.uikit.fixtures.samples.button.IconButton.isLoading -->

## Произвольный контент в IconButton

Вместо указания ресурса иконки, имеется возможность передать самостоятельно настроенный контент.  
При этом если в качестве контента используется [Icon](./IconUsage.md) и для контента не задан явно размер и  
цвет - будут применены размер и цвет указанный в стиле.

```kotlin
IconButton(
    icon = {
        Icon(
            painter = painterResource(com.sdds.icons.R.drawable.ic_alarm_done_fill_36),
            contentDescription = "Будильник",
        )
    },
    onClick = { },
    enabled = true,
    loading = false,
)
```

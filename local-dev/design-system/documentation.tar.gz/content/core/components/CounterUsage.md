---
title: Counter
---

Компонент Counter - по сути небольшого размера Badge для отображения числовых значений (счетчик).
Параметр count может быть формата String, AnnotatedString, а так же composable лямбдой.

```kotlin
Counter(
    count = "1",
)
```

<!-- @screenshot: com.sdds.compose.uikit.fixtures.samples.counter.Counter_Simple -->

## Стиль Counter

В большинстве случаев можно использовать готовые сгенерированные стили, а при необходимости создать собственный стиль через соответствующий builder. Подробнее о том, как работают `Style`, `StyleBuilder` и stateful-параметры стиля, см. в разделе [Стилизация компонентов](../theme/Styles.md).

### Параметры стиля

| Параметр | Тип | Возможные значения |
| --- | --- | --- |
| `size` | `CounterDefaultSize` | `L`, `M`, `S`, `Xs`, `Xxs` |
| `view` | `CounterDefaultView` | `Default`, `Accent`, `Positive`, `Warning`, `Negative`, `Black`, `White` |

Пример выбора готового стиля:
```kotlin
val style = CounterStyles.Default.style(
    size = CounterDefaultSize.L,
    view = CounterDefaultView.Default
)

// или через dot notation
val style = Counter.L.Default.style()
```


### Параметры стиля `SegmentItemCounter`

| Параметр | Тип | Возможные значения |
| --- | --- | --- |
| `size` | `SegmentItemCounterSize` | `L`, `M`, `S`, `Xs`, `Xxs` |
| `view` | `SegmentItemCounterView` | `Default`, `Accent` |

Пример выбора готового стиля:
```kotlin
val style = CounterStyles.SegmentItemCounter.style(
    size = SegmentItemCounterSize.L,
    view = SegmentItemCounterView.Default
)

// или через dot notation
val style = SegmentItemCounter.L.Default.style()
```


### Создание стиля с помощью builder()

```kotlin
CounterStyle.builder()
    .colors {
        backgroundColor(
            /** Токен цвета */.asInteractive(
                setOf(InteractiveState.Pressed)
                    to /** Цвет в состоянии pressed */,
                setOf(InteractiveState.Hovered)
                    to /** Цвет в состоянии hovered */,
            ),
        )
        textColor(
            /** Токен цвета */.asInteractive(
                setOf(InteractiveState.Pressed)
                    to /** Цвет в состоянии pressed */,
                setOf(InteractiveState.Hovered)
                    to /** Цвет в состоянии hovered */,
            ),
        )
    }
    .textStyle(/** Токен типографики */)
    .dimensions {
        minHeight(28.0.dp)
        minWidth(28.0.dp)
        paddingStart(10.0.dp)
        paddingEnd(10.0.dp)
    }
    .style()
```

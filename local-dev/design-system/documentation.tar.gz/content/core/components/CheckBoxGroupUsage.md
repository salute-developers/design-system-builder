---
title: CheckBoxGroup
---

Контент CheckBoxGroup формируется с помощью функций rootCheckbox(), checkbox() и checkboxes() из скоупа CheckboxGroupScope.
RootCheckBox() функция для главного чекбокса, который управляет всей группой, для добавления остальных элементов в группе - checkbox()
или checkboxes().

```kotlin
CheckBoxGroup {
    rootCheckbox {
        CheckBox(
            state = ToggleableState.On,
            label = "Label",
            description = "Description",
        )
    }
    checkbox {
        CheckBox(
            state = ToggleableState.On,
            label = "Label",
            description = "Description",
        )
    }
    checkbox {
        CheckBox(
            state = ToggleableState.On,
            label = "Label",
            description = "Description",
        )
    }
}
```

<!-- @screenshot: com.sdds.compose.uikit.fixtures.samples.checkbox.group.CheckBoxGroup_Simple -->

## Стиль CheckBoxGroup

В большинстве случаев можно использовать готовые сгенерированные стили, а при необходимости создать собственный стиль через соответствующий builder. Подробнее о том, как работают `Style`, `StyleBuilder` и stateful-параметры стиля, см. в разделе [Стилизация компонентов](../theme/Styles.md).

### Параметры стиля

| Параметр | Тип | Возможные значения |
| --- | --- | --- |
| `size` | `CheckBoxGroupSize` | `L`, `M`, `S` |

Пример выбора готового стиля:
```kotlin
val style = CheckBoxGroupStyles.style(
    size = CheckBoxGroupSize.L
)

// или через dot notation
val style = CheckBoxGroup.L.style()
```


### Создание стиля с помощью builder()

```kotlin
CheckBoxGroupStyle.builder()
    .checkBoxStyle(/** Стиль компонента */)
    .dimensions {
        itemSpacing(14.0.dp)
        itemOffset(36.0.dp)
    }
    .style()
```

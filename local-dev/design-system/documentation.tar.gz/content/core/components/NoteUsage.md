---
title: Note
---
Компонент для отображения краткой статусной информации внутри контентного блока.  
Реализован в двух ориентациях вертикальной - Note и горизонтальной - NoteCompact.  

В качестве action ожидает LinkButton.

```kotlin
NoteCompact(
    title = "Title",
    text = "Text",
    contentBefore = {
        Icon(
            painter = painterResource(com.sdds.icons.R.drawable.ic_salute_outline_24),
            contentDescription = null,
        )
    },
    action = {
        Button(
            style = LocalLinkButtonStyle.current,
            label = "Label",
            onClick = {},
        )
    },
)
```

<!-- @screenshot: com.sdds.compose.uikit.fixtures.samples.note.NoteCompact_Simple -->

```kotlin
Note(
    title = "Title",
    text = "Text",
    contentBefore = {
        Icon(
            painter = painterResource(com.sdds.icons.R.drawable.ic_salute_outline_24),
            contentDescription = null,
        )
    },
    action = {
        Button(
            style = LocalLinkButtonStyle.current,
            label = "Label",
            onClick = {},
        )
    },
)
```

<!-- @screenshot: com.sdds.compose.uikit.fixtures.samples.note.Note_Simple -->

## Стиль Note

В большинстве случаев можно использовать готовые сгенерированные стили, а при необходимости создать собственный стиль через соответствующий builder. Подробнее о том, как работают `Style`, `StyleBuilder` и stateful-параметры стиля, см. в разделе [Стилизация компонентов](../theme/Styles.md).

### Параметры стиля

| Параметр | Тип | Возможные значения |
| --- | --- | --- |
| `size` | `NoteSize` | `L`, `M`, `S`, `Xs` |
| `contentBefore` | `NoteContentBefore` | `Fixed`, `Scalable` |
| `hasClose` | `Boolean` | `true`, `false` |
| `view` | `NoteView` | `Default`, `Positive`, `Negative`, `Warning`, `Info` |

Пример выбора готового стиля:
```kotlin
val style = NoteStyles.style(
    size = NoteSize.L,
    contentBefore = NoteContentBefore.Fixed,
    hasClose = false,
    view = NoteView.Default
)

// или через dot notation
val style = Note.L.Default.style()
```


### Создание стиля NoteCompact с помощью builder()

```kotlin
NoteCompactStyle.builder()
    .shape(/** Токе формы(скругления) */.adjustBy(all = -2.0.dp))
    .contentBeforeArrangement(ContentBeforeVerticalArrangement.Top)
    .titleStyle(/** Токен типографики */)
    .textStyle(/** Токен типографики */)
    .dimensions {
        paddingStart(30.0.dp)
        paddingEnd(30.0.dp)
        paddingTop(7.0.dp)
        paddingBottom(24.0.dp)
        iconSize(24.0.dp)
        contentBeforeEndMargin(12.0.dp)
        textTopMargin(4.0.dp)
        closeStartMargin(0.0.dp)
        actionStartMargin(16.0.dp)
        actionEndMargin(0.0.dp)
    }
    .style()
```

### Создание стиля Note с помощью builder()

```kotlin
NoteStyle.builder()
    .shape(/** Токе формы(скругления) */.adjustBy(all = -2.0.dp))
    .contentBeforeArrangement(ContentBeforeVerticalArrangement.Top)
    .titleStyle(/** Токен типографики */)
    .textStyle(/** Токен типографики */)
    .dimensions {
        paddingStart(28.0.dp)
        paddingEnd(28.0.dp)
        paddingTop(24.0.dp)
        paddingBottom(7.0.dp)
        iconSize(24.0.dp)
        closeTopMargin(0.0.dp)
        contentBeforeEndMargin(12.0.dp)
        textTopMargin(4.0.dp)
        titlePaddingEnd(0.0.dp)
        closeEndMargin(0.0.dp)
        actionTopMargin(0.0.dp)
    }
    .style()
```

## ContentBeforeArrangement

Расположение слота contentBefore. Возможные значения: Top, Center, Bottom.  
Выравнивание при Top осуществляется относительно центра Title. Выравнивание при Center осуществляется  
относительно всего текстового блока, содержащего и Title и Text. Bottom - выравнивание по нижней границе Text.  

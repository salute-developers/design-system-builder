---
title: Button
---

```kotlin
Button(
    label = "Label",
    enabled = true,
    loading = false,
    onClick = {},
)
```

<!-- @screenshot: com.sdds.compose.uikit.fixtures.samples.button.BasicButton_Simple -->

## Стиль Button

В большинстве случаев можно использовать готовые сгенерированные стили, а при необходимости создать собственный стиль через соответствующий builder. Подробнее о том, как работают `Style`, `StyleBuilder` и stateful-параметры стиля, см. в разделе [Стилизация компонентов](../theme/Styles.md).

### Параметры стиля

| Параметр | Тип | Возможные значения |
| --- | --- | --- |
| `size` | `BasicButtonSize` | `Xl`, `L`, `M`, `S`, `Xs`, `Xxs` |
| `view` | `BasicButtonView` | `Default`, `Secondary`, `Accent`, `Positive`, `Negative`, `Warning`, `Clear`, `Dark`, `Black`, `White` |

Пример выбора готового стиля:
```kotlin
val style = BasicButtonStyles.style(
    size = BasicButtonSize.Xl,
    view = BasicButtonView.Default
)

// или через dot notation
val style = BasicButton.Xl.Default.style()
```


### Создание стиля с помощью builder()

```kotlin
ButtonStyle.basicButtonBuilder()
    .shape(/** Токен формы (скругления) */)
    .labelStyle(/** Токен типографики */)
    .valueStyle(/** Токен типографики */)
    .colors {
        backgroundColor(
            Color.White.asInteractive(
                setOf(InteractiveState.Pressed)
                    to /** Цвет в состоянии pressed */,
                setOf(InteractiveState.Hovered)
                    to /** Цвет в состоянии hovered */,
            ),
        )
        spinnerColor(/** Токен цвета */)
        iconColor(/** Токен цвета */)
        labelColor(/** Токен цвета */)
        valueColor(/** Токен цвета */)
    }
    .dimensions {
        height(64.0.dp)
        paddingStart(28.0.dp)
        paddingEnd(28.0.dp)
        minWidth(106.0.dp)
        iconSize(24.0.dp)
        spinnerSize(24.0.dp)
        spinnerStrokeWidth(2.0.dp)
        iconMargin(8.0.dp)
        valueMargin(4.0.dp)
    }
    .style()
```

## Расположение контента внутри Button

Расположение контента задается при помощи параметра spacing. 
Может быть Packed (контент центрирован, лишние отступы располагаются по краям):

```kotlin
Button(
    label = "Label",
    value = "Value",
    spacing = ButtonSpacing.Packed,
    onClick = {},
)
```

<!-- @screenshot: com.sdds.compose.uikit.fixtures.samples.button.BasicButton_LabelValue_Packed -->

или SpaceBetween (Контент отобразится по всей ширине, отступы будут добавлены между элементами контента): 
```kotlin
Button(
    modifier = Modifier.fillMaxWidth(),
    label = "Label",
    value = "Value",
    spacing = ButtonSpacing.SpaceBetween,
    onClick = {},
)
```

<!-- @screenshot: com.sdds.compose.uikit.fixtures.samples.button.BasicButton_LabelValue_SpaceBetween -->

## Button Loading

Имеется возможность отобразить состояние загрузки (спиннер), вместо контента, с помощью параметра loading.

```kotlin
Button(
    label = "Label",
    value = "",
    enabled = true,
    loading = true,
    onClick = {},
)
```

<!-- @screenshot: com.sdds.compose.uikit.fixtures.samples.button.BasicButton_isLoading -->

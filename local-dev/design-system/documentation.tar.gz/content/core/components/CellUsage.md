---
title: Cell
---

Компонент ячейки представляет собой стилизованные слоты для контента.

```kotlin
Cell(
    modifier = Modifier
        .focusable(interactionSource = interactionSource)
        .focusSelector(
            settings = LocalFocusSelectorSettings.current,
        ) { isFocused.value },
    title = AnnotatedString("Заголовок"),
    subtitle = AnnotatedString("Подзаголовок"),
    label = AnnotatedString("Лейбл"),
    disclosureContentEnabled = true,
    startContent = {
        Icon(
            painter = painterResource(id = R.drawable.ic_plasma_16),
            contentDescription = "",
        )
    },
    endContent = {
        Icon(
            painter = painterResource(id = R.drawable.ic_plasma_16),
            contentDescription = "",
        )
    },
    interactionSource = interactionSource,
)
```

<!-- @screenshot: com.sdds.compose.uikit.fixtures.samples.cell.Cell_Simple -->

## Стиль Cell

В большинстве случаев можно использовать готовые сгенерированные стили, а при необходимости создать собственный стиль через соответствующий builder. Подробнее о том, как работают `Style`, `StyleBuilder` и stateful-параметры стиля, см. в разделе [Стилизация компонентов](../theme/Styles.md).

### Параметры стиля

| Параметр | Тип | Возможные значения |
| --- | --- | --- |
| `size` | `CellSize` | `L`, `M`, `S`, `Xs` |

Пример выбора готового стиля:
```kotlin
val style = CellStyles.style(
    size = CellSize.L
)

// или через dot notation
val style = Cell.L.style()
```


### Создание стиля с помощью builder()

```kotlin
CellStyle.builder()
    .colors {
        labelColor(/** Токен цвета */)
        titleColor(/** Токен цвета */)
        subtitleColor(/** Токен цвета */)
        disclosureTextColor(/** Токен цвета */)
        disclosureIconColor(/** Токен цвета */)
    }
    .labelStyle(/** Токен типографики */)
    .titleStyle(/** Токен типографики */)
    .subtitleStyle(/** Токен типографики */)
    .disclosureTextStyle(/** Токен типографики */)
    .disclosureIcon(resourceImageSource(R.drawable.ic_disclosure_right_outline_24))
    .dimensions {
        contentPaddingStart(8.0.dp)
        contentPaddingEnd(8.0.dp)
    }
    .avatarStyle(/** Стиль компонента Avatar */)
    .iconButtonStyle(
        /** Стиль компонента IconButton */,
    )
    .checkBoxStyle(/** Стиль компонента CheckBox */)
    .radioBoxStyle(/** Стиль компонента RadioBox */)
    .switchStyle(/** Стиль компонента Switch */)
    .style()
```

## Cell Gravity

Выравнивание контента по вертикали возможно установить спомощью параметра gravity.

```kotlin
Cell(
    gravity = CellGravity.Center,
    disclosureContentEnabled = false,
)
```

## Cell Disclosure

С помощью параметра disclosureEnabled возможно отобразить иконку "раскрытия" контента, а так же disclosureText текст - описание.

```kotlin
Cell(
    disclosureContentEnabled = true,
    disclosureText = AnnotatedString("Description"),
)
```

## Cell Content

В качестве startContent и endContent предусматривается использование функций
Avatar(),  Switch(), CheckBox(), RadioBox(), IconButton() или иконка, а так же функций из RowScope.

```kotlin
Cell(
    modifier = Modifier
        .fillMaxWidth()
        .focusable(interactionSource = interactionSource)
        .focusSelector(
            settings = LocalFocusSelectorSettings.current,
        ) { isFocused.value },
    title = AnnotatedString("Заголовок"),
    subtitle = AnnotatedString("Подзаголовок"),
    label = AnnotatedString("Лейбл"),
    disclosureContentEnabled = false,
    startContent = {
        Avatar(
            status = AvatarStatus.Active,
            placeholder = AvatarPlaceholder.Name("Michael Scott"),
        )
    },
    endContent = {
        var active by remember { mutableStateOf(false) }
        Switch(active = active, onActiveChanged = { active = it })
    },
)
```

<!-- @screenshot: com.sdds.compose.uikit.fixtures.samples.cell.Cell_AvatarSwitch -->

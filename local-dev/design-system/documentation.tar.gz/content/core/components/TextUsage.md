---
title: Text
---

`Text` используется для отображения текста в Compose. Обеспечивает поддержку  
локального стиля `LocalTextStyle`, настраиваемого поведения и работу через универсальный `TextSource`.  

```kotlin
Text(
    source = stringSource("Hello, world!"),
)
```

<!-- @screenshot: com.sdds.compose.uikit.fixtures.samples.text.Text_Simple -->

## Варианты использования

Компонент принимает `TextSource`, который можно создать из разных источников текста:

- Обычная строка (`String`)
- Аннотированная строка (`AnnotatedString`)
- Строковый ресурс (`@StringRes`)

### String

Используется для простого отображения текста через `stringSource`.

```kotlin
Text(
    source = stringSource("Текст со строковым источником"),
    style = TextStyle(fontSize = 16.sp),
)
```

<!-- @screenshot: com.sdds.compose.uikit.fixtures.samples.text.Text_String -->

### AnnotatedString

Поддерживает различные стили внутри одного текста и возможность вставки встроенных composable-элементов через `annotatedStringSource`.

```kotlin
val text = buildAnnotatedString {
    append("Текст с ")
    withStyle(SpanStyle(color = Color.Red)) {
        append("цветным фрагментом")
    }
}
Text(
    source = annotatedStringSource(text),
    style = TextStyle(fontSize = 16.sp),
)
```

<!-- @screenshot: com.sdds.compose.uikit.fixtures.samples.text.Text_Annotated -->

## Настройка стиля текста

По умолчанию `Text` использует значение из LocalTextStyle. Чтобы задать общий стиль для вложенных `Text`- компонентов,  
можно использовать `ProvideTextStyle`. Если в ProvideTextStyle указан TextStyle, он объединяется с текущим локальным  
стилем (`LocalTextStyle`), заполняя недостоющие пераметры.

```kotlin
ProvideTextStyle(TextStyle(fontSize = 20.sp), color = { Color.Gray }) {
    Column {
        Text(source = stringSource("Заголовок"))
        Text(source = stringSource("Описание"))
    }
}
```

<!-- @screenshot: com.sdds.compose.uikit.fixtures.samples.text.Text_ProvideStyle -->

Для задания цвета или кисти по умолчанию можно использовать overload `ProvideTextStyle(..., brush = ...)`.

## Inline Content

Текст с типом `AnnotatedString` поддерживает отображение встроенных composable через параметр `inlineContent`.  

```kotlin
val inlineContent = mapOf(
    "icon" to InlineTextContent(
        placeholder = Placeholder(16.sp, 16.sp, PlaceholderVerticalAlign.Center),
    ) {
        Icon(
            source = resourceImageSource(com.sdds.icons.R.drawable.ic_alarm_done_fill_36),
            contentDescription = null,
            brush = { Color.Red.asBrush() },
        )
    },
)

val text = buildAnnotatedString {
    append("Добавляем иконку")
    appendInlineContent("icon", "[icon]")
}

Text(
    source = annotatedStringSource(text),
    inlineContent = inlineContent,
)
```

<!-- @screenshot: com.sdds.compose.uikit.fixtures.samples.text.Text_InlineContent -->

## Параметры отображения

Компонент поддерживает стандартные параметры форматирования текста:  

```kotlin
Text(
    source = stringSource("Длинное описание чего то, содержащее много строк"),
    maxLines = 2,
    overflow = TextOverflow.Ellipsis,
    softWrap = true,
)
```

<!-- @screenshot: com.sdds.compose.uikit.fixtures.samples.text.Text_Formatting -->

---
title: Cutout - вырезы
---

`Cutout` нужен для сценариев, где один composable рисуется поверх другого, а в нижнем слое нужно
сделать вырез точно по форме и размеру overlay-элемента.

Типичный пример: `Avatar` с `badge`, `counter` или любым другим `extra`-контентом, который должен
не просто лежать сверху, а визуально "вставляться" в поверхность аватара.

## Основные роли

- `CutoutState` — общее состояние, через которое обмениваются данными источник и цель выреза.
- `ProvideCutoutState(...)` — делает это состояние доступным в поддереве composable.
- `Modifier.cutoutTarget()` — помечает слой, из которого нужно вырезать отверстия.
- `Modifier.cutout(...)` — помечает overlay-элемент, по bounds которого нужно вырезать отверстие.

## Базовый сценарий

1. Создайте общее состояние через `rememberCutoutState()`.
2. Оберните нужную часть UI в `ProvideCutoutState(state)`.
3. Повесьте `Modifier.cutoutTarget()` на базовый слой.
4. Повесьте `Modifier.cutout(...)` на overlay-элемент.

```kotlin
val cutoutState = rememberCutoutState()

ProvideCutoutState(cutoutState) {
    Box {
        Box(
            modifier = Modifier
                .size(56.dp)
                .background(Color.Gray, CircleShape)
                .cutoutTarget(),
        )

        Box(
            modifier = Modifier
                .align(Alignment.BottomEnd)
                .size(16.dp)
                .cutout(
                    shape = CircleShape,
                    padding = PaddingValues(2.dp, 2.dp),
                )
                .background(Color.Red, CircleShape),
        )
    }
}
```

В этом примере:
- нижний `Box` выступает целью выреза;
- верхний `Box` регистрирует свою геометрию как источник выреза;
- в результате в нижнем слое появится круглое отверстие чуть больше overlay-элемента.

## Использование в Avatar

В `Avatar` удобно применять cutout для `extra`-контента:

```kotlin
Avatar(
    placeholder = AvatarPlaceholder.Name("Michael Scott"),
    extra = {
        Badge(
            modifier = Modifier
                .align(Alignment.BottomEnd)
                .cutout(
                    shape = CircleShape,
                    padding = PaddingValues(2.dp, 2.dp),
                ),
            label = "3",
        )
    },
) {
    // Avatar Image
}
```

Чтобы это работало, внутри реализации `Avatar`:
- поверхность аватара должна быть помечена `Modifier.cutoutTarget()`;
- и поверхность, и `extra` должны находиться внутри общего `ProvideCutoutState(...)`.

## Когда передавать state явно

Во многих случаях достаточно локального состояния через `ProvideCutoutState(...)`.
Явная передача `state` в `cutoutTarget(state)` и `cutout(state)` полезна, если:

- нужно связать source и target между разными ветками композиции;
- нужно явно контролировать, какой target должен реагировать на какой overlay;
- в одном участке UI одновременно используется несколько независимых cutout-сценариев.

В этом случае используйте тот же подход, что и в `Cutout_Simple`, но передавайте
один и тот же экземпляр `state` явно в `cutoutTarget(state)` и `cutout(state)`.

## Параметры Modifier.cutout

- `shape` — форма отверстия. Обычно это `CircleShape`, но можно передать любую `Shape`.
- `padding` — дополнительное расширение области выреза относительно фактических bounds элемента.
- `enabled` — быстрый способ временно выключить регистрацию выреза.
- `state` — состояние cutout-системы. Если не задано, используется локальное.

## Ограничения и нюансы

- `cutout` работает по реальным `bounds` composable после layout, поэтому вырез следует за
  изменением размера и позиции элемента.
- Если у `cutoutTarget` и `cutout` нет общего `CutoutState`, вырез не появится.
- Вырез применяется только к слою, на который навешан `cutoutTarget()`.
  Сам overlay-элемент не стирается, если он рисуется поверх target отдельным слоем.
- Если overlay выходит за границы target, вырез будет рассчитываться относительно target,
  поэтому стоит отдельно проверить желаемое визуальное поведение в таких случаях.
